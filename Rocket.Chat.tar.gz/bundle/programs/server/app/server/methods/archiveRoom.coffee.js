(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/archiveRoom.coffee.js                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  archiveRoom: function(rid) {                                         // 2
    var i, len, member, ref, results, room, update, username;          // 3
    if (!Meteor.userId()) {                                            // 3
      throw new Meteor.Error('invalid-user', '[methods] archiveRoom -> Invalid user');
    }                                                                  //
    room = RocketChat.models.Rooms.findOneById(rid);                   // 3
    if ((room.u != null) && room.u._id === Meteor.userId() || RocketChat.authz.hasRole(Meteor.userId(), 'admin')) {
      update = {                                                       // 9
        $set: {                                                        // 10
          archived: true                                               // 11
        }                                                              //
      };                                                               //
      RocketChat.models.Rooms.archiveById(rid);                        // 9
      ref = room.usernames;                                            // 15
      results = [];                                                    // 15
      for (i = 0, len = ref.length; i < len; i++) {                    //
        username = ref[i];                                             //
        member = RocketChat.models.Users.findOneByUsername(username, {
          fields: {                                                    // 16
            username: 1                                                // 16
          }                                                            //
        });                                                            //
        if (member == null) {                                          // 17
          continue;                                                    // 18
        }                                                              //
        results.push(RocketChat.models.Subscriptions.archiveByRoomIdAndUserId(rid, member._id));
      }                                                                // 15
      return results;                                                  //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=archiveRoom.coffee.js.map
