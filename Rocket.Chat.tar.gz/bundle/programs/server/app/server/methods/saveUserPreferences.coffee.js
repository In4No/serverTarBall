(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/saveUserPreferences.coffee.js                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  saveUserPreferences: function(settings) {                            // 2
    var preferences;                                                   // 3
    if (Meteor.userId()) {                                             // 3
      preferences = {};                                                // 4
      if (settings.disableNewRoomNotification != null) {               // 6
        preferences.disableNewRoomNotification = settings.disableNewRoomNotification === "1" ? true : false;
      }                                                                //
      if (settings.disableNewMessageNotification != null) {            // 9
        preferences.disableNewMessageNotification = settings.disableNewMessageNotification === "1" ? true : false;
      }                                                                //
      if (settings.useEmojis != null) {                                // 12
        preferences.useEmojis = settings.useEmojis === "1" ? true : false;
      }                                                                //
      if (settings.convertAsciiEmoji != null) {                        // 15
        preferences.convertAsciiEmoji = settings.convertAsciiEmoji === "1" ? true : false;
      }                                                                //
      if (settings.saveMobileBandwidth != null) {                      // 18
        preferences.saveMobileBandwidth = settings.saveMobileBandwidth === "1" ? true : false;
      }                                                                //
      if (settings.compactView != null) {                              // 21
        preferences.compactView = settings.compactView === "1" ? true : false;
      }                                                                //
      if (settings.unreadRoomsMode != null) {                          // 24
        preferences.unreadRoomsMode = settings.unreadRoomsMode === "1" ? true : false;
      }                                                                //
      if (settings.autoImageLoad != null) {                            // 27
        preferences.autoImageLoad = settings.autoImageLoad === "1" ? true : false;
      }                                                                //
      if (settings.emailNotificationMode != null) {                    // 30
        preferences.emailNotificationMode = settings.emailNotificationMode;
      }                                                                //
      RocketChat.models.Users.setPreferences(Meteor.userId(), preferences);
      return true;                                                     // 35
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=saveUserPreferences.coffee.js.map
