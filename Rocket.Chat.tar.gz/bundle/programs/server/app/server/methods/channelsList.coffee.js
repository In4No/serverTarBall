(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/channelsList.coffee.js                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  channelsList: function() {                                           // 2
    return {                                                           // 3
      channels: RocketChat.models.Rooms.findByTypeAndArchivationState('c', false, {
        sort: {                                                        // 3
          msgs: -1                                                     // 3
        }                                                              //
      }).fetch()                                                       //
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=channelsList.coffee.js.map
