(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/createDirectMessage.coffee.js                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  createDirectMessage: function(username) {                            // 2
    var me, now, rid, to;                                              // 3
    if (!Meteor.userId()) {                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] createDirectMessage -> Invalid user");
    }                                                                  //
    me = Meteor.user();                                                // 3
    if (me.username === username) {                                    // 8
      throw new Meteor.Error('invalid-user', "[methods] createDirectMessage -> Invalid target user");
    }                                                                  //
    to = RocketChat.models.Users.findOneByUsername(username);          // 3
    if (!to) {                                                         // 13
      throw new Meteor.Error('invalid-user', "[methods] createDirectMessage -> Invalid target user");
    }                                                                  //
    rid = [me._id, to._id].sort().join('');                            // 3
    now = new Date();                                                  // 3
    RocketChat.models.Rooms.upsert({                                   // 3
      _id: rid                                                         // 22
    }, {                                                               //
      $set: {                                                          // 24
        usernames: [me.username, to.username]                          // 25
      },                                                               //
      $setOnInsert: {                                                  // 24
        t: 'd',                                                        // 27
        msgs: 0,                                                       // 27
        ts: now                                                        // 27
      }                                                                //
    });                                                                //
    RocketChat.models.Subscriptions.upsert({                           // 3
      rid: rid,                                                        // 33
      $and: [                                                          // 33
        {                                                              //
          'u._id': me._id                                              // 34
        }                                                              //
      ]                                                                //
    }, {                                                               //
      $set: {                                                          // 36
        ts: now,                                                       // 37
        ls: now,                                                       // 37
        open: true                                                     // 37
      },                                                               //
      $setOnInsert: {                                                  // 36
        name: to.username,                                             // 41
        t: 'd',                                                        // 41
        alert: false,                                                  // 41
        unread: 0,                                                     // 41
        u: {                                                           // 41
          _id: me._id,                                                 // 46
          username: me.username                                        // 46
        }                                                              //
      }                                                                //
    });                                                                //
    RocketChat.models.Subscriptions.upsert({                           // 3
      rid: rid,                                                        // 51
      $and: [                                                          // 51
        {                                                              //
          'u._id': to._id                                              // 52
        }                                                              //
      ]                                                                //
    }, {                                                               //
      $setOnInsert: {                                                  // 54
        name: me.username,                                             // 55
        t: 'd',                                                        // 55
        open: false,                                                   // 55
        alert: false,                                                  // 55
        unread: 0,                                                     // 55
        u: {                                                           // 55
          _id: to._id,                                                 // 61
          username: to.username                                        // 61
        }                                                              //
      }                                                                //
    });                                                                //
    return {                                                           // 64
      rid: rid                                                         // 64
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=createDirectMessage.coffee.js.map
