(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/getUsernameSuggestion.coffee.js                      //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var slug, usernameIsAvaliable;                                         // 1
                                                                       //
slug = function(text) {                                                // 1
  text = slugify(text, '.');                                           // 2
  return text.replace(/[^0-9a-z-_.]/g, '');                            // 3
};                                                                     // 1
                                                                       //
usernameIsAvaliable = function(username) {                             // 1
  if (username.length < 1) {                                           // 6
    return false;                                                      // 7
  }                                                                    //
  if (username === 'all') {                                            // 9
    return false;                                                      // 10
  }                                                                    //
  return !RocketChat.models.Users.findOneByUsername({                  // 12
    $regex: new RegExp("^" + username + "$", "i")                      // 12
  });                                                                  //
};                                                                     // 5
                                                                       //
this.generateSuggestion = function(user) {                             // 1
  var email, first, i, index, item, j, k, last, len, len1, len2, nameParts, ref, ref1, ref2, ref3, ref4, ref5, service, serviceName, username, usernames;
  usernames = [];                                                      // 15
  username = void 0;                                                   // 15
  if (RocketChat.settings.get('UTF8_Names_Slugify')) {                 // 18
    usernames.push(slug(user.name));                                   // 19
  } else {                                                             //
    usernames.push(user.name);                                         // 21
  }                                                                    //
  nameParts = user != null ? (ref = user.name) != null ? ref.split(' ') : void 0 : void 0;
  if (nameParts.length > 1) {                                          // 24
    first = nameParts[0];                                              // 25
    last = nameParts[nameParts.length - 1];                            // 25
    if (RocketChat.settings.get('UTF8_Names_Slugify')) {               // 28
      usernames.push(slug(first[0] + last));                           // 29
      usernames.push(slug(first + last[0]));                           // 29
    } else {                                                           //
      usernames.push(first[0] + last);                                 // 32
      usernames.push(first + last[0]);                                 // 32
    }                                                                  //
  }                                                                    //
  if (((ref1 = user.profile) != null ? ref1.name : void 0) != null) {  // 35
    if (RocketChat.settings.get('UTF8_Names_Slugify')) {               // 36
      usernames.push(slug(user.profile.name));                         // 37
    } else {                                                           //
      usernames.push(user.profile.name);                               // 39
    }                                                                  //
  }                                                                    //
  if (user.services != null) {                                         // 41
    ref2 = user.services;                                              // 42
    for (serviceName in ref2) {                                        // 42
      service = ref2[serviceName];                                     //
      if (service.name != null) {                                      // 43
        if (RocketChat.settings.get('UTF8_Names_Slugify')) {           // 44
          usernames.push(slug(service.name));                          // 45
        } else {                                                       //
          usernames.push(service.name);                                // 47
        }                                                              //
      } else if (service.username != null) {                           //
        if (RocketChat.settings.get('UTF8_Names_Slugify')) {           // 49
          usernames.push(slug(service.username));                      // 50
        } else {                                                       //
          usernames.push(service.username);                            // 52
        }                                                              //
      }                                                                //
    }                                                                  // 42
  }                                                                    //
  if (((ref3 = user.emails) != null ? ref3.length : void 0) > 0) {     // 54
    ref4 = user.emails;                                                // 55
    for (i = 0, len = ref4.length; i < len; i++) {                     // 55
      email = ref4[i];                                                 //
      if ((email.address != null) && email.verified === true) {        //
        usernames.push(slug(email.address.replace(/@.+$/, '')));       // 56
      }                                                                //
    }                                                                  // 55
    ref5 = user.emails;                                                // 58
    for (j = 0, len1 = ref5.length; j < len1; j++) {                   // 58
      email = ref5[j];                                                 //
      if ((email.address != null) && email.verified === true) {        //
        usernames.push(slug(email.address.replace(/(.+)@(\w+).+/, '$1.$2')));
      }                                                                //
    }                                                                  // 58
  }                                                                    //
  for (k = 0, len2 = usernames.length; k < len2; k++) {                // 61
    item = usernames[k];                                               //
    if (usernameIsAvaliable(item)) {                                   // 62
      username = item;                                                 // 63
      break;                                                           // 64
    }                                                                  //
  }                                                                    // 61
  if ((usernames[0] != null) && usernames[0].length > 0) {             // 66
    index = 0;                                                         // 67
    while (username == null) {                                         // 68
      index++;                                                         // 69
      if (usernameIsAvaliable(usernames[0] + '-' + index)) {           // 70
        username = usernames[0] + '-' + index;                         // 71
      }                                                                //
    }                                                                  //
  }                                                                    //
  if (usernameIsAvaliable(username)) {                                 // 73
    return username;                                                   // 74
  }                                                                    //
  return void 0;                                                       // 76
};                                                                     // 14
                                                                       //
RocketChat.generateUsernameSuggestion = generateSuggestion;            // 1
                                                                       //
Meteor.methods({                                                       // 1
  getUsernameSuggestion: function() {                                  // 80
    var user;                                                          // 81
    if (!Meteor.userId()) {                                            // 81
      throw new Meteor.Error(203, '[methods] getUsernameSuggestion -> Usuário não logado');
    }                                                                  //
    user = Meteor.user();                                              // 81
    return generateSuggestion(user);                                   // 85
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=getUsernameSuggestion.coffee.js.map
