(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/createPrivateGroup.coffee.js                         //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  createPrivateGroup: function(name, members) {                        // 2
    var extra, i, len, me, member, nameValidation, now, room, username;
    if (!Meteor.userId()) {                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] createPrivateGroup -> Invalid user");
    }                                                                  //
    if (!RocketChat.authz.hasPermission(Meteor.userId(), 'create-p')) {
      throw new Meteor.Error('not-authorized', '[methods] createPrivateGroup -> Not authorized');
    }                                                                  //
    try {                                                              // 9
      nameValidation = new RegExp('^' + RocketChat.settings.get('UTF8_Names_Validation') + '$');
    } catch (_error) {                                                 //
      nameValidation = new RegExp('^[0-9a-zA-Z-_.]+$');                // 12
    }                                                                  //
    if (!nameValidation.test(name)) {                                  // 14
      throw new Meteor.Error('name-invalid');                          // 15
    }                                                                  //
    now = new Date();                                                  // 3
    me = Meteor.user();                                                // 3
    members.push(me.username);                                         // 3
    if (RocketChat.models.Rooms.findOneByName(name)) {                 // 26
      if (RocketChat.models.Rooms.findOneByName(name).archived) {      // 27
        throw new Meteor.Error('archived-duplicate-name');             // 28
      } else {                                                         //
        throw new Meteor.Error('duplicate-name');                      // 30
      }                                                                //
    }                                                                  //
    room = RocketChat.models.Rooms.createWithTypeNameUserAndUsernames('p', name, me, members, {
      ts: now                                                          // 34
    });                                                                //
    RocketChat.authz.addUserRoles(Meteor.userId(), ['moderator', 'owner'], room._id);
    for (i = 0, len = members.length; i < len; i++) {                  // 39
      username = members[i];                                           //
      member = RocketChat.models.Users.findOneByUsername(username, {   // 40
        fields: {                                                      // 40
          username: 1                                                  // 40
        }                                                              //
      });                                                              //
      if (member == null) {                                            // 41
        continue;                                                      // 42
      }                                                                //
      extra = {};                                                      // 40
      if (username === me.username) {                                  // 46
        extra.ls = now;                                                // 47
      } else {                                                         //
        extra.alert = true;                                            // 49
      }                                                                //
      RocketChat.models.Subscriptions.createWithRoomAndUser(room, member, extra);
    }                                                                  // 39
    return {                                                           // 53
      rid: room._id                                                    // 53
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=createPrivateGroup.coffee.js.map
