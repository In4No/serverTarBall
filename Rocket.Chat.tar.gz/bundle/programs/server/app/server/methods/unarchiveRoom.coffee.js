(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/unarchiveRoom.coffee.js                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  unarchiveRoom: function(rid) {                                       // 2
    var i, len, member, ref, results, room, username;                  // 3
    if (!Meteor.userId()) {                                            // 3
      throw new Meteor.Error('invalid-user', '[methods] unarchiveRoom -> Invalid user');
    }                                                                  //
    room = RocketChat.models.Rooms.findOneById(rid);                   // 3
    if ((room.u != null) && room.u._id === Meteor.userId() || RocketChat.authz.hasRole(Meteor.userId(), 'admin')) {
      RocketChat.models.Rooms.unarchiveById(rid);                      // 9
      ref = room.usernames;                                            // 11
      results = [];                                                    // 11
      for (i = 0, len = ref.length; i < len; i++) {                    //
        username = ref[i];                                             //
        member = RocketChat.models.Users.findOneByUsername(username, {
          fields: {                                                    // 12
            username: 1                                                // 12
          }                                                            //
        });                                                            //
        if (member == null) {                                          // 13
          continue;                                                    // 14
        }                                                              //
        results.push(RocketChat.models.Subscriptions.unarchiveByRoomIdAndUserId(rid, member._id));
      }                                                                // 11
      return results;                                                  //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=unarchiveRoom.coffee.js.map
