(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/methods/saveUserProfile.coffee.js                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                       // 1
  saveUserProfile: function(settings) {                                // 2
    var profile;                                                       // 3
    if (!RocketChat.settings.get("Accounts_AllowUserProfileChange")) {
      throw new Meteor.Error(403, "[methods] resetAvatar -> Invalid access");
    }                                                                  //
    if (Meteor.userId()) {                                             // 6
      if (settings.language != null) {                                 // 7
        RocketChat.models.Users.setLanguage(Meteor.userId(), settings.language);
      }                                                                //
      if (settings.realname != null) {                                 // 13
        Meteor.call('setRealName', settings.realname);                 // 14
      }                                                                //
      if (settings.username != null) {                                 // 16
        Meteor.call('setUsername', settings.username);                 // 17
      }                                                                //
      if (settings.email != null) {                                    // 19
        Meteor.call('setEmail', settings.email);                       // 20
      }                                                                //
      profile = {};                                                    // 7
      RocketChat.models.Users.setProfile(Meteor.userId(), profile);    // 7
      return true;                                                     // 26
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=saveUserProfile.coffee.js.map
