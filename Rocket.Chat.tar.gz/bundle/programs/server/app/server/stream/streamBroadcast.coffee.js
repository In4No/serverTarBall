(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/stream/streamBroadcast.coffee.js                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.connections = {};                                                 // 1
                                                                       //
this.startStreamBroadcast = function(streams) {                        // 1
  var broadcast, emitters, fn, stream, streamName;                     // 3
  console.log('startStreamBroadcast');                                 // 3
  InstanceStatus.getCollection().find({                                // 3
    'extraInformation.port': {                                         // 7
      $exists: true                                                    // 7
    }                                                                  //
  }, {                                                                 //
    sort: {                                                            // 7
      _createdAt: -1                                                   // 7
    }                                                                  //
  }).observe({                                                         //
    added: function(record) {                                          // 8
      if (record.extraInformation.port === process.env.PORT || (connections[record.extraInformation.port] != null)) {
        return;                                                        // 10
      }                                                                //
      console.log('connecting in', "localhost:" + record.extraInformation.port);
      connections[record.extraInformation.port] = DDP.connect("localhost:" + record.extraInformation.port, {
        _dontPrintErrors: true                                         // 13
      });                                                              //
      return connections[record.extraInformation.port].call('broadcastAuth', record._id, InstanceStatus.id(), function(err, ok) {
        connections[record.extraInformation.port].broadcastAuth = ok;  // 15
        return console.log("broadcastAuth with localhost:" + record.extraInformation.port, ok);
      });                                                              //
    },                                                                 //
    removed: function(record) {                                        // 8
      if ((connections[record.extraInformation.port] != null) && (InstanceStatus.getCollection().findOne({
        'extraInformation.port': record.extraInformation.port          //
      }) == null)) {                                                   //
        console.log('disconnecting from', "localhost:" + record.extraInformation.port);
        connections[record.extraInformation.port].disconnect();        // 20
        return delete connections[record.extraInformation.port];       //
      }                                                                //
    }                                                                  //
  });                                                                  //
  broadcast = function(streamName, args, userId) {                     // 3
    var connection, port, results;                                     // 25
    results = [];                                                      // 25
    for (port in connections) {                                        //
      connection = connections[port];                                  //
      results.push((function(port, connection) {                       // 26
        if (connection.status().connected === true) {                  // 27
          return connection.call('stream', streamName, args, function(error, response) {
            if (error != null) {                                       // 29
              console.log("Stream broadcast error", error);            // 30
            }                                                          //
            switch (response) {                                        // 32
              case 'self-not-authorized':                              // 32
                console.log(("Stream broadcast from:" + process.env.PORT + " to:" + connection._stream.endpoint + " with name " + streamName + " to self is not authorized").red);
                console.log("    -> connection authorized".red, connection.broadcastAuth);
                console.log("    -> connection status".red, connection.status());
                return console.log("    -> arguments".red, args);      //
              case 'not-authorized':                                   // 32
                console.log(("Stream broadcast from:" + process.env.PORT + " to:" + connection._stream.endpoint + " with name " + streamName + " not authorized").red);
                console.log("    -> connection authorized".red, connection.broadcastAuth);
                console.log("    -> connection status".red, connection.status());
                return console.log("    -> arguments".red, args);      //
              case 'stream-not-exists':                                // 32
                console.log(("Stream broadcast from:" + process.env.PORT + " to:" + connection._stream.endpoint + " with name " + streamName + " does not exists").red);
                console.log("    -> connection authorized".red, connection.broadcastAuth);
                console.log("    -> connection status".red, connection.status());
                return console.log("    -> arguments".red, args);      //
            }                                                          // 32
          });                                                          //
        }                                                              //
      })(port, connection));                                           //
    }                                                                  // 25
    return results;                                                    //
  };                                                                   //
  Meteor.methods({                                                     // 3
    showConnections: function() {                                      // 53
      var connection, data, port;                                      // 54
      data = {};                                                       // 54
      for (port in connections) {                                      // 55
        connection = connections[port];                                //
        data[port] = {                                                 // 56
          status: connection.status(),                                 // 57
          broadcastAuth: connection.broadcastAuth                      // 57
        };                                                             //
      }                                                                // 55
      return data;                                                     // 59
    }                                                                  //
  });                                                                  //
  emitters = {};                                                       // 3
  fn = function(streamName, stream) {                                  // 63
    emitters[streamName] = stream.emitToSubscriptions;                 // 65
    return stream.emitToSubscriptions = function(args, subscriptionId, userId) {
      if (subscriptionId !== 'broadcasted') {                          // 67
        broadcast(streamName, args);                                   // 68
      }                                                                //
      return emitters[streamName](args, subscriptionId, userId);       //
    };                                                                 //
  };                                                                   //
  for (streamName in streams) {                                        // 63
    stream = streams[streamName];                                      //
    fn(streamName, stream);                                            // 64
  }                                                                    // 63
  return Meteor.methods({                                              //
    broadcastAuth: function(selfId, remoteId) {                        // 73
      check(selfId, String);                                           // 74
      check(remoteId, String);                                         // 74
      this.unblock();                                                  // 74
      if (selfId === InstanceStatus.id() && remoteId !== InstanceStatus.id() && (InstanceStatus.getCollection().findOne({
        _id: remoteId                                                  //
      }) != null)) {                                                   //
        this.connection.broadcastAuth = true;                          // 79
      }                                                                //
      return this.connection.broadcastAuth === true;                   // 81
    },                                                                 //
    stream: function(streamName, args) {                               // 73
      if (this.connection == null) {                                   // 85
        return 'self-not-authorized';                                  // 86
      }                                                                //
      if (this.connection.broadcastAuth !== true) {                    // 89
        return 'not-authorized';                                       // 90
      }                                                                //
      if (emitters[streamName] == null) {                              // 92
        return 'stream-not-exists';                                    // 93
      }                                                                //
      emitters[streamName].call(null, args, 'broadcasted');            // 85
      return void 0;                                                   // 97
    }                                                                  //
  });                                                                  //
};                                                                     // 2
                                                                       //
Meteor.startup(function() {                                            // 1
  var config;                                                          // 101
  config = {                                                           // 101
    'RocketChat.Notifications.streamAll': RocketChat.Notifications.streamAll,
    'RocketChat.Notifications.streamRoom': RocketChat.Notifications.streamRoom,
    'RocketChat.Notifications.streamUser': RocketChat.Notifications.streamUser
  };                                                                   //
  return startStreamBroadcast(config);                                 //
});                                                                    // 100
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=streamBroadcast.coffee.js.map
