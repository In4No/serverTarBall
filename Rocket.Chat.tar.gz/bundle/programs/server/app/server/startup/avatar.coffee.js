(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/startup/avatar.coffee.js                                     //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.startup(function() {                                            // 1
  var RocketChatStore, path, ref, storeType, transformWrite;           // 2
  storeType = 'GridFS';                                                // 2
  if (RocketChat.settings.get('Accounts_AvatarStoreType')) {           // 4
    storeType = RocketChat.settings.get('Accounts_AvatarStoreType');   // 5
  }                                                                    //
  RocketChatStore = RocketChatFile[storeType];                         // 2
  if (RocketChatStore == null) {                                       // 9
    throw new Error("Invalid RocketChatStore type [" + storeType + "]");
  }                                                                    //
  console.log(("Using " + storeType + " for Avatar storage").green);   // 2
  transformWrite = function(file, readStream, writeStream) {           // 2
    var height, width;                                                 // 15
    if (RocketChatFile.enabled === false || RocketChat.settings.get('Accounts_AvatarResize') !== true) {
      return readStream.pipe(writeStream);                             // 16
    }                                                                  //
    height = RocketChat.settings.get('Accounts_AvatarSize');           // 15
    width = height;                                                    // 15
    return RocketChatFile.gm(readStream, file.fileName).background('#ffffff').resize(width, height + '^>').gravity('Center').extent(width, height).stream('jpeg').pipe(writeStream);
  };                                                                   //
  path = "~/uploads";                                                  // 2
  if (((ref = RocketChat.settings.get('Accounts_AvatarStorePath')) != null ? ref.trim() : void 0) !== '') {
    path = RocketChat.settings.get('Accounts_AvatarStorePath');        // 26
  }                                                                    //
  this.RocketChatFileAvatarInstance = new RocketChatStore({            // 2
    name: 'avatars',                                                   // 29
    absolutePath: path,                                                // 29
    transformWrite: transformWrite                                     // 29
  });                                                                  //
  return WebApp.connectHandlers.use('/avatar/', function(req, res, next) {
    var color, colors, file, initials, params, position, ref1, ref2, reqModifiedHeader, svg, username, usernameParts;
    params = {                                                         // 34
      username: decodeURIComponent(req.url.replace(/^\//, '').replace(/\?.*$/, ''))
    };                                                                 //
    if (params.username[0] !== '@') {                                  // 37
      file = RocketChatFileAvatarInstance.getFileWithReadStream(encodeURIComponent(params.username));
    } else {                                                           //
      params.username = params.username.replace('@', '');              // 40
    }                                                                  //
    res.setHeader('Content-Disposition', 'inline');                    // 34
    if (file == null) {                                                // 45
      res.setHeader('Content-Type', 'image/svg+xml');                  // 46
      res.setHeader('Cache-Control', 'public, max-age=0');             // 46
      res.setHeader('Expires', '-1');                                  // 46
      res.setHeader('Last-Modified', "Thu, 01 Jan 2015 00:00:00 GMT");
      reqModifiedHeader = req.headers["if-modified-since"];            // 46
      if (reqModifiedHeader != null) {                                 // 52
        if (reqModifiedHeader === "Thu, 01 Jan 2015 00:00:00 GMT") {   // 53
          res.writeHead(304);                                          // 54
          res.end();                                                   // 54
          return;                                                      // 56
        }                                                              //
      }                                                                //
      colors = ['#F44336', '#E91E63', '#9C27B0', '#673AB7', '#3F51B5', '#2196F3', '#03A9F4', '#00BCD4', '#009688', '#4CAF50', '#8BC34A', '#CDDC39', '#FFC107', '#FF9800', '#FF5722', '#795548', '#9E9E9E', '#607D8B'];
      username = params.username.replace('.jpg', '');                  // 46
      color = '';                                                      // 46
      initials = '';                                                   // 46
      if (username === "?") {                                          // 63
        color = "#000";                                                // 64
        initials = username;                                           // 64
      } else {                                                         //
        position = username.length % colors.length;                    // 67
        color = colors[position];                                      // 67
        username = username.replace(/[^A-Za-z0-9]/g, '.').replace(/\.+/g, '.').replace(/(^\.)|(\.$)/g, '');
        usernameParts = username.split('.');                           // 67
        initials = usernameParts.length > 1 ? _.first(usernameParts)[0] + _.last(usernameParts)[0] : username.replace(/[^A-Za-z0-9]/g, '').substr(0, 2);
        initials = initials.toUpperCase();                             // 67
      }                                                                //
      svg = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg xmlns=\"http://www.w3.org/2000/svg\" pointer-events=\"none\" width=\"50\" height=\"50\" style=\"width: 50px; height: 50px; background-color: " + color + ";\">\n	<text text-anchor=\"middle\" y=\"50%\" x=\"50%\" dy=\"0.36em\" pointer-events=\"auto\" fill=\"#ffffff\" font-family=\"Helvetica, Arial, Lucida Grande, sans-serif\" style=\"font-weight: 400; font-size: 28px;\">\n		" + initials + "\n	</text>\n</svg>";
      res.write(svg);                                                  // 46
      res.end();                                                       // 46
      return;                                                          // 88
    }                                                                  //
    reqModifiedHeader = req.headers["if-modified-since"];              // 34
    if (reqModifiedHeader != null) {                                   // 91
      if (reqModifiedHeader === ((ref1 = file.uploadDate) != null ? ref1.toUTCString() : void 0)) {
        res.setHeader('Last-Modified', reqModifiedHeader);             // 93
        res.writeHead(304);                                            // 93
        res.end();                                                     // 93
        return;                                                        // 96
      }                                                                //
    }                                                                  //
    res.setHeader('Cache-Control', 'public, max-age=0');               // 34
    res.setHeader('Expires', '-1');                                    // 34
    res.setHeader('Last-Modified', ((ref2 = file.uploadDate) != null ? ref2.toUTCString() : void 0) || new Date().toUTCString());
    res.setHeader('Content-Type', 'image/jpeg');                       // 34
    res.setHeader('Content-Length', file.length);                      // 34
    file.readStream.pipe(res);                                         // 34
  });                                                                  //
});                                                                    // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=avatar.coffee.js.map
