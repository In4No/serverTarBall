(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/roomSearch.coffee.js                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('roomSearch', function(selector, options, collName) {   // 1
  var ref, searchType, self, subHandleRooms, subHandleUsers;           // 2
  if (!this.userId) {                                                  // 2
    return this.ready();                                               // 3
  }                                                                    //
  self = this;                                                         // 2
  searchType = null;                                                   // 2
  subHandleUsers = null;                                               // 2
  subHandleRooms = null;                                               // 2
  if (selector.type) {                                                 // 10
    searchType = selector.type;                                        // 11
    delete selector.type;                                              // 11
  }                                                                    //
  if ((searchType == null) || searchType === 'u') {                    // 14
    subHandleUsers = RocketChat.models.Users.find(selector, {          // 15
      limit: 10,                                                       // 15
      fields: {                                                        // 15
        name: 1,                                                       // 15
        username: 1,                                                   // 15
        status: 1                                                      // 15
      },                                                               //
      sort: {                                                          // 15
        name: 1                                                        // 15
      }                                                                //
    }).observeChanges({                                                //
      added: function(id, fields) {                                    // 16
        var data;                                                      // 17
        data = {                                                       // 17
          type: 'u',                                                   // 17
          uid: id,                                                     // 17
          name: fields.name,                                           // 17
          username: fields.username,                                   // 17
          status: fields.status                                        // 17
        };                                                             //
        return self.added("autocompleteRecords", id, data);            //
      },                                                               //
      changed: function(id, fields) {                                  // 16
        return self.changed("autocompleteRecords", id, fields);        //
      },                                                               //
      removed: function(id) {                                          // 16
        return self.removed("autocompleteRecords", id);                //
      }                                                                //
    });                                                                //
  }                                                                    //
  if ((searchType == null) || searchType === 'r') {                    // 24
    subHandleRooms = RocketChat.models.Rooms.findByTypesAndNotUserIdContainingUsername(RocketChat.roomTypes.getIdentifiers('d'), (ref = selector.uid) != null ? ref.$ne : void 0, RocketChat.models.Users.findOneById(this.userId).username, {
      limit: 10,                                                       // 25
      fields: {                                                        // 25
        t: 1,                                                          // 25
        name: 1                                                        // 25
      },                                                               //
      sort: {                                                          // 25
        name: 1                                                        // 25
      }                                                                //
    }).observeChanges({                                                //
      added: function(id, fields) {                                    // 26
        var data;                                                      // 27
        data = {                                                       // 27
          type: 'r',                                                   // 27
          rid: id,                                                     // 27
          name: fields.name,                                           // 27
          t: fields.t                                                  // 27
        };                                                             //
        return self.added("autocompleteRecords", id, data);            //
      },                                                               //
      changed: function(id, fields) {                                  // 26
        return self.changed("autocompleteRecords", id, fields);        //
      },                                                               //
      removed: function(id) {                                          // 26
        return self.removed("autocompleteRecords", id);                //
      }                                                                //
    });                                                                //
  }                                                                    //
  this.ready();                                                        // 2
  return this.onStop(function() {                                      //
    if (subHandleUsers != null) {                                      //
      subHandleUsers.stop();                                           //
    }                                                                  //
    return subHandleRooms != null ? subHandleRooms.stop() : void 0;    //
  });                                                                  //
});                                                                    // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=roomSearch.coffee.js.map
