(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/filteredUsers.coffee.js                         //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('filteredUsers', function(name) {                       // 1
  var cursorHandle, exp, options, pub;                                 // 2
  if (!this.userId) {                                                  // 2
    return this.ready();                                               // 3
  }                                                                    //
  exp = new RegExp(name, 'i');                                         // 2
  options = {                                                          // 2
    fields: {                                                          // 8
      username: 1,                                                     // 9
      name: 1,                                                         // 9
      status: 1,                                                       // 9
      utcOffset: 1                                                     // 9
    },                                                                 //
    sort: {                                                            // 8
      lastLogin: -1                                                    // 14
    },                                                                 //
    limit: 5                                                           // 8
  };                                                                   //
  pub = this;                                                          // 2
  cursorHandle = RocketChat.models.Users.findByActiveUsersNameOrUsername(exp, options).observeChanges({
    added: function(_id, record) {                                     // 20
      return pub.added('filtered-users', _id, record);                 //
    },                                                                 //
    changed: function(_id, record) {                                   // 20
      return pub.changed('filtered-users', _id, record);               //
    },                                                                 //
    removed: function(_id, record) {                                   // 20
      return pub.removed('filtered-users', _id, record);               //
    }                                                                  //
  });                                                                  //
  this.ready();                                                        // 2
  this.onStop(function() {                                             // 2
    return cursorHandle.stop();                                        //
  });                                                                  //
});                                                                    // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=filteredUsers.coffee.js.map
