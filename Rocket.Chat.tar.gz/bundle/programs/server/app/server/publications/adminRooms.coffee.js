(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/adminRooms.coffee.js                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('adminRooms', function(filter, types, limit) {          // 1
  var options;                                                         // 2
  if (!this.userId) {                                                  // 2
    return this.ready();                                               // 3
  }                                                                    //
  if (RocketChat.authz.hasPermission(this.userId, 'view-room-administration') !== true) {
    return this.ready();                                               // 6
  }                                                                    //
  if (!_.isArray(types)) {                                             // 8
    types = [];                                                        // 9
  }                                                                    //
  options = {                                                          // 2
    fields: {                                                          // 12
      name: 1,                                                         // 13
      t: 1,                                                            // 13
      cl: 1,                                                           // 13
      u: 1,                                                            // 13
      usernames: 1,                                                    // 13
      muted: 1                                                         // 13
    },                                                                 //
    limit: limit,                                                      // 12
    sort: {                                                            // 12
      name: 1                                                          // 21
    }                                                                  //
  };                                                                   //
  filter = _.trim(filter);                                             // 2
  if (filter && types.length) {                                        // 25
    return RocketChat.models.Rooms.findByNameContainingAndTypes(filter, types, options);
  }                                                                    //
  if (filter) {                                                        // 28
    return RocketChat.models.Rooms.findByNameContaining(filter, options);
  }                                                                    //
  if (types.length) {                                                  // 31
    return RocketChat.models.Rooms.findByTypes(types, options);        // 32
  }                                                                    //
});                                                                    // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=adminRooms.coffee.js.map
