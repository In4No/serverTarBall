(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/fullUserData.coffee.js                          //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('fullUserData', function(filter, limit) {               // 1
  var fields, filterReg, options;                                      // 2
  if (!this.userId) {                                                  // 2
    return this.ready();                                               // 3
  }                                                                    //
  fields = {                                                           // 2
    name: 1,                                                           // 6
    username: 1,                                                       // 6
    status: 1,                                                         // 6
    utcOffset: 1                                                       // 6
  };                                                                   //
  if (RocketChat.authz.hasPermission(this.userId, 'view-full-other-user-info') === true) {
    fields = _.extend(fields, {                                        // 12
      emails: 1,                                                       // 13
      phone: 1,                                                        // 13
      statusConnection: 1,                                             // 13
      createdAt: 1,                                                    // 13
      lastLogin: 1,                                                    // 13
      active: 1,                                                       // 13
      services: 1,                                                     // 13
      roles: 1,                                                        // 13
      requirePasswordChange: 1                                         // 13
    });                                                                //
  } else {                                                             //
    limit = 1;                                                         // 23
  }                                                                    //
  filter = s.trim(filter);                                             // 2
  if (!filter && limit === 1) {                                        // 27
    return this.ready();                                               // 28
  }                                                                    //
  options = {                                                          // 2
    fields: fields,                                                    // 31
    limit: limit,                                                      // 31
    sort: {                                                            // 31
      username: 1                                                      // 33
    }                                                                  //
  };                                                                   //
  if (filter) {                                                        // 35
    if (limit === 1) {                                                 // 36
      return RocketChat.models.Users.findByUsername(filter, options);  // 37
    } else {                                                           //
      filterReg = new RegExp(filter, "i");                             // 39
      return RocketChat.models.Users.findByUsernameNameOrEmailAddress(filterReg, options);
    }                                                                  //
  }                                                                    //
  return RocketChat.models.Users.find({}, options);                    // 42
});                                                                    // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fullUserData.coffee.js.map
