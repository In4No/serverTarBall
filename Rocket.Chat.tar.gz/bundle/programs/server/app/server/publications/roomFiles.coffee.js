(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications/roomFiles.coffee.js                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('roomFiles', function(rid, limit) {                     // 1
  var cursorFileListHandle, fileOptions, fileQuery, pub;               // 2
  if (limit == null) {                                                 //
    limit = 50;                                                        //
  }                                                                    //
  if (!this.userId) {                                                  // 2
    return this.ready();                                               // 3
  }                                                                    //
  pub = this;                                                          // 2
  fileQuery = {                                                        // 2
    rid: rid,                                                          // 8
    complete: true,                                                    // 8
    uploading: false,                                                  // 8
    _hidden: {                                                         // 8
      $ne: true                                                        // 12
    }                                                                  //
  };                                                                   //
  fileOptions = {                                                      // 2
    limit: limit,                                                      // 15
    sort: {                                                            // 15
      uploadedAt: -1                                                   // 17
    },                                                                 //
    fields: {                                                          // 15
      _id: 1,                                                          // 19
      userId: 1,                                                       // 19
      rid: 1,                                                          // 19
      name: 1,                                                         // 19
      type: 1,                                                         // 19
      url: 1                                                           // 19
    }                                                                  //
  };                                                                   //
  cursorFileListHandle = RocketChat.models.Uploads.find(fileQuery, fileOptions).observeChanges({
    added: function(_id, record) {                                     // 27
      return pub.added('room_files', _id, record);                     //
    },                                                                 //
    changed: function(_id, record) {                                   // 27
      return pub.changed('room_files', _id, record);                   //
    },                                                                 //
    removed: function(_id, record) {                                   // 27
      return pub.removed('room_files', _id, record);                   //
    }                                                                  //
  });                                                                  //
  this.ready();                                                        // 2
  return this.onStop(function() {                                      //
    return cursorFileListHandle.stop();                                //
  });                                                                  //
});                                                                    // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=roomFiles.coffee.js.map
