(function(){var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["fa"] = ["Persian","فارسی"];
if(_.isUndefined(TAPi18n.translations["fa"])) {
  TAPi18n.translations["fa"] = {};
}

if(_.isUndefined(TAPi18n.translations["fa"][namespace])) {
  TAPi18n.translations["fa"][namespace] = {};
}

_.extend(TAPi18n.translations["fa"][namespace], {"Accounts":"حساب ها"});
TAPi18n._registerServerTranslator("fa", namespace);

}).call(this);

//# sourceMappingURL=fa.i18n.js.map
