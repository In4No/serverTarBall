(function(){var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["cs"] = ["Czech","čeština‎"];
if(_.isUndefined(TAPi18n.translations["cs"])) {
  TAPi18n.translations["cs"] = {};
}

if(_.isUndefined(TAPi18n.translations["cs"][namespace])) {
  TAPi18n.translations["cs"][namespace] = {};
}

_.extend(TAPi18n.translations["cs"][namespace], {"Add_users":"Přidat uživatele","are_also_typing":"také píší","are_typing":"píší","Channels":"Kanály","Channels_list":"Seznam veřejných kanálů","Create_new_public_channel":"Vytvořit nový veřejný kanál","Direct_Messages":"Přímé zprávy","edited":"upraveno","Email_verified":"Email ověřen","Error_changing_password":"Chyba změny hesla","Favorites":"Oblíbené","Hide_room":"Skrýt místnost","Invalid_room_name":"<strong>%s</strong> není platné jméno místnosti,<br/> použijte pouze písmena, číslice a pomlčky","is_also_typing":"také píše","is_typing":"píše","Leave_room":"Opustit místnost","Members":"Členové","Members_List":"Seznam členů","Members_placeholder":"Členové","More_channels":"Další kanály","Name":"Jméno","New_messages":"Nové zprávy","New_password":"Nové heslo","No_channels_yet":"Zatím se neúčastníte v žádném kanálu.","No_direct_messages_yet":"Zatím jste nezačali žádné konverzace.","No_favorites_yet":"Zatím jste nepřidali žádné oblíbené.","No_groups_yet":"Zatím nemáte žádné soukromé skupiny.","Powered_by":"Běží na","Private_Groups":"Soukromé skupiny","Quick_Search":"Rychlé vyhledávání","Recents":"Nedávné","Room_name_changed":"Jméno místnosti změněno na: <em>__room_name__</em> uživatelem <em>__user_by__</em>","Room_name_changed_successfully":"Změna jména místnosti proběhla úspěšně","See_all":"Zobrazit všechny","See_only_online":"Pouze online","Selected_users":"Vybraní členové","Send_Message":"Poslat zprávu","Showing_online_users":"Viditelných <b>__total_showing__</b> z __total__ users","Start_of_conversation":"Začít konverzaci","User_added_by":"<em>__user_by__</em> přidal uživatele <em>__user_added__</em>.","User_left":"Opustil(a) kanál.","User_removed_by":"<em>__user_by__</em> odstranil uživatele <em>__user_removed__</em>.","View_All":"Zobrazit vše","Welcome":"Vítej <em>%s</em>."});
TAPi18n._registerServerTranslator("cs", namespace);

}).call(this);

//# sourceMappingURL=cs.i18n.js.map
