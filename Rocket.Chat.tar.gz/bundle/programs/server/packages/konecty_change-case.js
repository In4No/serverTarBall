(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var changeCase;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/konecty_change-case/packages/konecty_change-case.js           //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {                                                            // 1
                                                                          // 2
///////////////////////////////////////////////////////////////////////   // 3
//                                                                   //   // 4
// packages/konecty:change-case/konecty:change-case.js               //   // 5
//                                                                   //   // 6
///////////////////////////////////////////////////////////////////////   // 7
                                                                     //   // 8
// Write your package code here!                                     // 1
changeCase = Npm.require('change-case');                             // 2
///////////////////////////////////////////////////////////////////////   // 11
                                                                          // 12
}).call(this);                                                            // 13
                                                                          // 14
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['konecty:change-case'] = {
  changeCase: changeCase
};

})();

//# sourceMappingURL=konecty_change-case.js.map
