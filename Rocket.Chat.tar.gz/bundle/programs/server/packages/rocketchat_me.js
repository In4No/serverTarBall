(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var RocketChat = Package['rocketchat:lib'].RocketChat;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/rocketchat_me/me.coffee.js                               //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                     // 1
/*                                                                   // 1
 * Me is a named function that will replace /me commands             //
 * @param {Object} message - The message object                      //
 */                                                                  //
var Me;                                                              // 1
                                                                     //
Me = (function() {                                                   // 1
  function Me(command, params, item) {                               // 7
    var currentUser, msg;                                            // 8
    if (command === "me") {                                          // 8
      if (_.trim(params)) {                                          // 9
        currentUser = Meteor.user();                                 // 10
        msg = item;                                                  // 10
        msg.msg = '_' + params + '_';                                // 10
        Meteor.call('sendMessage', msg);                             // 10
      }                                                              //
    }                                                                //
  }                                                                  //
                                                                     //
  return Me;                                                         //
                                                                     //
})();                                                                //
                                                                     //
RocketChat.slashCommands.add('me', Me);                              // 1
                                                                     //
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:me'] = {};

})();

//# sourceMappingURL=rocketchat_me.js.map
