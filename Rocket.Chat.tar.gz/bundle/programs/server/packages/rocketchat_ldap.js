(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var LDAPJS = Package['rocketchat:ldapjs'].LDAPJS;
var Logger = Package['rocketchat:logger'].Logger;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;
var slugify = Package['yasaricli:slugify'].slugify;
var ECMAScript = Package.ecmascript.ECMAScript;
var SHA256 = Package.sha.SHA256;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var LDAP, domain_search_user_id, loginRequest, users, __coffeescriptShare, user;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_ldap/server/ldap.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var ldapjs = LDAPJS;                                                                                                   // 1
                                                                                                                       //
var logger = new Logger('LDAP', {                                                                                      // 3
	methods: {                                                                                                            // 4
		connection_info: { type: 'info' },                                                                                   // 5
		connection_debug: { type: 'debug' },                                                                                 // 6
		connection_error: { type: 'error' },                                                                                 // 7
		bind_info: { type: 'info' },                                                                                         // 8
		search_info: { type: 'info' },                                                                                       // 9
		search_debug: { type: 'debug' },                                                                                     // 10
		search_error: { type: 'error' },                                                                                     // 11
		auth_info: { type: 'info' },                                                                                         // 12
		auth_debug: { type: 'debug' }                                                                                        // 13
	}                                                                                                                     //
});                                                                                                                    //
                                                                                                                       //
LDAP = (function () {                                                                                                  // 17
	function LDAP(options) {                                                                                              // 18
		babelHelpers.classCallCheck(this, LDAP);                                                                             //
                                                                                                                       //
		var self = this;                                                                                                     // 19
                                                                                                                       //
		self.ldapjs = ldapjs;                                                                                                // 21
                                                                                                                       //
		self.connected = false;                                                                                              // 23
                                                                                                                       //
		self.options = {                                                                                                     // 25
			host: RocketChat.settings.get('LDAP_Host'),                                                                         // 26
			port: RocketChat.settings.get('LDAP_Port'),                                                                         // 27
			encryption: RocketChat.settings.get('LDAP_Encryption'),                                                             // 28
			ca_cert: RocketChat.settings.get('LDAP_CA_Cert'),                                                                   // 29
			reject_unauthorized: RocketChat.settings.get('LDAP_Reject_Unauthorized') || false,                                  // 30
			domain_base: RocketChat.settings.get('LDAP_Domain_Base'),                                                           // 31
			use_custom_domain_search: RocketChat.settings.get('LDAP_Use_Custom_Domain_Search'),                                 // 32
			custom_domain_search: RocketChat.settings.get('LDAP_Custom_Domain_Search'),                                         // 33
			domain_search_user: RocketChat.settings.get('LDAP_Domain_Search_User'),                                             // 34
			domain_search_password: RocketChat.settings.get('LDAP_Domain_Search_Password'),                                     // 35
			domain_search_filter: RocketChat.settings.get('LDAP_Domain_Search_Filter'),                                         // 36
			domain_search_user_id: RocketChat.settings.get('LDAP_Domain_Search_User_ID'),                                       // 37
			domain_search_object_class: RocketChat.settings.get('LDAP_Domain_Search_Object_Class'),                             // 38
			domain_search_object_category: RocketChat.settings.get('LDAP_Domain_Search_Object_Category')                        // 39
		};                                                                                                                   //
                                                                                                                       //
		self.connectSync = Meteor.wrapAsync(self.connectAsync, self);                                                        // 42
		self.searchAllSync = Meteor.wrapAsync(self.searchAllAsync, self);                                                    // 43
	}                                                                                                                     //
                                                                                                                       //
	LDAP.prototype.connectAsync = (function () {                                                                          // 17
		function connectAsync(callback) {                                                                                    // 46
			var self = this;                                                                                                    // 47
                                                                                                                       //
			logger.connection_info('Init setup');                                                                               // 49
                                                                                                                       //
			var replied = false;                                                                                                // 51
                                                                                                                       //
			var connectionOptions = {                                                                                           // 53
				url: self.options.host + ':' + self.options.port,                                                                  // 54
				timeout: 1000 * 5,                                                                                                 // 55
				connectTimeout: 1000 * 10,                                                                                         // 56
				idleTimeout: 1000 * 10,                                                                                            // 57
				reconnect: false                                                                                                   // 58
			};                                                                                                                  //
                                                                                                                       //
			var tlsOptions = {                                                                                                  // 61
				rejectUnauthorized: self.options.reject_unauthorized                                                               // 62
			};                                                                                                                  //
                                                                                                                       //
			if (self.options.ca_cert && self.options.ca_cert !== '') {                                                          // 65
				// Split CA cert into array of strings                                                                             //
				var chainLines = RocketChat.settings.get('LDAP_CA_Cert').split("\n");                                              // 67
				var cert = [];                                                                                                     // 68
				var ca = [];                                                                                                       // 69
				chainLines.forEach(function (line) {                                                                               // 70
					cert.push(line);                                                                                                  // 71
					if (line.match(/-END CERTIFICATE-/)) {                                                                            // 72
						ca.push(cert.join("\n"));                                                                                        // 73
						cert = [];                                                                                                       // 74
					}                                                                                                                 //
				});                                                                                                                //
				tlsOptions.ca = ca;                                                                                                // 77
			}                                                                                                                   //
                                                                                                                       //
			if (self.options.encryption === 'ssl') {                                                                            // 80
				connectionOptions.url = 'ldaps://' + connectionOptions.url;                                                        // 81
				connectionOptions.tlsOptions = tlsOptions;                                                                         // 82
			} else {                                                                                                            //
				connectionOptions.url = 'ldap://' + connectionOptions.url;                                                         // 84
			}                                                                                                                   //
                                                                                                                       //
			logger.connection_info('Connecting', connectionOptions.url);                                                        // 87
			logger.connection_debug('connectionOptions', connectionOptions);                                                    // 88
                                                                                                                       //
			self.client = ldapjs.createClient(connectionOptions);                                                               // 90
                                                                                                                       //
			self.bindSync = Meteor.wrapAsync(self.client.bind, self.client);                                                    // 92
                                                                                                                       //
			self.client.on('error', function (error) {                                                                          // 94
				logger.connection_error('connection', error);                                                                      // 95
				if (replied === false) {                                                                                           // 96
					replied = true;                                                                                                   // 97
					callback(error, null);                                                                                            // 98
				}                                                                                                                  //
			});                                                                                                                 //
                                                                                                                       //
			if (self.options.encryption === 'tls') {                                                                            // 102
				logger.connection_info('Starting TLS');                                                                            // 103
				logger.connection_debug('tlsOptions', tlsOptions);                                                                 // 104
                                                                                                                       //
				self.client.starttls(tlsOptions, null, function (error, response) {                                                // 106
					if (error) {                                                                                                      // 107
						logger.connection_error('TLS connection', error);                                                                // 108
						if (replied === false) {                                                                                         // 109
							replied = true;                                                                                                 // 110
							callback(error, null);                                                                                          // 111
						}                                                                                                                //
						return;                                                                                                          // 113
					}                                                                                                                 //
                                                                                                                       //
					logger.connection_info('TLS connected');                                                                          // 116
					self.connected = true;                                                                                            // 117
					if (replied === false) {                                                                                          // 118
						replied = true;                                                                                                  // 119
						callback(null, response);                                                                                        // 120
					}                                                                                                                 //
				});                                                                                                                //
			} else {                                                                                                            //
				self.client.on('connect', function (response) {                                                                    // 124
					logger.connection_info('LDAP connected');                                                                         // 125
					self.connected = true;                                                                                            // 126
					if (replied === false) {                                                                                          // 127
						replied = true;                                                                                                  // 128
						callback(null, response);                                                                                        // 129
					}                                                                                                                 //
				});                                                                                                                //
			}                                                                                                                   //
                                                                                                                       //
			setTimeout(function () {                                                                                            // 134
				if (replied === false) {                                                                                           // 135
					logger.connection_error('connection time out', connectionOptions.timeout);                                        // 136
					replied = true;                                                                                                   // 137
					callback(new Error('Timeout'));                                                                                   // 138
				}                                                                                                                  //
			}, connectionOptions.timeout);                                                                                      //
		}                                                                                                                    //
                                                                                                                       //
		return connectAsync;                                                                                                 //
	})();                                                                                                                 //
                                                                                                                       //
	LDAP.prototype.getDomainBindSearch = (function () {                                                                   // 17
		function getDomainBindSearch() {                                                                                     // 143
			var self = this;                                                                                                    // 144
                                                                                                                       //
			if (self.options.use_custom_domain_search === true) {                                                               // 146
				var custom_domain_search = undefined;                                                                              // 147
				try {                                                                                                              // 148
					custom_domain_search = JSON.parse(self.options.custom_domain_search);                                             // 149
				} catch (error) {                                                                                                  //
					throw new Error('Invalid Custom Domain Search JSON');                                                             // 151
				}                                                                                                                  //
                                                                                                                       //
				return {                                                                                                           // 154
					filter: custom_domain_search.filter,                                                                              // 155
					domain_search_user: custom_domain_search.userDN || '',                                                            // 156
					domain_search_password: custom_domain_search.password || ''                                                       // 157
				};                                                                                                                 //
			}                                                                                                                   //
                                                                                                                       //
			var filter = ['(&'];                                                                                                // 161
                                                                                                                       //
			if (self.options.domain_search_object_category !== '') {                                                            // 163
				filter.push('(objectCategory=' + self.options.domain_search_object_category + ')');                                // 164
			}                                                                                                                   //
                                                                                                                       //
			if (self.options.domain_search_object_class !== '') {                                                               // 167
				filter.push('(objectclass=' + self.options.domain_search_object_class + ')');                                      // 168
			}                                                                                                                   //
                                                                                                                       //
			if (self.options.domain_search_filter !== '') {                                                                     // 171
				filter.push('(' + self.options.domain_search_filter + ')');                                                        // 172
			}                                                                                                                   //
                                                                                                                       //
			domain_search_user_id = self.options.domain_search_user_id.split(',');                                              // 175
			if (domain_search_user_id.length === 1) {                                                                           // 176
				filter.push('(' + domain_search_user_id[0] + '=#{username})');                                                     // 177
			} else {                                                                                                            //
				filter.push('(|');                                                                                                 // 179
				domain_search_user_id.forEach(function (item) {                                                                    // 180
					filter.push('(' + item + '=#{username})');                                                                        // 181
				});                                                                                                                //
				filter.push(')');                                                                                                  // 183
			}                                                                                                                   //
                                                                                                                       //
			filter.push(')');                                                                                                   // 186
                                                                                                                       //
			return {                                                                                                            // 188
				filter: filter.join(''),                                                                                           // 189
				domain_search_user: self.options.domain_search_user || '',                                                         // 190
				domain_search_password: self.options.domain_search_password || ''                                                  // 191
			};                                                                                                                  //
		}                                                                                                                    //
                                                                                                                       //
		return getDomainBindSearch;                                                                                          //
	})();                                                                                                                 //
                                                                                                                       //
	LDAP.prototype.bindIfNecessary = (function () {                                                                       // 17
		function bindIfNecessary() {                                                                                         // 195
			var self = this;                                                                                                    // 196
                                                                                                                       //
			var domain_search = self.getDomainBindSearch();                                                                     // 198
                                                                                                                       //
			if (domain_search.domain_search_user !== '' && domain_search.domain_search_password !== '') {                       // 200
				logger.bind_info('Binding admin user', domain_search.domain_search_user);                                          // 201
				self.bindSync(domain_search.domain_search_user, domain_search.domain_search_password);                             // 202
			}                                                                                                                   //
		}                                                                                                                    //
                                                                                                                       //
		return bindIfNecessary;                                                                                              //
	})();                                                                                                                 //
                                                                                                                       //
	LDAP.prototype.searchUsersSync = (function () {                                                                       // 17
		function searchUsersSync(username) {                                                                                 // 206
			var self = this;                                                                                                    // 207
                                                                                                                       //
			self.bindIfNecessary();                                                                                             // 209
                                                                                                                       //
			var domain_search = self.getDomainBindSearch();                                                                     // 211
                                                                                                                       //
			var searchOptions = {                                                                                               // 213
				filter: domain_search.filter.replace(/#{username}/g, username),                                                    // 214
				scope: 'sub'                                                                                                       // 215
			};                                                                                                                  //
                                                                                                                       //
			logger.search_info('Searching user', username);                                                                     // 218
			logger.search_debug('searchOptions', searchOptions);                                                                // 219
			logger.search_debug('domain_base', self.options.domain_base);                                                       // 220
                                                                                                                       //
			return self.searchAllSync(self.options.domain_base, searchOptions);                                                 // 222
		}                                                                                                                    //
                                                                                                                       //
		return searchUsersSync;                                                                                              //
	})();                                                                                                                 //
                                                                                                                       //
	LDAP.prototype.searchAllAsync = (function () {                                                                        // 17
		function searchAllAsync(domain_base, options, callback) {                                                            // 225
			var self = this;                                                                                                    // 226
                                                                                                                       //
			self.client.search(domain_base, options, function (error, res) {                                                    // 228
				if (error) {                                                                                                       // 229
					logger.search_error(error);                                                                                       // 230
					callback(error);                                                                                                  // 231
					return;                                                                                                           // 232
				}                                                                                                                  //
                                                                                                                       //
				res.on('error', function (error) {                                                                                 // 235
					logger.search_error(error);                                                                                       // 236
					callback(error);                                                                                                  // 237
					return;                                                                                                           // 238
				});                                                                                                                //
                                                                                                                       //
				var entries = [];                                                                                                  // 241
                                                                                                                       //
				res.on('searchEntry', function (entry) {                                                                           // 243
					entries.push(entry);                                                                                              // 244
				});                                                                                                                //
                                                                                                                       //
				res.on('end', function (result) {                                                                                  // 247
					logger.search_info('Search result count', entries.length);                                                        // 248
					logger.search_debug('Search result', entries);                                                                    // 249
					callback(null, entries);                                                                                          // 250
				});                                                                                                                //
			});                                                                                                                 //
		}                                                                                                                    //
                                                                                                                       //
		return searchAllAsync;                                                                                               //
	})();                                                                                                                 //
                                                                                                                       //
	LDAP.prototype.authSync = (function () {                                                                              // 17
		function authSync(dn, password) {                                                                                    // 255
			var self = this;                                                                                                    // 256
                                                                                                                       //
			logger.auth_info('Authenticating', dn);                                                                             // 258
                                                                                                                       //
			try {                                                                                                               // 260
				self.bindSync(dn, password);                                                                                       // 261
				logger.auth_info('Authenticated', dn);                                                                             // 262
				return true;                                                                                                       // 263
			} catch (error) {                                                                                                   //
				logger.auth_info('Not authenticated', dn);                                                                         // 265
				logger.auth_debug('error', error);                                                                                 // 266
				return false;                                                                                                      // 267
			}                                                                                                                   //
		}                                                                                                                    //
                                                                                                                       //
		return authSync;                                                                                                     //
	})();                                                                                                                 //
                                                                                                                       //
	LDAP.prototype.disconnect = (function () {                                                                            // 17
		function disconnect() {                                                                                              // 271
			var self = this;                                                                                                    // 272
                                                                                                                       //
			self.connected = false;                                                                                             // 274
			logger.connection_info('Disconecting');                                                                             // 275
			self.client.unbind();                                                                                               // 276
		}                                                                                                                    //
                                                                                                                       //
		return disconnect;                                                                                                   //
	})();                                                                                                                 //
                                                                                                                       //
	return LDAP;                                                                                                          //
})();                                                                                                                  //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_ldap/server/loginHandler.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var logger = new Logger('LDAPHandler', {});                                                                            // 1
                                                                                                                       //
var slug = function (text) {                                                                                           // 3
	if (RocketChat.settings.get('UTF8_Names_Slugify') !== true) {                                                         // 4
		return text;                                                                                                         // 5
	}                                                                                                                     //
	text = slugify(text, '.');                                                                                            // 7
	return text.replace(/[^0-9a-z-_.]/g, '');                                                                             // 8
};                                                                                                                     //
                                                                                                                       //
function fallbackDefaultAccountSystem(bind, username, password) {                                                      // 11
	if (typeof username === 'string') if (username.indexOf('@') === -1) username = { username: username };else username = { email: username };
                                                                                                                       //
	logger.info('Fallback to default account systen', username);                                                          // 18
                                                                                                                       //
	loginRequest = {                                                                                                      // 20
		user: username,                                                                                                      // 21
		password: {                                                                                                          // 22
			digest: SHA256(password),                                                                                           // 23
			algorithm: "sha-256"                                                                                                // 24
		}                                                                                                                    //
	};                                                                                                                    //
                                                                                                                       //
	return Accounts._runLoginHandlers(bind, loginRequest);                                                                // 28
}                                                                                                                      //
                                                                                                                       //
function getDataToSyncUserData(ldapUser) {                                                                             // 31
	var syncUserData = RocketChat.settings.get('LDAP_Sync_User_Data');                                                    // 32
	var syncUserDataFieldMap = RocketChat.settings.get('LDAP_Sync_User_Data_FieldMap').trim();                            // 33
                                                                                                                       //
	if (syncUserData && syncUserDataFieldMap) {                                                                           // 35
		var _ret = (function () {                                                                                            //
			var fieldMap = JSON.parse(syncUserDataFieldMap);                                                                    // 36
			var userData = {};                                                                                                  // 37
                                                                                                                       //
			var emailList = [];                                                                                                 // 39
			_.map(fieldMap, function (userField, ldapField) {                                                                   // 40
				if (!ldapUser.object.hasOwnProperty(ldapField)) {                                                                  // 41
					return;                                                                                                           // 42
				}                                                                                                                  //
                                                                                                                       //
				switch (userField) {                                                                                               // 45
					case 'email':                                                                                                     // 46
						if (_.isObject(ldapUser.object[ldapField] === 'object')) {                                                       // 47
							_.map(ldapUser.object[ldapField], function (item) {                                                             // 48
								emailList.push({ address: item, verified: true });                                                             // 49
							});                                                                                                             //
						} else {                                                                                                         //
							emailList.push({ address: ldapUser.object[ldapField], verified: true });                                        // 52
						}                                                                                                                //
						break;                                                                                                           // 54
                                                                                                                       //
					case 'name':                                                                                                      // 54
						userData.name = ldapUser.object[ldapField];                                                                      // 57
						break;                                                                                                           // 58
				}                                                                                                                  // 58
			});                                                                                                                 //
                                                                                                                       //
			if (emailList.length > 0) {                                                                                         // 62
				userData.emails = emailList;                                                                                       // 63
			}                                                                                                                   //
                                                                                                                       //
			if (_.size(userData)) {                                                                                             // 66
				return {                                                                                                           // 67
					v: userData                                                                                                       //
				};                                                                                                                 //
			}                                                                                                                   //
		})();                                                                                                                //
                                                                                                                       //
		if (typeof _ret === 'object') return _ret.v;                                                                         //
	}                                                                                                                     //
}                                                                                                                      //
                                                                                                                       //
function syncUserData(user, ldapUser) {                                                                                // 72
	logger.info('Syncing user data');                                                                                     // 73
	logger.debug('user', user);                                                                                           // 74
	logger.debug('ldapUser', ldapUser);                                                                                   // 75
                                                                                                                       //
	var userData = getDataToSyncUserData(ldapUser);                                                                       // 77
	if (user && user._id && userData) {                                                                                   // 78
		Meteor.users.update(user._id, { $set: userData });                                                                   // 79
	}                                                                                                                     //
                                                                                                                       //
	if (user && user._id) {                                                                                               // 82
		var avatar = ldapUser.raw.thumbnailPhoto || ldapUser.raw.jpegPhoto;                                                  // 83
		if (avatar) {                                                                                                        // 84
			logger.info('Syncing user avatar');                                                                                 // 85
			var rs = RocketChatFile.bufferToStream(avatar);                                                                     // 86
			RocketChatFileAvatarInstance.deleteFile(encodeURIComponent(user.username + '.jpg'));                                // 87
			var ws = RocketChatFileAvatarInstance.createWriteStream(encodeURIComponent(user.username + '.jpg'), 'image/jpeg');  // 88
			ws.on('end', Meteor.bindEnvironment(function () {                                                                   // 89
				Meteor.setTimeout(function () {                                                                                    // 90
					RocketChat.models.Users.setAvatarOrigin(user._id, 'ldap');                                                        // 91
					RocketChat.Notifications.notifyAll('updateAvatar', { username: user.username });                                  // 92
				}, 500);                                                                                                           //
			}));                                                                                                                //
			rs.pipe(ws);                                                                                                        // 95
		}                                                                                                                    //
	}                                                                                                                     //
}                                                                                                                      //
                                                                                                                       //
function getLdapUserUniqueID(ldapUser, fallback) {                                                                     // 100
	var Unique_Identifier_Field = RocketChat.settings.get('LDAP_Unique_Identifier_Field');                                // 101
                                                                                                                       //
	if (Unique_Identifier_Field !== '') {                                                                                 // 103
		Unique_Identifier_Field = Unique_Identifier_Field.split(',').find(function (field) {                                 // 104
			return !_.isEmpty(ldapUser.object[field]);                                                                          // 105
		});                                                                                                                  //
		if (Unique_Identifier_Field) {                                                                                       // 107
			Unique_Identifier_Field = ldapUser.raw[Unique_Identifier_Field].toString('hex');                                    // 108
		}                                                                                                                    //
		return Unique_Identifier_Field || fallback;                                                                          // 110
	}                                                                                                                     //
}                                                                                                                      //
                                                                                                                       //
Accounts.registerLoginHandler("ldap", function (loginRequest) {                                                        // 114
	var self = this;                                                                                                      // 115
                                                                                                                       //
	if (!loginRequest.ldapOptions) {                                                                                      // 117
		return undefined;                                                                                                    // 118
	}                                                                                                                     //
                                                                                                                       //
	logger.info('Init login', loginRequest.username);                                                                     // 121
                                                                                                                       //
	if (RocketChat.settings.get('LDAP_Enable') !== true) {                                                                // 123
		return fallbackDefaultAccountSystem(self, loginRequest.username, loginRequest.ldapPass);                             // 124
	}                                                                                                                     //
                                                                                                                       //
	var ldap = new LDAP();                                                                                                // 127
	var ldapUser = undefined;                                                                                             // 128
                                                                                                                       //
	try {                                                                                                                 // 130
		ldap.connectSync();                                                                                                  // 131
		users = ldap.searchUsersSync(loginRequest.username);                                                                 // 132
                                                                                                                       //
		if (users.length !== 1) {                                                                                            // 134
			logger.info('Search returned', users.length, 'record(s) for', loginRequest.username);                               // 135
			throw new Error('User not Found');                                                                                  // 136
		}                                                                                                                    //
                                                                                                                       //
		if (ldap.authSync(users[0].dn, loginRequest.ldapPass) === true) {                                                    // 139
			ldapUser = users[0];                                                                                                // 140
		} else {                                                                                                             //
			logger.info('Wrong password for', loginRequest.username);                                                           // 142
		}                                                                                                                    //
	} catch (error) {                                                                                                     //
		logger.error(error);                                                                                                 // 145
	}                                                                                                                     //
                                                                                                                       //
	ldap.disconnect();                                                                                                    // 148
                                                                                                                       //
	if (ldapUser === undefined) {                                                                                         // 150
		return fallbackDefaultAccountSystem(self, loginRequest.username, loginRequest.ldapPass);                             // 151
	}                                                                                                                     //
                                                                                                                       //
	var username = undefined;                                                                                             // 154
                                                                                                                       //
	if (RocketChat.settings.get('LDAP_Username_Field') !== '') {                                                          // 156
		username = slug(ldapUser.object[RocketChat.settings.get('LDAP_Username_Field')]);                                    // 157
	} else {                                                                                                              //
		username = slug(loginRequest.username);                                                                              // 159
	}                                                                                                                     //
                                                                                                                       //
	// Look to see if user already exists                                                                                 //
	var userQuery = undefined;                                                                                            // 163
                                                                                                                       //
	var Unique_Identifier_Field = getLdapUserUniqueID(ldapUser, username);                                                // 165
	if (Unique_Identifier_Field) {                                                                                        // 166
		userQuery = {                                                                                                        // 167
			'services.ldap.id': Unique_Identifier_Field                                                                         // 168
		};                                                                                                                   //
	} else {                                                                                                              //
		userQuery = {                                                                                                        // 171
			username: username                                                                                                  // 172
		};                                                                                                                   //
	}                                                                                                                     //
                                                                                                                       //
	logger.info('Querying user');                                                                                         // 176
	logger.debug('userQuery', userQuery);                                                                                 // 177
                                                                                                                       //
	var user = Meteor.users.findOne(userQuery);                                                                           // 179
                                                                                                                       //
	// Login user if they exist                                                                                           //
	if (user) {                                                                                                           // 182
		if (user.ldap !== true) {                                                                                            // 183
			logger.info('User exists without "ldap: true"');                                                                    // 184
			throw new Meteor.Error("LDAP-login-error", "LDAP Authentication succeded, but there's already an existing user with provided username [" + username + "] in Mongo.");
		}                                                                                                                    //
                                                                                                                       //
		logger.info('Logging user');                                                                                         // 188
                                                                                                                       //
		var stampedToken = Accounts._generateStampedLoginToken();                                                            // 190
		var hashStampedToken = Meteor.users.update(user._id, {                                                               // 191
			$push: {                                                                                                            // 193
				'services.resume.loginTokens': Accounts._hashStampedToken(stampedToken)                                            // 194
			}                                                                                                                   //
		});                                                                                                                  //
                                                                                                                       //
		syncUserData(user, ldapUser, loginRequest.ldapPass);                                                                 // 198
		Accounts.setPassword(user._id, loginRequest.ldapPass, { logout: false });                                            // 199
		return {                                                                                                             // 200
			userId: user._id,                                                                                                   // 201
			token: stampedToken.token                                                                                           // 202
		};                                                                                                                   //
	}                                                                                                                     //
                                                                                                                       //
	logger.info('User does not exists, creating', username);                                                              // 206
	// Create new user                                                                                                    //
	var userObject = {                                                                                                    // 208
		username: username,                                                                                                  // 209
		password: loginRequest.ldapPass                                                                                      // 210
	};                                                                                                                    //
                                                                                                                       //
	var userData = getDataToSyncUserData(ldapUser);                                                                       // 213
                                                                                                                       //
	if (userData && userData.emails) {                                                                                    // 215
		userObject.email = userData.emails[0].address;                                                                       // 216
	} else if (ldapUser.object.mail && ldapUser.object.mail.indexOf('@') > -1) {                                          //
		userObject.email = ldapUser.object.mail;                                                                             // 218
	} else if (RocketChat.settings.get('LDAP_Default_Domain') !== '') {                                                   //
		userObject.email = username + '@' + RocketChat.settings.get('LDAP_Default_Domain');                                  // 220
	} else {                                                                                                              //
		throw new Meteor.Error("LDAP-login-error", "LDAP Authentication succeded, there is no email to create an account.");
	}                                                                                                                     //
                                                                                                                       //
	userObject._id = Accounts.createUser(userObject);                                                                     // 225
                                                                                                                       //
	syncUserData(userObject, ldapUser, loginRequest.ldapPass);                                                            // 227
                                                                                                                       //
	var ldapUserService = {                                                                                               // 229
		ldap: true                                                                                                           // 230
	};                                                                                                                    //
                                                                                                                       //
	if (Unique_Identifier_Field) {                                                                                        // 233
		ldapUserService['services.ldap.id'] = Unique_Identifier_Field;                                                       // 234
	}                                                                                                                     //
                                                                                                                       //
	Meteor.users.update(userObject._id, {                                                                                 // 237
		$set: ldapUserService                                                                                                // 238
	});                                                                                                                   //
                                                                                                                       //
	logger.info('Joining user to default channels');                                                                      // 241
	Meteor.runAsUser(userObject._id, function () {                                                                        // 242
		Meteor.call('joinDefaultChannels');                                                                                  // 243
	});                                                                                                                   //
                                                                                                                       //
	return {                                                                                                              // 246
		userId: userObject._id                                                                                               // 247
	};                                                                                                                    //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_ldap/server/settings.coffee.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.startup(function() {                                                                                            // 1
  return RocketChat.settings.addGroup('LDAP', function() {                                                             //
    var customBindSearchDisabledQuery, customBindSearchEnabledQuery, enableQuery, enableTLSQuery, syncDataQuery;       // 3
    enableQuery = {                                                                                                    // 3
      _id: 'LDAP_Enable',                                                                                              // 3
      value: true                                                                                                      // 3
    };                                                                                                                 //
    enableTLSQuery = [                                                                                                 // 3
      {                                                                                                                //
        _id: 'LDAP_Enable',                                                                                            // 5
        value: true                                                                                                    // 5
      }, {                                                                                                             //
        _id: 'LDAP_Encryption',                                                                                        // 6
        value: {                                                                                                       // 6
          $in: ['tls', 'ssl']                                                                                          // 6
        }                                                                                                              //
      }                                                                                                                //
    ];                                                                                                                 //
    customBindSearchEnabledQuery = [                                                                                   // 3
      {                                                                                                                //
        _id: 'LDAP_Enable',                                                                                            // 9
        value: true                                                                                                    // 9
      }, {                                                                                                             //
        _id: 'LDAP_Use_Custom_Domain_Search',                                                                          // 10
        value: true                                                                                                    // 10
      }                                                                                                                //
    ];                                                                                                                 //
    customBindSearchDisabledQuery = [                                                                                  // 3
      {                                                                                                                //
        _id: 'LDAP_Enable',                                                                                            // 13
        value: true                                                                                                    // 13
      }, {                                                                                                             //
        _id: 'LDAP_Use_Custom_Domain_Search',                                                                          // 14
        value: false                                                                                                   // 14
      }                                                                                                                //
    ];                                                                                                                 //
    syncDataQuery = [                                                                                                  // 3
      {                                                                                                                //
        _id: 'LDAP_Enable',                                                                                            // 17
        value: true                                                                                                    // 17
      }, {                                                                                                             //
        _id: 'LDAP_Sync_User_Data',                                                                                    // 18
        value: true                                                                                                    // 18
      }                                                                                                                //
    ];                                                                                                                 //
    this.add('LDAP_Enable', false, {                                                                                   // 3
      type: 'boolean',                                                                                                 // 21
      "public": true                                                                                                   // 21
    });                                                                                                                //
    this.add('LDAP_Host', '', {                                                                                        // 3
      type: 'string',                                                                                                  // 22
      enableQuery: enableQuery                                                                                         // 22
    });                                                                                                                //
    this.add('LDAP_Port', '389', {                                                                                     // 3
      type: 'string',                                                                                                  // 23
      enableQuery: enableQuery                                                                                         // 23
    });                                                                                                                //
    this.add('LDAP_Encryption', 'plain', {                                                                             // 3
      type: 'select',                                                                                                  // 24
      values: [                                                                                                        // 24
        {                                                                                                              //
          key: 'plain',                                                                                                // 24
          i18nLabel: 'No_Encryption'                                                                                   // 24
        }, {                                                                                                           //
          key: 'tls',                                                                                                  // 24
          i18nLabel: 'StartTLS'                                                                                        // 24
        }, {                                                                                                           //
          key: 'ssl',                                                                                                  // 24
          i18nLabel: 'SSL/LDAPS'                                                                                       // 24
        }                                                                                                              //
      ],                                                                                                               //
      enableQuery: enableQuery                                                                                         // 24
    });                                                                                                                //
    this.add('LDAP_CA_Cert', '', {                                                                                     // 3
      type: 'string',                                                                                                  // 25
      multiline: true,                                                                                                 // 25
      enableQuery: enableTLSQuery                                                                                      // 25
    });                                                                                                                //
    this.add('LDAP_Reject_Unauthorized', true, {                                                                       // 3
      type: 'boolean',                                                                                                 // 26
      enableQuery: enableTLSQuery                                                                                      // 26
    });                                                                                                                //
    this.add('LDAP_Domain_Base', '', {                                                                                 // 3
      type: 'string',                                                                                                  // 27
      enableQuery: enableQuery                                                                                         // 27
    });                                                                                                                //
    this.add('LDAP_Use_Custom_Domain_Search', false, {                                                                 // 3
      type: 'boolean',                                                                                                 // 28
      enableQuery: enableQuery                                                                                         // 28
    });                                                                                                                //
    this.add('LDAP_Custom_Domain_Search', '', {                                                                        // 3
      type: 'string',                                                                                                  // 29
      enableQuery: customBindSearchEnabledQuery                                                                        // 29
    });                                                                                                                //
    this.add('LDAP_Domain_Search_User', '', {                                                                          // 3
      type: 'string',                                                                                                  // 30
      enableQuery: customBindSearchDisabledQuery                                                                       // 30
    });                                                                                                                //
    this.add('LDAP_Domain_Search_Password', '', {                                                                      // 3
      type: 'password',                                                                                                // 31
      enableQuery: customBindSearchDisabledQuery                                                                       // 31
    });                                                                                                                //
    this.add('LDAP_Domain_Search_Filter', '', {                                                                        // 3
      type: 'string',                                                                                                  // 32
      enableQuery: customBindSearchDisabledQuery                                                                       // 32
    });                                                                                                                //
    this.add('LDAP_Domain_Search_User_ID', 'sAMAccountName', {                                                         // 3
      type: 'string',                                                                                                  // 33
      enableQuery: customBindSearchDisabledQuery                                                                       // 33
    });                                                                                                                //
    this.add('LDAP_Domain_Search_Object_Class', 'user', {                                                              // 3
      type: 'string',                                                                                                  // 34
      enableQuery: customBindSearchDisabledQuery                                                                       // 34
    });                                                                                                                //
    this.add('LDAP_Domain_Search_Object_Category', 'person', {                                                         // 3
      type: 'string',                                                                                                  // 35
      enableQuery: customBindSearchDisabledQuery                                                                       // 35
    });                                                                                                                //
    this.add('LDAP_Username_Field', 'sAMAccountName', {                                                                // 3
      type: 'string',                                                                                                  // 36
      enableQuery: enableQuery                                                                                         // 36
    });                                                                                                                //
    this.add('LDAP_Unique_Identifier_Field', 'objectGUID,ibm-entryUUID,GUID,dominoUNID,nsuniqueId,uidNumber', {        // 3
      type: 'string',                                                                                                  // 37
      enableQuery: enableQuery                                                                                         // 37
    });                                                                                                                //
    this.add('LDAP_Sync_User_Data', false, {                                                                           // 3
      type: 'boolean',                                                                                                 // 38
      enableQuery: enableQuery                                                                                         // 38
    });                                                                                                                //
    this.add('LDAP_Sync_User_Data_FieldMap', '{"cn":"name", "mail":"email"}', {                                        // 3
      type: 'string',                                                                                                  // 39
      enableQuery: syncDataQuery                                                                                       // 39
    });                                                                                                                //
    this.add('LDAP_Default_Domain', '', {                                                                              // 3
      type: 'string',                                                                                                  // 40
      enableQuery: enableQuery                                                                                         // 40
    });                                                                                                                //
    return this.add('LDAP_Test_Connection', 'ldap_test_connection', {                                                  //
      type: 'action',                                                                                                  // 41
      actionText: 'Test_Connection'                                                                                    // 41
    });                                                                                                                //
  });                                                                                                                  //
});                                                                                                                    // 1
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_ldap/server/testConnection.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({                                                                                                       // 1
	ldap_test_connection: function () {                                                                                   // 2
		user = Meteor.user();                                                                                                // 3
		if (!user) {                                                                                                         // 4
			throw new Meteor.Error('unauthorized', '[methods] ldap_test_connection -> Unauthorized');                           // 5
		}                                                                                                                    //
                                                                                                                       //
		if (!RocketChat.authz.hasRole(user._id, 'admin')) {                                                                  // 8
			throw new Meteor.Error('unauthorized', '[methods] ldap_test_connection -> Unauthorized');                           // 9
		}                                                                                                                    //
                                                                                                                       //
		if (RocketChat.settings.get('LDAP_Enable') !== true) {                                                               // 12
			throw new Meteor.Error('LDAP_disabled');                                                                            // 13
		}                                                                                                                    //
                                                                                                                       //
		var ldap = undefined;                                                                                                // 16
		try {                                                                                                                // 17
			ldap = new LDAP();                                                                                                  // 18
			ldap.connectSync();                                                                                                 // 19
		} catch (error) {                                                                                                    //
			console.log(error);                                                                                                 // 21
			throw new Meteor.Error(error.message);                                                                              // 22
		}                                                                                                                    //
                                                                                                                       //
		try {                                                                                                                // 25
			ldap.bindIfNecessary();                                                                                             // 26
			ldap.disconnect();                                                                                                  // 27
		} catch (error) {                                                                                                    //
			throw new Meteor.Error(error.name || error.message);                                                                // 29
		}                                                                                                                    //
                                                                                                                       //
		return {                                                                                                             // 32
			message: "Connection_success",                                                                                      // 33
			params: []                                                                                                          // 34
		};                                                                                                                   //
	}                                                                                                                     //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:ldap'] = {
  LDAP: LDAP
};

})();

//# sourceMappingURL=rocketchat_ldap.js.map
