(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var colors;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/nooitaf_colors/packages/nooitaf_colors.js                     //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {                                                            // 1
                                                                          // 2
///////////////////////////////////////////////////////////////////////   // 3
//                                                                   //   // 4
// packages/nooitaf:colors/export-colors.js                          //   // 5
//                                                                   //   // 6
///////////////////////////////////////////////////////////////////////   // 7
                                                                     //   // 8
var colors = Npm.require('colors');                                  // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////   // 11
                                                                          // 12
}).call(this);                                                            // 13
                                                                          // 14
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nooitaf:colors'] = {
  colors: colors
};

})();

//# sourceMappingURL=nooitaf_colors.js.map
