(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var RocketChat = Package['rocketchat:lib'].RocketChat;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                          //
// packages/rocketchat_tutum/startup.coffee.js                                              //
//                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////
                                                                                            //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                            // 1
/* Examples                                                                                 // 1
                                                                                            //
TUTUM_REDIS_HOST=redis://:password@host:6379                                                //
TUTUM_CLIENT_NAME=mywebsite                                                                 //
TUTUM_CLIENT_HOST=mywebsite.dotcloud.com                                                    //
 */                                                                                         //
var client, day, inactiveDays, redis, terminateAppIfInactive;                               // 1
                                                                                            //
if (process.env.TUTUM_REDIS_HOST != null) {                                                 // 8
  redis = Npm.require('redis');                                                             // 9
  client = redis.createClient(process.env.TUTUM_REDIS_HOST);                                // 9
  client.del("frontend:" + process.env.TUTUM_CLIENT_HOST);                                  // 9
  client.rpush("frontend:" + process.env.TUTUM_CLIENT_HOST, process.env.TUTUM_CLIENT_NAME);
  client.rpush("frontend:" + process.env.TUTUM_CLIENT_HOST, "http://" + (process.env.TUTUM_IP_ADDRESS.split('/')[0]) + ":3000");
  day = 86400000;                                                                           // 9
  inactiveDays = 30;                                                                        // 9
  if (!isNaN(parseInt(process.env.TUTUM_REDIS_INACTIVE_DAYS))) {                            // 21
    inactiveDays = parseInt(process.env.TUTUM_REDIS_INACTIVE_DAYS);                         // 22
  }                                                                                         //
  terminateAppIfInactive = function() {                                                     // 9
    var subscription;                                                                       // 25
    subscription = RocketChat.models.Subscriptions.findOne({                                // 25
      ls: {                                                                                 // 25
        $exists: true                                                                       // 25
      }                                                                                     //
    }, {                                                                                    //
      sort: {                                                                               // 25
        ls: -1                                                                              // 25
      },                                                                                    //
      fields: {                                                                             // 25
        ls: 1                                                                               // 25
      }                                                                                     //
    });                                                                                     //
    if ((subscription == null) || Date.now() - subscription.ls > inactiveDays * day) {      // 27
      client.del("frontend:" + process.env.TUTUM_CLIENT_HOST);                              // 28
      return process.exit(0);                                                               //
    }                                                                                       //
  };                                                                                        //
  Meteor.setInterval(function() {                                                           // 9
    var now;                                                                                // 32
    now = new Date();                                                                       // 32
    if (now.getHours() === 4 && now.getMinutes() === 0) {                                   // 33
      return terminateAppIfInactive();                                                      //
    }                                                                                       //
  }, 60000);                                                                                //
}                                                                                           //
                                                                                            //
//////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:tutum'] = {};

})();

//# sourceMappingURL=rocketchat_tutum.js.map
