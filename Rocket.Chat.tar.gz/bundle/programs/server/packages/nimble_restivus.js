(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var JsonRoutes = Package['simple:json-routes'].JsonRoutes;

/* Package-scope variables */
var __coffeescriptShare, ironRouterSendErrorToResponse, msg, Restivus;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nimble_restivus/packages/nimble_restivus.js                                                              //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
(function () {                                                                                                       // 1
                                                                                                                     // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nimble:restivus/lib/auth.coffee.js                                                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var getUserQuerySelector, userValidator;                                                                             // 10
                                                                                                                     // 11
this.Auth || (this.Auth = {});                                                                                       // 12
                                                                                                                     // 13
                                                                                                                     // 14
/*                                                                                                                   // 15
  A valid user will have exactly one of the following identification fields: id, username, or email                  // 16
 */                                                                                                                  // 17
                                                                                                                     // 18
userValidator = Match.Where(function(user) {                                                                         // 19
  check(user, {                                                                                                      // 20
    id: Match.Optional(String),                                                                                      // 21
    username: Match.Optional(String),                                                                                // 22
    email: Match.Optional(String)                                                                                    // 23
  });                                                                                                                // 24
  if (_.keys(user).length === !1) {                                                                                  // 25
    throw new Match.Error('User must have exactly one identifier field');                                            // 26
  }                                                                                                                  // 27
  return true;                                                                                                       // 28
});                                                                                                                  // 29
                                                                                                                     // 30
                                                                                                                     // 31
/*                                                                                                                   // 32
  Return a MongoDB query selector for finding the given user                                                         // 33
 */                                                                                                                  // 34
                                                                                                                     // 35
getUserQuerySelector = function(user) {                                                                              // 36
  if (user.id) {                                                                                                     // 37
    return {                                                                                                         // 38
      '_id': user.id                                                                                                 // 39
    };                                                                                                               // 40
  } else if (user.username) {                                                                                        // 41
    return {                                                                                                         // 42
      'username': user.username                                                                                      // 43
    };                                                                                                               // 44
  } else if (user.email) {                                                                                           // 45
    return {                                                                                                         // 46
      'emails.address': user.email                                                                                   // 47
    };                                                                                                               // 48
  }                                                                                                                  // 49
  throw new Error('Cannot create selector from invalid user');                                                       // 50
};                                                                                                                   // 51
                                                                                                                     // 52
                                                                                                                     // 53
/*                                                                                                                   // 54
  Log a user in with their password                                                                                  // 55
 */                                                                                                                  // 56
                                                                                                                     // 57
this.Auth.loginWithPassword = function(user, password) {                                                             // 58
  var authToken, authenticatingUser, authenticatingUserSelector, hashedToken, passwordVerification, _ref;            // 59
  if (!user || !password) {                                                                                          // 60
    throw new Meteor.Error(401, 'Unauthorized');                                                                     // 61
  }                                                                                                                  // 62
  check(user, userValidator);                                                                                        // 63
  check(password, String);                                                                                           // 64
  authenticatingUserSelector = getUserQuerySelector(user);                                                           // 65
  authenticatingUser = Meteor.users.findOne(authenticatingUserSelector);                                             // 66
  if (!authenticatingUser) {                                                                                         // 67
    throw new Meteor.Error(401, 'Unauthorized');                                                                     // 68
  }                                                                                                                  // 69
  if (!((_ref = authenticatingUser.services) != null ? _ref.password : void 0)) {                                    // 70
    throw new Meteor.Error(401, 'Unauthorized');                                                                     // 71
  }                                                                                                                  // 72
  passwordVerification = Accounts._checkPassword(authenticatingUser, password);                                      // 73
  if (passwordVerification.error) {                                                                                  // 74
    throw new Meteor.Error(401, 'Unauthorized');                                                                     // 75
  }                                                                                                                  // 76
  authToken = Accounts._generateStampedLoginToken();                                                                 // 77
  hashedToken = Accounts._hashLoginToken(authToken.token);                                                           // 78
  Accounts._insertHashedLoginToken(authenticatingUser._id, {                                                         // 79
    hashedToken: hashedToken                                                                                         // 80
  });                                                                                                                // 81
  return {                                                                                                           // 82
    authToken: authToken.token,                                                                                      // 83
    userId: authenticatingUser._id                                                                                   // 84
  };                                                                                                                 // 85
};                                                                                                                   // 86
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     // 88
}).call(this);                                                                                                       // 89
                                                                                                                     // 90
                                                                                                                     // 91
                                                                                                                     // 92
                                                                                                                     // 93
                                                                                                                     // 94
                                                                                                                     // 95
(function () {                                                                                                       // 96
                                                                                                                     // 97
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nimble:restivus/lib/iron-router-error-to-response.js                                                     //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
// We need a function that treats thrown errors exactly like Iron Router would.                                      // 1
// This file is written in JavaScript to enable copy-pasting Iron Router code.                                       // 2
                                                                                                                     // 3
// Taken from: https://github.com/iron-meteor/iron-router/blob/9c369499c98af9fd12ef9e68338dee3b1b1276aa/lib/router_server.js#L3
var env = process.env.NODE_ENV || 'development';                                                                     // 5
                                                                                                                     // 6
// Taken from: https://github.com/iron-meteor/iron-router/blob/9c369499c98af9fd12ef9e68338dee3b1b1276aa/lib/router_server.js#L47
ironRouterSendErrorToResponse = function (err, req, res) {                                                           // 8
  if (res.statusCode < 400)                                                                                          // 9
    res.statusCode = 500;                                                                                            // 10
                                                                                                                     // 11
  if (err.status)                                                                                                    // 12
    res.statusCode = err.status;                                                                                     // 13
                                                                                                                     // 14
  if (env === 'development')                                                                                         // 15
    msg = (err.stack || err.toString()) + '\n';                                                                      // 16
  else                                                                                                               // 17
    //XXX get this from standard dict of error messages?                                                             // 18
    msg = 'Server error.';                                                                                           // 19
                                                                                                                     // 20
  console.error(err.stack || err.toString());                                                                        // 21
                                                                                                                     // 22
  if (res.headersSent)                                                                                               // 23
    return req.socket.destroy();                                                                                     // 24
                                                                                                                     // 25
  res.setHeader('Content-Type', 'text/html');                                                                        // 26
  res.setHeader('Content-Length', Buffer.byteLength(msg));                                                           // 27
  if (req.method === 'HEAD')                                                                                         // 28
    return res.end();                                                                                                // 29
  res.end(msg);                                                                                                      // 30
  return;                                                                                                            // 31
}                                                                                                                    // 32
                                                                                                                     // 33
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     // 138
}).call(this);                                                                                                       // 139
                                                                                                                     // 140
                                                                                                                     // 141
                                                                                                                     // 142
                                                                                                                     // 143
                                                                                                                     // 144
                                                                                                                     // 145
(function () {                                                                                                       // 146
                                                                                                                     // 147
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nimble:restivus/lib/route.coffee.js                                                                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.Route = (function() {                                                                                           // 155
  function Route(api, path, options, endpoints) {                                                                    // 156
    this.api = api;                                                                                                  // 157
    this.path = path;                                                                                                // 158
    this.options = options;                                                                                          // 159
    this.endpoints = endpoints;                                                                                      // 160
    if (!this.endpoints) {                                                                                           // 161
      this.endpoints = this.options;                                                                                 // 162
      this.options = {};                                                                                             // 163
    }                                                                                                                // 164
  }                                                                                                                  // 165
                                                                                                                     // 166
  Route.prototype.addToApi = (function() {                                                                           // 167
    var availableMethods;                                                                                            // 168
    availableMethods = ['get', 'post', 'put', 'patch', 'delete', 'options'];                                         // 169
    return function() {                                                                                              // 170
      var allowedMethods, fullPath, rejectedMethods, self;                                                           // 171
      self = this;                                                                                                   // 172
      if (_.contains(this.api._config.paths, this.path)) {                                                           // 173
        throw new Error("Cannot add a route at an existing path: " + this.path);                                     // 174
      }                                                                                                              // 175
      this.endpoints = _.extend({                                                                                    // 176
        options: this.api._config.defaultOptionsEndpoint                                                             // 177
      }, this.endpoints);                                                                                            // 178
      this._resolveEndpoints();                                                                                      // 179
      this._configureEndpoints();                                                                                    // 180
      this.api._config.paths.push(this.path);                                                                        // 181
      allowedMethods = _.filter(availableMethods, function(method) {                                                 // 182
        return _.contains(_.keys(self.endpoints), method);                                                           // 183
      });                                                                                                            // 184
      rejectedMethods = _.reject(availableMethods, function(method) {                                                // 185
        return _.contains(_.keys(self.endpoints), method);                                                           // 186
      });                                                                                                            // 187
      fullPath = this.api._config.apiPath + this.path;                                                               // 188
      _.each(allowedMethods, function(method) {                                                                      // 189
        var endpoint;                                                                                                // 190
        endpoint = self.endpoints[method];                                                                           // 191
        return JsonRoutes.add(method, fullPath, function(req, res) {                                                 // 192
          var doneFunc, endpointContext, error, responseData, responseInitiated;                                     // 193
          responseInitiated = false;                                                                                 // 194
          doneFunc = function() {                                                                                    // 195
            return responseInitiated = true;                                                                         // 196
          };                                                                                                         // 197
          endpointContext = {                                                                                        // 198
            urlParams: req.params,                                                                                   // 199
            queryParams: req.query,                                                                                  // 200
            bodyParams: req.body,                                                                                    // 201
            request: req,                                                                                            // 202
            response: res,                                                                                           // 203
            done: doneFunc                                                                                           // 204
          };                                                                                                         // 205
          _.extend(endpointContext, endpoint);                                                                       // 206
          responseData = null;                                                                                       // 207
          try {                                                                                                      // 208
            responseData = self._callEndpoint(endpointContext, endpoint);                                            // 209
            if (responseData === null || responseData === void 0) {                                                  // 210
              throw new Error("Cannot return null or undefined from an endpoint: " + method + " " + fullPath);       // 211
            }                                                                                                        // 212
            if (res.headersSent && !responseInitiated) {                                                             // 213
              throw new Error("Must call this.done() after handling endpoint response manually: " + method + " " + fullPath);
            }                                                                                                        // 215
          } catch (_error) {                                                                                         // 216
            error = _error;                                                                                          // 217
            ironRouterSendErrorToResponse(error, req, res);                                                          // 218
            return;                                                                                                  // 219
          }                                                                                                          // 220
          if (responseInitiated) {                                                                                   // 221
            res.end();                                                                                               // 222
            return;                                                                                                  // 223
          }                                                                                                          // 224
          if (responseData.body && (responseData.statusCode || responseData.headers)) {                              // 225
            return self._respond(res, responseData.body, responseData.statusCode, responseData.headers);             // 226
          } else {                                                                                                   // 227
            return self._respond(res, responseData);                                                                 // 228
          }                                                                                                          // 229
        });                                                                                                          // 230
      });                                                                                                            // 231
      return _.each(rejectedMethods, function(method) {                                                              // 232
        return JsonRoutes.add(method, fullPath, function(req, res) {                                                 // 233
          var headers, responseData;                                                                                 // 234
          responseData = {                                                                                           // 235
            status: 'error',                                                                                         // 236
            message: 'API endpoint does not exist'                                                                   // 237
          };                                                                                                         // 238
          headers = {                                                                                                // 239
            'Allow': allowedMethods.join(', ').toUpperCase()                                                         // 240
          };                                                                                                         // 241
          return self._respond(res, responseData, 405, headers);                                                     // 242
        });                                                                                                          // 243
      });                                                                                                            // 244
    };                                                                                                               // 245
  })();                                                                                                              // 246
                                                                                                                     // 247
                                                                                                                     // 248
  /*                                                                                                                 // 249
    Convert all endpoints on the given route into our expected endpoint object if it is a bare                       // 250
    function                                                                                                         // 251
                                                                                                                     // 252
    @param {Route} route The route the endpoints belong to                                                           // 253
   */                                                                                                                // 254
                                                                                                                     // 255
  Route.prototype._resolveEndpoints = function() {                                                                   // 256
    _.each(this.endpoints, function(endpoint, method, endpoints) {                                                   // 257
      if (_.isFunction(endpoint)) {                                                                                  // 258
        return endpoints[method] = {                                                                                 // 259
          action: endpoint                                                                                           // 260
        };                                                                                                           // 261
      }                                                                                                              // 262
    });                                                                                                              // 263
  };                                                                                                                 // 264
                                                                                                                     // 265
                                                                                                                     // 266
  /*                                                                                                                 // 267
    Configure the authentication and role requirement on all endpoints (except OPTIONS, which must                   // 268
    be configured directly on the endpoint)                                                                          // 269
                                                                                                                     // 270
    Authentication can be required on an entire route or individual endpoints. If required on an                     // 271
    entire route, that serves as the default. If required in any individual endpoints, that will                     // 272
    override the default.                                                                                            // 273
                                                                                                                     // 274
    After the endpoint is configured, all authentication and role requirements of an endpoint can be                 // 275
    accessed at <code>endpoint.authRequired</code> and <code>endpoint.roleRequired</code>,                           // 276
    respectively.                                                                                                    // 277
                                                                                                                     // 278
    @param {Route} route The route the endpoints belong to                                                           // 279
    @param {Endpoint} endpoint The endpoint to configure                                                             // 280
   */                                                                                                                // 281
                                                                                                                     // 282
  Route.prototype._configureEndpoints = function() {                                                                 // 283
    _.each(this.endpoints, function(endpoint, method) {                                                              // 284
      var _ref, _ref1;                                                                                               // 285
      if (method !== 'options') {                                                                                    // 286
        if (!((_ref = this.options) != null ? _ref.roleRequired : void 0)) {                                         // 287
          this.options.roleRequired = [];                                                                            // 288
        }                                                                                                            // 289
        if (!endpoint.roleRequired) {                                                                                // 290
          endpoint.roleRequired = [];                                                                                // 291
        }                                                                                                            // 292
        endpoint.roleRequired = _.union(endpoint.roleRequired, this.options.roleRequired);                           // 293
        if (_.isEmpty(endpoint.roleRequired)) {                                                                      // 294
          endpoint.roleRequired = false;                                                                             // 295
        }                                                                                                            // 296
        if (endpoint.authRequired === void 0) {                                                                      // 297
          if (((_ref1 = this.options) != null ? _ref1.authRequired : void 0) || endpoint.roleRequired) {             // 298
            endpoint.authRequired = true;                                                                            // 299
          } else {                                                                                                   // 300
            endpoint.authRequired = false;                                                                           // 301
          }                                                                                                          // 302
        }                                                                                                            // 303
      }                                                                                                              // 304
    }, this);                                                                                                        // 305
  };                                                                                                                 // 306
                                                                                                                     // 307
                                                                                                                     // 308
  /*                                                                                                                 // 309
    Authenticate an endpoint if required, and return the result of calling it                                        // 310
                                                                                                                     // 311
    @returns The endpoint response or a 401 if authentication fails                                                  // 312
   */                                                                                                                // 313
                                                                                                                     // 314
  Route.prototype._callEndpoint = function(endpointContext, endpoint) {                                              // 315
    if (this._authAccepted(endpointContext, endpoint)) {                                                             // 316
      if (this._roleAccepted(endpointContext, endpoint)) {                                                           // 317
        return endpoint.action.call(endpointContext);                                                                // 318
      } else {                                                                                                       // 319
        return {                                                                                                     // 320
          statusCode: 403,                                                                                           // 321
          body: {                                                                                                    // 322
            status: 'error',                                                                                         // 323
            message: 'You do not have permission to do this.'                                                        // 324
          }                                                                                                          // 325
        };                                                                                                           // 326
      }                                                                                                              // 327
    } else {                                                                                                         // 328
      return {                                                                                                       // 329
        statusCode: 401,                                                                                             // 330
        body: {                                                                                                      // 331
          status: 'error',                                                                                           // 332
          message: 'You must be logged in to do this.'                                                               // 333
        }                                                                                                            // 334
      };                                                                                                             // 335
    }                                                                                                                // 336
  };                                                                                                                 // 337
                                                                                                                     // 338
                                                                                                                     // 339
  /*                                                                                                                 // 340
    Authenticate the given endpoint if required                                                                      // 341
                                                                                                                     // 342
    Once it's globally configured in the API, authentication can be required on an entire route or                   // 343
    individual endpoints. If required on an entire endpoint, that serves as the default. If required                 // 344
    in any individual endpoints, that will override the default.                                                     // 345
                                                                                                                     // 346
    @returns False if authentication fails, and true otherwise                                                       // 347
   */                                                                                                                // 348
                                                                                                                     // 349
  Route.prototype._authAccepted = function(endpointContext, endpoint) {                                              // 350
    if (endpoint.authRequired) {                                                                                     // 351
      return this._authenticate(endpointContext);                                                                    // 352
    } else {                                                                                                         // 353
      return true;                                                                                                   // 354
    }                                                                                                                // 355
  };                                                                                                                 // 356
                                                                                                                     // 357
                                                                                                                     // 358
  /*                                                                                                                 // 359
    Verify the request is being made by an actively logged in user                                                   // 360
                                                                                                                     // 361
    If verified, attach the authenticated user to the context.                                                       // 362
                                                                                                                     // 363
    @returns {Boolean} True if the authentication was successful                                                     // 364
   */                                                                                                                // 365
                                                                                                                     // 366
  Route.prototype._authenticate = function(endpointContext) {                                                        // 367
    var auth, userSelector;                                                                                          // 368
    auth = this.api._config.auth.user.call(endpointContext);                                                         // 369
    if ((auth != null ? auth.userId : void 0) && (auth != null ? auth.token : void 0) && !(auth != null ? auth.user : void 0)) {
      userSelector = {};                                                                                             // 371
      userSelector._id = auth.userId;                                                                                // 372
      userSelector[this.api._config.auth.token] = auth.token;                                                        // 373
      auth.user = Meteor.users.findOne(userSelector);                                                                // 374
    }                                                                                                                // 375
    if (auth != null ? auth.user : void 0) {                                                                         // 376
      endpointContext.user = auth.user;                                                                              // 377
      endpointContext.userId = auth.user._id;                                                                        // 378
      return true;                                                                                                   // 379
    } else {                                                                                                         // 380
      return false;                                                                                                  // 381
    }                                                                                                                // 382
  };                                                                                                                 // 383
                                                                                                                     // 384
                                                                                                                     // 385
  /*                                                                                                                 // 386
    Authenticate the user role if required                                                                           // 387
                                                                                                                     // 388
    Must be called after _authAccepted().                                                                            // 389
                                                                                                                     // 390
    @returns True if the authenticated user belongs to <i>any</i> of the acceptable roles on the                     // 391
             endpoint                                                                                                // 392
   */                                                                                                                // 393
                                                                                                                     // 394
  Route.prototype._roleAccepted = function(endpointContext, endpoint) {                                              // 395
    if (endpoint.roleRequired) {                                                                                     // 396
      if (_.isEmpty(_.intersection(endpoint.roleRequired, endpointContext.user.roles))) {                            // 397
        return false;                                                                                                // 398
      }                                                                                                              // 399
    }                                                                                                                // 400
    return true;                                                                                                     // 401
  };                                                                                                                 // 402
                                                                                                                     // 403
                                                                                                                     // 404
  /*                                                                                                                 // 405
    Respond to an HTTP request                                                                                       // 406
   */                                                                                                                // 407
                                                                                                                     // 408
  Route.prototype._respond = function(response, body, statusCode, headers) {                                         // 409
    var defaultHeaders, delayInMilliseconds, minimumDelayInMilliseconds, randomMultiplierBetweenOneAndTwo, sendResponse;
    if (statusCode == null) {                                                                                        // 411
      statusCode = 200;                                                                                              // 412
    }                                                                                                                // 413
    if (headers == null) {                                                                                           // 414
      headers = {};                                                                                                  // 415
    }                                                                                                                // 416
    defaultHeaders = this._lowerCaseKeys(this.api._config.defaultHeaders);                                           // 417
    headers = this._lowerCaseKeys(headers);                                                                          // 418
    headers = _.extend(defaultHeaders, headers);                                                                     // 419
    if (headers['content-type'].match(/json|javascript/) !== null) {                                                 // 420
      if (this.api._config.prettyJson) {                                                                             // 421
        body = JSON.stringify(body, void 0, 2);                                                                      // 422
      } else {                                                                                                       // 423
        body = JSON.stringify(body);                                                                                 // 424
      }                                                                                                              // 425
    }                                                                                                                // 426
    sendResponse = function() {                                                                                      // 427
      response.writeHead(statusCode, headers);                                                                       // 428
      response.write(body);                                                                                          // 429
      return response.end();                                                                                         // 430
    };                                                                                                               // 431
    if (statusCode === 401 || statusCode === 403) {                                                                  // 432
      minimumDelayInMilliseconds = 500;                                                                              // 433
      randomMultiplierBetweenOneAndTwo = 1 + Math.random();                                                          // 434
      delayInMilliseconds = minimumDelayInMilliseconds * randomMultiplierBetweenOneAndTwo;                           // 435
      return Meteor.setTimeout(sendResponse, delayInMilliseconds);                                                   // 436
    } else {                                                                                                         // 437
      return sendResponse();                                                                                         // 438
    }                                                                                                                // 439
  };                                                                                                                 // 440
                                                                                                                     // 441
                                                                                                                     // 442
  /*                                                                                                                 // 443
    Return the object with all of the keys converted to lowercase                                                    // 444
   */                                                                                                                // 445
                                                                                                                     // 446
  Route.prototype._lowerCaseKeys = function(object) {                                                                // 447
    return _.chain(object).pairs().map(function(attr) {                                                              // 448
      return [attr[0].toLowerCase(), attr[1]];                                                                       // 449
    }).object().value();                                                                                             // 450
  };                                                                                                                 // 451
                                                                                                                     // 452
  return Route;                                                                                                      // 453
                                                                                                                     // 454
})();                                                                                                                // 455
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     // 457
}).call(this);                                                                                                       // 458
                                                                                                                     // 459
                                                                                                                     // 460
                                                                                                                     // 461
                                                                                                                     // 462
                                                                                                                     // 463
                                                                                                                     // 464
(function () {                                                                                                       // 465
                                                                                                                     // 466
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/nimble:restivus/lib/restivus.coffee.js                                                                   //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var                                                                                                                  // 474
  __indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };
                                                                                                                     // 476
this.Restivus = (function() {                                                                                        // 477
  function Restivus(options) {                                                                                       // 478
    var corsHeaders;                                                                                                 // 479
    this._routes = [];                                                                                               // 480
    this._config = {                                                                                                 // 481
      paths: [],                                                                                                     // 482
      useDefaultAuth: false,                                                                                         // 483
      apiPath: 'api/',                                                                                               // 484
      version: null,                                                                                                 // 485
      prettyJson: false,                                                                                             // 486
      auth: {                                                                                                        // 487
        token: 'services.resume.loginTokens.hashedToken',                                                            // 488
        user: function() {                                                                                           // 489
          var token;                                                                                                 // 490
          if (this.request.headers['x-auth-token']) {                                                                // 491
            token = Accounts._hashLoginToken(this.request.headers['x-auth-token']);                                  // 492
          }                                                                                                          // 493
          return {                                                                                                   // 494
            userId: this.request.headers['x-user-id'],                                                               // 495
            token: token                                                                                             // 496
          };                                                                                                         // 497
        }                                                                                                            // 498
      },                                                                                                             // 499
      onLoggedIn: function() {                                                                                       // 500
        return {};                                                                                                   // 501
      },                                                                                                             // 502
      onLoggedOut: function() {                                                                                      // 503
        return {};                                                                                                   // 504
      },                                                                                                             // 505
      defaultHeaders: {                                                                                              // 506
        'Content-Type': 'application/json'                                                                           // 507
      },                                                                                                             // 508
      enableCors: true                                                                                               // 509
    };                                                                                                               // 510
    _.extend(this._config, options);                                                                                 // 511
    if (this._config.enableCors) {                                                                                   // 512
      corsHeaders = {                                                                                                // 513
        'Access-Control-Allow-Origin': '*',                                                                          // 514
        'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept'                             // 515
      };                                                                                                             // 516
      if (this._config.useDefaultAuth) {                                                                             // 517
        corsHeaders['Access-Control-Allow-Headers'] += ', X-User-Id, X-Auth-Token';                                  // 518
      }                                                                                                              // 519
      _.extend(this._config.defaultHeaders, corsHeaders);                                                            // 520
      if (!this._config.defaultOptionsEndpoint) {                                                                    // 521
        this._config.defaultOptionsEndpoint = function() {                                                           // 522
          this.response.writeHead(200, corsHeaders);                                                                 // 523
          return this.done();                                                                                        // 524
        };                                                                                                           // 525
      }                                                                                                              // 526
    }                                                                                                                // 527
    if (this._config.apiPath[0] === '/') {                                                                           // 528
      this._config.apiPath = this._config.apiPath.slice(1);                                                          // 529
    }                                                                                                                // 530
    if (_.last(this._config.apiPath) !== '/') {                                                                      // 531
      this._config.apiPath = this._config.apiPath + '/';                                                             // 532
    }                                                                                                                // 533
    if (this._config.version) {                                                                                      // 534
      this._config.apiPath += this._config.version + '/';                                                            // 535
    }                                                                                                                // 536
    if (this._config.useDefaultAuth) {                                                                               // 537
      this._initAuth();                                                                                              // 538
    } else if (this._config.useAuth) {                                                                               // 539
      this._initAuth();                                                                                              // 540
      console.warn('Warning: useAuth API config option will be removed in Restivus v1.0 ' + '\n    Use the useDefaultAuth option instead');
    }                                                                                                                // 542
    return this;                                                                                                     // 543
  }                                                                                                                  // 544
                                                                                                                     // 545
                                                                                                                     // 546
  /**                                                                                                                // 547
    Add endpoints for the given HTTP methods at the given path                                                       // 548
                                                                                                                     // 549
    @param path {String} The extended URL path (will be appended to base path of the API)                            // 550
    @param options {Object} Route configuration options                                                              // 551
    @param options.authRequired {Boolean} The default auth requirement for each endpoint on the route                // 552
    @param options.roleRequired {String or String[]} The default role required for each endpoint on the route        // 553
    @param endpoints {Object} A set of endpoints available on the new route (get, post, put, patch, delete, options)
    @param endpoints.<method> {Function or Object} If a function is provided, all default route                      // 555
        configuration options will be applied to the endpoint. Otherwise an object with an `action`                  // 556
        and all other route config options available. An `action` must be provided with the object.                  // 557
   */                                                                                                                // 558
                                                                                                                     // 559
  Restivus.prototype.addRoute = function(path, options, endpoints) {                                                 // 560
    var route;                                                                                                       // 561
    route = new Route(this, path, options, endpoints);                                                               // 562
    this._routes.push(route);                                                                                        // 563
    route.addToApi();                                                                                                // 564
    return this;                                                                                                     // 565
  };                                                                                                                 // 566
                                                                                                                     // 567
                                                                                                                     // 568
  /**                                                                                                                // 569
    Generate routes for the Meteor Collection with the given name                                                    // 570
   */                                                                                                                // 571
                                                                                                                     // 572
  Restivus.prototype.addCollection = function(collection, options) {                                                 // 573
    var collectionEndpoints, collectionRouteEndpoints, endpointsAwaitingConfiguration, entityRouteEndpoints, excludedEndpoints, methods, methodsOnCollection, path, routeOptions;
    if (options == null) {                                                                                           // 575
      options = {};                                                                                                  // 576
    }                                                                                                                // 577
    methods = ['get', 'post', 'put', 'delete', 'getAll'];                                                            // 578
    methodsOnCollection = ['post', 'getAll'];                                                                        // 579
    if (collection === Meteor.users) {                                                                               // 580
      collectionEndpoints = this._userCollectionEndpoints;                                                           // 581
    } else {                                                                                                         // 582
      collectionEndpoints = this._collectionEndpoints;                                                               // 583
    }                                                                                                                // 584
    endpointsAwaitingConfiguration = options.endpoints || {};                                                        // 585
    routeOptions = options.routeOptions || {};                                                                       // 586
    excludedEndpoints = options.excludedEndpoints || [];                                                             // 587
    path = options.path || collection._name;                                                                         // 588
    collectionRouteEndpoints = {};                                                                                   // 589
    entityRouteEndpoints = {};                                                                                       // 590
    if (_.isEmpty(endpointsAwaitingConfiguration) && _.isEmpty(excludedEndpoints)) {                                 // 591
      _.each(methods, function(method) {                                                                             // 592
        if (__indexOf.call(methodsOnCollection, method) >= 0) {                                                      // 593
          _.extend(collectionRouteEndpoints, collectionEndpoints[method].call(this, collection));                    // 594
        } else {                                                                                                     // 595
          _.extend(entityRouteEndpoints, collectionEndpoints[method].call(this, collection));                        // 596
        }                                                                                                            // 597
      }, this);                                                                                                      // 598
    } else {                                                                                                         // 599
      _.each(methods, function(method) {                                                                             // 600
        var configuredEndpoint, endpointOptions;                                                                     // 601
        if (__indexOf.call(excludedEndpoints, method) < 0 && endpointsAwaitingConfiguration[method] !== false) {     // 602
          endpointOptions = endpointsAwaitingConfiguration[method];                                                  // 603
          configuredEndpoint = {};                                                                                   // 604
          _.each(collectionEndpoints[method].call(this, collection), function(action, methodType) {                  // 605
            return configuredEndpoint[methodType] = _.chain(action).clone().extend(endpointOptions).value();         // 606
          });                                                                                                        // 607
          if (__indexOf.call(methodsOnCollection, method) >= 0) {                                                    // 608
            _.extend(collectionRouteEndpoints, configuredEndpoint);                                                  // 609
          } else {                                                                                                   // 610
            _.extend(entityRouteEndpoints, configuredEndpoint);                                                      // 611
          }                                                                                                          // 612
        }                                                                                                            // 613
      }, this);                                                                                                      // 614
    }                                                                                                                // 615
    this.addRoute(path, routeOptions, collectionRouteEndpoints);                                                     // 616
    this.addRoute("" + path + "/:id", routeOptions, entityRouteEndpoints);                                           // 617
    return this;                                                                                                     // 618
  };                                                                                                                 // 619
                                                                                                                     // 620
                                                                                                                     // 621
  /**                                                                                                                // 622
    A set of endpoints that can be applied to a Collection Route                                                     // 623
   */                                                                                                                // 624
                                                                                                                     // 625
  Restivus.prototype._collectionEndpoints = {                                                                        // 626
    get: function(collection) {                                                                                      // 627
      return {                                                                                                       // 628
        get: {                                                                                                       // 629
          action: function() {                                                                                       // 630
            var entity;                                                                                              // 631
            entity = collection.findOne(this.urlParams.id);                                                          // 632
            if (entity) {                                                                                            // 633
              return {                                                                                               // 634
                status: 'success',                                                                                   // 635
                data: entity                                                                                         // 636
              };                                                                                                     // 637
            } else {                                                                                                 // 638
              return {                                                                                               // 639
                statusCode: 404,                                                                                     // 640
                body: {                                                                                              // 641
                  status: 'fail',                                                                                    // 642
                  message: 'Item not found'                                                                          // 643
                }                                                                                                    // 644
              };                                                                                                     // 645
            }                                                                                                        // 646
          }                                                                                                          // 647
        }                                                                                                            // 648
      };                                                                                                             // 649
    },                                                                                                               // 650
    put: function(collection) {                                                                                      // 651
      return {                                                                                                       // 652
        put: {                                                                                                       // 653
          action: function() {                                                                                       // 654
            var entity, entityIsUpdated;                                                                             // 655
            entityIsUpdated = collection.update(this.urlParams.id, this.bodyParams);                                 // 656
            if (entityIsUpdated) {                                                                                   // 657
              entity = collection.findOne(this.urlParams.id);                                                        // 658
              return {                                                                                               // 659
                status: 'success',                                                                                   // 660
                data: entity                                                                                         // 661
              };                                                                                                     // 662
            } else {                                                                                                 // 663
              return {                                                                                               // 664
                statusCode: 404,                                                                                     // 665
                body: {                                                                                              // 666
                  status: 'fail',                                                                                    // 667
                  message: 'Item not found'                                                                          // 668
                }                                                                                                    // 669
              };                                                                                                     // 670
            }                                                                                                        // 671
          }                                                                                                          // 672
        }                                                                                                            // 673
      };                                                                                                             // 674
    },                                                                                                               // 675
    "delete": function(collection) {                                                                                 // 676
      return {                                                                                                       // 677
        "delete": {                                                                                                  // 678
          action: function() {                                                                                       // 679
            if (collection.remove(this.urlParams.id)) {                                                              // 680
              return {                                                                                               // 681
                status: 'success',                                                                                   // 682
                data: {                                                                                              // 683
                  message: 'Item removed'                                                                            // 684
                }                                                                                                    // 685
              };                                                                                                     // 686
            } else {                                                                                                 // 687
              return {                                                                                               // 688
                statusCode: 404,                                                                                     // 689
                body: {                                                                                              // 690
                  status: 'fail',                                                                                    // 691
                  message: 'Item not found'                                                                          // 692
                }                                                                                                    // 693
              };                                                                                                     // 694
            }                                                                                                        // 695
          }                                                                                                          // 696
        }                                                                                                            // 697
      };                                                                                                             // 698
    },                                                                                                               // 699
    post: function(collection) {                                                                                     // 700
      return {                                                                                                       // 701
        post: {                                                                                                      // 702
          action: function() {                                                                                       // 703
            var entity, entityId;                                                                                    // 704
            entityId = collection.insert(this.bodyParams);                                                           // 705
            entity = collection.findOne(entityId);                                                                   // 706
            if (entity) {                                                                                            // 707
              return {                                                                                               // 708
                statusCode: 201,                                                                                     // 709
                body: {                                                                                              // 710
                  status: 'success',                                                                                 // 711
                  data: entity                                                                                       // 712
                }                                                                                                    // 713
              };                                                                                                     // 714
            } else {                                                                                                 // 715
              return {                                                                                               // 716
                statusCode: 400,                                                                                     // 717
                body: {                                                                                              // 718
                  status: 'fail',                                                                                    // 719
                  message: 'No item added'                                                                           // 720
                }                                                                                                    // 721
              };                                                                                                     // 722
            }                                                                                                        // 723
          }                                                                                                          // 724
        }                                                                                                            // 725
      };                                                                                                             // 726
    },                                                                                                               // 727
    getAll: function(collection) {                                                                                   // 728
      return {                                                                                                       // 729
        get: {                                                                                                       // 730
          action: function() {                                                                                       // 731
            var entities;                                                                                            // 732
            entities = collection.find().fetch();                                                                    // 733
            if (entities) {                                                                                          // 734
              return {                                                                                               // 735
                status: 'success',                                                                                   // 736
                data: entities                                                                                       // 737
              };                                                                                                     // 738
            } else {                                                                                                 // 739
              return {                                                                                               // 740
                statusCode: 404,                                                                                     // 741
                body: {                                                                                              // 742
                  status: 'fail',                                                                                    // 743
                  message: 'Unable to retrieve items from collection'                                                // 744
                }                                                                                                    // 745
              };                                                                                                     // 746
            }                                                                                                        // 747
          }                                                                                                          // 748
        }                                                                                                            // 749
      };                                                                                                             // 750
    }                                                                                                                // 751
  };                                                                                                                 // 752
                                                                                                                     // 753
                                                                                                                     // 754
  /**                                                                                                                // 755
    A set of endpoints that can be applied to a Meteor.users Collection Route                                        // 756
   */                                                                                                                // 757
                                                                                                                     // 758
  Restivus.prototype._userCollectionEndpoints = {                                                                    // 759
    get: function(collection) {                                                                                      // 760
      return {                                                                                                       // 761
        get: {                                                                                                       // 762
          action: function() {                                                                                       // 763
            var entity;                                                                                              // 764
            entity = collection.findOne(this.urlParams.id, {                                                         // 765
              fields: {                                                                                              // 766
                profile: 1                                                                                           // 767
              }                                                                                                      // 768
            });                                                                                                      // 769
            if (entity) {                                                                                            // 770
              return {                                                                                               // 771
                status: 'success',                                                                                   // 772
                data: entity                                                                                         // 773
              };                                                                                                     // 774
            } else {                                                                                                 // 775
              return {                                                                                               // 776
                statusCode: 404,                                                                                     // 777
                body: {                                                                                              // 778
                  status: 'fail',                                                                                    // 779
                  message: 'User not found'                                                                          // 780
                }                                                                                                    // 781
              };                                                                                                     // 782
            }                                                                                                        // 783
          }                                                                                                          // 784
        }                                                                                                            // 785
      };                                                                                                             // 786
    },                                                                                                               // 787
    put: function(collection) {                                                                                      // 788
      return {                                                                                                       // 789
        put: {                                                                                                       // 790
          action: function() {                                                                                       // 791
            var entity, entityIsUpdated;                                                                             // 792
            entityIsUpdated = collection.update(this.urlParams.id, {                                                 // 793
              $set: {                                                                                                // 794
                profile: this.bodyParams                                                                             // 795
              }                                                                                                      // 796
            });                                                                                                      // 797
            if (entityIsUpdated) {                                                                                   // 798
              entity = collection.findOne(this.urlParams.id, {                                                       // 799
                fields: {                                                                                            // 800
                  profile: 1                                                                                         // 801
                }                                                                                                    // 802
              });                                                                                                    // 803
              return {                                                                                               // 804
                status: "success",                                                                                   // 805
                data: entity                                                                                         // 806
              };                                                                                                     // 807
            } else {                                                                                                 // 808
              return {                                                                                               // 809
                statusCode: 404,                                                                                     // 810
                body: {                                                                                              // 811
                  status: 'fail',                                                                                    // 812
                  message: 'User not found'                                                                          // 813
                }                                                                                                    // 814
              };                                                                                                     // 815
            }                                                                                                        // 816
          }                                                                                                          // 817
        }                                                                                                            // 818
      };                                                                                                             // 819
    },                                                                                                               // 820
    "delete": function(collection) {                                                                                 // 821
      return {                                                                                                       // 822
        "delete": {                                                                                                  // 823
          action: function() {                                                                                       // 824
            if (collection.remove(this.urlParams.id)) {                                                              // 825
              return {                                                                                               // 826
                status: 'success',                                                                                   // 827
                data: {                                                                                              // 828
                  message: 'User removed'                                                                            // 829
                }                                                                                                    // 830
              };                                                                                                     // 831
            } else {                                                                                                 // 832
              return {                                                                                               // 833
                statusCode: 404,                                                                                     // 834
                body: {                                                                                              // 835
                  status: 'fail',                                                                                    // 836
                  message: 'User not found'                                                                          // 837
                }                                                                                                    // 838
              };                                                                                                     // 839
            }                                                                                                        // 840
          }                                                                                                          // 841
        }                                                                                                            // 842
      };                                                                                                             // 843
    },                                                                                                               // 844
    post: function(collection) {                                                                                     // 845
      return {                                                                                                       // 846
        post: {                                                                                                      // 847
          action: function() {                                                                                       // 848
            var entity, entityId;                                                                                    // 849
            entityId = Accounts.createUser(this.bodyParams);                                                         // 850
            entity = collection.findOne(entityId, {                                                                  // 851
              fields: {                                                                                              // 852
                profile: 1                                                                                           // 853
              }                                                                                                      // 854
            });                                                                                                      // 855
            if (entity) {                                                                                            // 856
              return {                                                                                               // 857
                statusCode: 201,                                                                                     // 858
                body: {                                                                                              // 859
                  status: 'success',                                                                                 // 860
                  data: entity                                                                                       // 861
                }                                                                                                    // 862
              };                                                                                                     // 863
            } else {                                                                                                 // 864
              ({                                                                                                     // 865
                statusCode: 400                                                                                      // 866
              });                                                                                                    // 867
              return {                                                                                               // 868
                status: 'fail',                                                                                      // 869
                message: 'No user added'                                                                             // 870
              };                                                                                                     // 871
            }                                                                                                        // 872
          }                                                                                                          // 873
        }                                                                                                            // 874
      };                                                                                                             // 875
    },                                                                                                               // 876
    getAll: function(collection) {                                                                                   // 877
      return {                                                                                                       // 878
        get: {                                                                                                       // 879
          action: function() {                                                                                       // 880
            var entities;                                                                                            // 881
            entities = collection.find({}, {                                                                         // 882
              fields: {                                                                                              // 883
                profile: 1                                                                                           // 884
              }                                                                                                      // 885
            }).fetch();                                                                                              // 886
            if (entities) {                                                                                          // 887
              return {                                                                                               // 888
                status: 'success',                                                                                   // 889
                data: entities                                                                                       // 890
              };                                                                                                     // 891
            } else {                                                                                                 // 892
              return {                                                                                               // 893
                statusCode: 404,                                                                                     // 894
                body: {                                                                                              // 895
                  status: 'fail',                                                                                    // 896
                  message: 'Unable to retrieve users'                                                                // 897
                }                                                                                                    // 898
              };                                                                                                     // 899
            }                                                                                                        // 900
          }                                                                                                          // 901
        }                                                                                                            // 902
      };                                                                                                             // 903
    }                                                                                                                // 904
  };                                                                                                                 // 905
                                                                                                                     // 906
                                                                                                                     // 907
  /*                                                                                                                 // 908
    Add /login and /logout endpoints to the API                                                                      // 909
   */                                                                                                                // 910
                                                                                                                     // 911
  Restivus.prototype._initAuth = function() {                                                                        // 912
    var logout, self;                                                                                                // 913
    self = this;                                                                                                     // 914
                                                                                                                     // 915
    /*                                                                                                               // 916
      Add a login endpoint to the API                                                                                // 917
                                                                                                                     // 918
      After the user is logged in, the onLoggedIn hook is called (see Restfully.configure() for                      // 919
      adding hook).                                                                                                  // 920
     */                                                                                                              // 921
    this.addRoute('login', {                                                                                         // 922
      authRequired: false                                                                                            // 923
    }, {                                                                                                             // 924
      post: function() {                                                                                             // 925
        var auth, e, searchQuery, user, _ref;                                                                        // 926
        user = {};                                                                                                   // 927
        if (this.bodyParams.user) {                                                                                  // 928
          if (this.bodyParams.user.indexOf('@') === -1) {                                                            // 929
            user.username = this.bodyParams.user;                                                                    // 930
          } else {                                                                                                   // 931
            user.email = this.bodyParams.user;                                                                       // 932
          }                                                                                                          // 933
        } else if (this.bodyParams.username) {                                                                       // 934
          user.username = this.bodyParams.username;                                                                  // 935
        } else if (this.bodyParams.email) {                                                                          // 936
          user.email = this.bodyParams.email;                                                                        // 937
        }                                                                                                            // 938
        try {                                                                                                        // 939
          auth = Auth.loginWithPassword(user, this.bodyParams.password);                                             // 940
        } catch (_error) {                                                                                           // 941
          e = _error;                                                                                                // 942
          return {                                                                                                   // 943
            statusCode: e.error,                                                                                     // 944
            body: {                                                                                                  // 945
              status: 'error',                                                                                       // 946
              message: e.reason                                                                                      // 947
            }                                                                                                        // 948
          };                                                                                                         // 949
        }                                                                                                            // 950
        if (auth.userId && auth.authToken) {                                                                         // 951
          searchQuery = {};                                                                                          // 952
          searchQuery[self._config.auth.token] = Accounts._hashLoginToken(auth.authToken);                           // 953
          this.user = Meteor.users.findOne({                                                                         // 954
            '_id': auth.userId                                                                                       // 955
          }, searchQuery);                                                                                           // 956
          this.userId = (_ref = this.user) != null ? _ref._id : void 0;                                              // 957
        }                                                                                                            // 958
        self._config.onLoggedIn.call(this);                                                                          // 959
        return {                                                                                                     // 960
          status: 'success',                                                                                         // 961
          data: auth                                                                                                 // 962
        };                                                                                                           // 963
      }                                                                                                              // 964
    });                                                                                                              // 965
    logout = function() {                                                                                            // 966
      var authToken, hashedToken, index, tokenFieldName, tokenLocation, tokenPath, tokenRemovalQuery, tokenToRemove, _ref;
      authToken = this.request.headers['x-auth-token'];                                                              // 968
      hashedToken = Accounts._hashLoginToken(authToken);                                                             // 969
      tokenLocation = self._config.auth.token;                                                                       // 970
      index = tokenLocation.lastIndexOf('.');                                                                        // 971
      tokenPath = tokenLocation.substring(0, index);                                                                 // 972
      tokenFieldName = tokenLocation.substring(index + 1);                                                           // 973
      tokenToRemove = {};                                                                                            // 974
      tokenToRemove[tokenFieldName] = hashedToken;                                                                   // 975
      tokenRemovalQuery = {};                                                                                        // 976
      tokenRemovalQuery[tokenPath] = tokenToRemove;                                                                  // 977
      Meteor.users.update(this.user._id, {                                                                           // 978
        $pull: tokenRemovalQuery                                                                                     // 979
      });                                                                                                            // 980
      if ((_ref = self._config.onLoggedOut) != null) {                                                               // 981
        _ref.call(this);                                                                                             // 982
      }                                                                                                              // 983
      return {                                                                                                       // 984
        status: 'success',                                                                                           // 985
        data: {                                                                                                      // 986
          message: 'You\'ve been logged out!'                                                                        // 987
        }                                                                                                            // 988
      };                                                                                                             // 989
    };                                                                                                               // 990
                                                                                                                     // 991
    /*                                                                                                               // 992
      Add a logout endpoint to the API                                                                               // 993
                                                                                                                     // 994
      After the user is logged out, the onLoggedOut hook is called (see Restfully.configure() for                    // 995
      adding hook).                                                                                                  // 996
     */                                                                                                              // 997
    return this.addRoute('logout', {                                                                                 // 998
      authRequired: true                                                                                             // 999
    }, {                                                                                                             // 1000
      get: function() {                                                                                              // 1001
        console.warn("Warning: Default logout via GET will be removed in Restivus v1.0. Use POST instead.");         // 1002
        console.warn("    See https://github.com/kahmali/meteor-restivus/issues/100");                               // 1003
        return logout.call(this);                                                                                    // 1004
      },                                                                                                             // 1005
      post: logout                                                                                                   // 1006
    });                                                                                                              // 1007
  };                                                                                                                 // 1008
                                                                                                                     // 1009
  return Restivus;                                                                                                   // 1010
                                                                                                                     // 1011
})();                                                                                                                // 1012
                                                                                                                     // 1013
Restivus = this.Restivus;                                                                                            // 1014
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     // 1016
}).call(this);                                                                                                       // 1017
                                                                                                                     // 1018
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nimble:restivus'] = {
  Restivus: Restivus
};

})();

//# sourceMappingURL=nimble_restivus.js.map
