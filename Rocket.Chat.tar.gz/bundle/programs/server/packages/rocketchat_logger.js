(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var Random = Package.random.Random;
var Log = Package.logging.Log;
var colors = Package['nooitaf:colors'].colors;
var EventEmitter = Package['raix:eventemitter'].EventEmitter;

/* Package-scope variables */
var __coffeescriptShare, Logger;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                          //
// packages/rocketchat_logger/server.coffee.js                                                              //
//                                                                                                          //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                            //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var StdOut, processString,                                                                                  // 1
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty,                                                                              //
  slice = [].slice;                                                                                         //
                                                                                                            //
this.LoggerManager = new ((function(superClass) {                                                           // 1
  extend(_Class, superClass);                                                                               // 2
                                                                                                            //
  function _Class() {                                                                                       // 2
    this.enabled = false;                                                                                   // 3
    this.loggers = {};                                                                                      // 3
    this.queue = [];                                                                                        // 3
    this.showPackage = false;                                                                               // 3
    this.showFileAndLine = false;                                                                           // 3
    this.logLevel = 0;                                                                                      // 3
  }                                                                                                         //
                                                                                                            //
  _Class.prototype.register = function(logger) {                                                            // 2
    if (!logger instanceof Logger) {                                                                        // 12
      return;                                                                                               // 13
    }                                                                                                       //
    this.loggers[logger.name] = logger;                                                                     // 12
    return this.emit('register', logger);                                                                   //
  };                                                                                                        //
                                                                                                            //
  _Class.prototype.addToQueue = function(logger, args) {                                                    // 2
    return this.queue.push({                                                                                //
      logger: logger,                                                                                       // 21
      args: args                                                                                            // 21
    });                                                                                                     //
  };                                                                                                        //
                                                                                                            //
  _Class.prototype.dispatchQueue = function() {                                                             // 2
    var i, item, len1, ref;                                                                                 // 25
    ref = this.queue;                                                                                       // 25
    for (i = 0, len1 = ref.length; i < len1; i++) {                                                         // 25
      item = ref[i];                                                                                        //
      item.logger._log.apply(item.logger, item.args);                                                       // 26
    }                                                                                                       // 25
    return this.clearQueue();                                                                               //
  };                                                                                                        //
                                                                                                            //
  _Class.prototype.clearQueue = function() {                                                                // 2
    return this.queue = [];                                                                                 //
  };                                                                                                        //
                                                                                                            //
  _Class.prototype.disable = function() {                                                                   // 2
    return this.enabled = false;                                                                            //
  };                                                                                                        //
                                                                                                            //
  _Class.prototype.enable = function(dispatchQueue) {                                                       // 2
    if (dispatchQueue == null) {                                                                            //
      dispatchQueue = false;                                                                                //
    }                                                                                                       //
    this.enabled = true;                                                                                    // 37
    if (dispatchQueue === true) {                                                                           // 38
      return this.dispatchQueue();                                                                          //
    } else {                                                                                                //
      return this.clearQueue();                                                                             //
    }                                                                                                       //
  };                                                                                                        //
                                                                                                            //
  return _Class;                                                                                            //
                                                                                                            //
})(EventEmitter));                                                                                          //
                                                                                                            //
this.Logger = Logger = (function() {                                                                        // 1
  Logger.prototype.defaultTypes = {                                                                         // 49
    debug: {                                                                                                // 50
      name: 'debug',                                                                                        // 51
      color: 'blue',                                                                                        // 51
      level: 2                                                                                              // 51
    },                                                                                                      //
    log: {                                                                                                  // 50
      name: 'info',                                                                                         // 55
      color: 'blue',                                                                                        // 55
      level: 1                                                                                              // 55
    },                                                                                                      //
    info: {                                                                                                 // 50
      name: 'info',                                                                                         // 59
      color: 'blue',                                                                                        // 59
      level: 1                                                                                              // 59
    },                                                                                                      //
    success: {                                                                                              // 50
      name: 'info',                                                                                         // 63
      color: 'green',                                                                                       // 63
      level: 1                                                                                              // 63
    },                                                                                                      //
    warn: {                                                                                                 // 50
      name: 'warn',                                                                                         // 67
      color: 'magenta',                                                                                     // 67
      level: 1                                                                                              // 67
    },                                                                                                      //
    error: {                                                                                                // 50
      name: 'error',                                                                                        // 71
      color: 'red',                                                                                         // 71
      level: 0                                                                                              // 71
    }                                                                                                       //
  };                                                                                                        //
                                                                                                            //
  function Logger(name, config) {                                                                           // 75
    var fn, fn1, method, ref, ref1, type, typeConfig;                                                       // 76
    this.name = name;                                                                                       // 76
    if (config == null) {                                                                                   //
      config = {};                                                                                          //
    }                                                                                                       //
    this.config = {};                                                                                       // 76
    _.extend(this.config, config);                                                                          // 76
    if (LoggerManager.loggers[this.name] != null) {                                                         // 80
      LoggerManager.loggers[this.name].warn('Duplicated instance');                                         // 81
      return LoggerManager.loggers[this.name];                                                              // 82
    }                                                                                                       //
    ref = this.defaultTypes;                                                                                // 84
    fn = (function(_this) {                                                                                 // 84
      return function(type, typeConfig) {                                                                   //
        _this[type] = function() {                                                                          // 86
          var args;                                                                                         // 87
          args = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                     // 87
          return _this._log({                                                                               //
            type: type,                                                                                     // 88
            level: typeConfig.level,                                                                        // 88
            method: typeConfig.name,                                                                        // 88
            "arguments": args                                                                               // 88
          });                                                                                               //
        };                                                                                                  //
        return _this[type + "_box"] = function() {                                                          //
          var args;                                                                                         // 94
          args = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                     // 94
          return _this._log({                                                                               //
            type: type,                                                                                     // 95
            box: true,                                                                                      // 95
            level: typeConfig.level,                                                                        // 95
            method: typeConfig.name,                                                                        // 95
            "arguments": args                                                                               // 95
          });                                                                                               //
        };                                                                                                  //
      };                                                                                                    //
    })(this);                                                                                               //
    for (type in ref) {                                                                                     // 84
      typeConfig = ref[type];                                                                               //
      fn(type, typeConfig);                                                                                 // 85
    }                                                                                                       // 84
    if (this.config.methods != null) {                                                                      // 101
      ref1 = this.config.methods;                                                                           // 102
      fn1 = (function(_this) {                                                                              // 102
        return function(method, typeConfig) {                                                               //
          if (_this[method] != null) {                                                                      // 104
            _this.warn("Method", method, "already exists");                                                 // 105
          }                                                                                                 //
          if (_this.defaultTypes[typeConfig.type] == null) {                                                // 107
            _this.warn("Method type", typeConfig.type, "doest not exists");                                 // 108
          }                                                                                                 //
          _this[method] = function() {                                                                      // 104
            var args, ref2;                                                                                 // 111
            args = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                   // 111
            return _this._log({                                                                             //
              type: typeConfig.type,                                                                        // 112
              level: typeConfig.level != null ? typeConfig.level : (ref2 = _this.defaultTypes[typeConfig.type]) != null ? ref2.level : void 0,
              method: method,                                                                               // 112
              "arguments": args                                                                             // 112
            });                                                                                             //
          };                                                                                                //
          return _this[method + "_box"] = function() {                                                      //
            var args, ref2;                                                                                 // 118
            args = 1 <= arguments.length ? slice.call(arguments, 0) : [];                                   // 118
            return _this._log({                                                                             //
              type: typeConfig.type,                                                                        // 119
              box: true,                                                                                    // 119
              level: typeConfig.level != null ? typeConfig.level : (ref2 = _this.defaultTypes[typeConfig.type]) != null ? ref2.level : void 0,
              method: method,                                                                               // 119
              "arguments": args                                                                             // 119
            });                                                                                             //
          };                                                                                                //
        };                                                                                                  //
      })(this);                                                                                             //
      for (method in ref1) {                                                                                // 102
        typeConfig = ref1[method];                                                                          //
        fn1(method, typeConfig);                                                                            // 103
      }                                                                                                     // 102
    }                                                                                                       //
    LoggerManager.register(this);                                                                           // 76
    return this;                                                                                            // 126
  }                                                                                                         //
                                                                                                            //
  Logger.prototype.getPrefix = function(options) {                                                          // 49
    var detailParts, details, prefix;                                                                       // 129
    prefix = this.name + " ➔ " + options.method;                                                            // 129
    details = this._getCallerDetails();                                                                     // 129
    detailParts = [];                                                                                       // 129
    if ((details["package"] != null) && (LoggerManager.showPackage === true || options.type === 'error')) {
      detailParts.push(details["package"]);                                                                 // 135
    }                                                                                                       //
    if (LoggerManager.showFileAndLine === true || options.type === 'error') {                               // 137
      if ((details.file != null) && (details.line != null)) {                                               // 138
        detailParts.push(details.file + ":" + details.line);                                                // 139
      } else {                                                                                              //
        if (details.file != null) {                                                                         // 141
          detailParts.push(details.file);                                                                   // 142
        }                                                                                                   //
        if (details.line != null) {                                                                         // 143
          detailParts.push(details.line);                                                                   // 144
        }                                                                                                   //
      }                                                                                                     //
    }                                                                                                       //
    if (this.defaultTypes[options.type] != null) {                                                          // 146
      prefix = prefix[this.defaultTypes[options.type].color];                                               // 147
    }                                                                                                       //
    if (detailParts.length > 0) {                                                                           // 149
      prefix = (detailParts.join(' ')) + " " + prefix;                                                      // 150
    }                                                                                                       //
    return prefix;                                                                                          // 152
  };                                                                                                        //
                                                                                                            //
  Logger.prototype._getCallerDetails = function() {                                                         // 49
    var details, getStack, i, index, item, len1, line, lines, match, packageMatch, stack;                   // 156
    getStack = function() {                                                                                 // 156
      var err, stack;                                                                                       // 160
      err = new Error;                                                                                      // 160
      stack = err.stack;                                                                                    // 160
      return stack;                                                                                         // 162
    };                                                                                                      //
    stack = getStack();                                                                                     // 156
    if (!stack) {                                                                                           // 166
      return {};                                                                                            // 167
    }                                                                                                       //
    lines = stack.split('\n');                                                                              // 156
    line = void 0;                                                                                          // 156
    for (index = i = 0, len1 = lines.length; i < len1; index = ++i) {                                       // 174
      item = lines[index];                                                                                  //
      if (!(index > 0)) {                                                                                   //
        continue;                                                                                           //
      }                                                                                                     //
      line = item;                                                                                          // 175
      if (line.match(/^\s*at eval \(eval/)) {                                                               // 176
        return {                                                                                            // 177
          file: "eval"                                                                                      // 177
        };                                                                                                  //
      }                                                                                                     //
      if (!line.match(/packages\/rocketchat_logger(?:\/|\.js)/)) {                                          // 179
        break;                                                                                              // 180
      }                                                                                                     //
    }                                                                                                       // 174
    details = {};                                                                                           // 156
    match = /(?:[@(]| at )([^(]+?):([0-9:]+)(?:\)|$)/.exec(line);                                           // 156
    if (!match) {                                                                                           // 188
      return details;                                                                                       // 189
    }                                                                                                       //
    details.line = match[2].split(':')[0];                                                                  // 156
    details.file = match[1].split('/').slice(-1)[0].split('?')[0];                                          // 156
    packageMatch = match[1].match(/packages\/([^\.\/]+)(?:\/|\.)/);                                         // 156
    if (packageMatch != null) {                                                                             // 199
      details["package"] = packageMatch[1];                                                                 // 200
    }                                                                                                       //
    return details;                                                                                         // 202
  };                                                                                                        //
                                                                                                            //
  Logger.prototype.makeABox = function(message, title) {                                                    // 49
    var i, j, len, len1, len2, line, lines, separator, topLine;                                             // 205
    if (!_.isArray(message)) {                                                                              // 205
      message = message.split("\n");                                                                        // 206
    }                                                                                                       //
    len = 0;                                                                                                // 205
    for (i = 0, len1 = message.length; i < len1; i++) {                                                     // 209
      line = message[i];                                                                                    //
      len = Math.max(len, line.length);                                                                     // 210
    }                                                                                                       // 209
    topLine = "+--" + s.pad('', len, '-') + "--+";                                                          // 205
    separator = "|  " + s.pad('', len, '') + "  |";                                                         // 205
    lines = [];                                                                                             // 205
    lines.push(topLine);                                                                                    // 205
    if (title != null) {                                                                                    // 217
      lines.push("|  " + s.lrpad(title, len) + "  |");                                                      // 218
      lines.push(topLine);                                                                                  // 218
    }                                                                                                       //
    lines.push(separator);                                                                                  // 205
    for (j = 0, len2 = message.length; j < len2; j++) {                                                     // 223
      line = message[j];                                                                                    //
      lines.push("|  " + s.rpad(line, len) + "  |");                                                        // 224
    }                                                                                                       // 223
    lines.push(separator);                                                                                  // 205
    lines.push(topLine);                                                                                    // 205
    return lines;                                                                                           // 228
  };                                                                                                        //
                                                                                                            //
  Logger.prototype._log = function(options) {                                                               // 49
    var box, color, i, len1, line, prefix, subPrefix;                                                       // 232
    if (LoggerManager.enabled === false) {                                                                  // 232
      LoggerManager.addToQueue(this, arguments);                                                            // 233
      return;                                                                                               // 234
    }                                                                                                       //
    if (options.level == null) {                                                                            //
      options.level = 1;                                                                                    //
    }                                                                                                       //
    if (LoggerManager.logLevel < options.level) {                                                           // 238
      return;                                                                                               // 239
    }                                                                                                       //
    prefix = this.getPrefix(options);                                                                       // 232
    if (options.box === true && _.isString(options["arguments"][0])) {                                      // 243
      color = void 0;                                                                                       // 244
      if (this.defaultTypes[options.type] != null) {                                                        // 245
        color = this.defaultTypes[options.type].color;                                                      // 246
      }                                                                                                     //
      box = this.makeABox(options["arguments"][0], options["arguments"][1]);                                // 244
      subPrefix = '➔';                                                                                      // 244
      if (color != null) {                                                                                  // 250
        subPrefix = subPrefix[color];                                                                       // 251
      }                                                                                                     //
      console.log(subPrefix, prefix);                                                                       // 244
      for (i = 0, len1 = box.length; i < len1; i++) {                                                       // 254
        line = box[i];                                                                                      //
        if (color != null) {                                                                                // 255
          console.log(subPrefix, line[color]);                                                              // 256
        } else {                                                                                            //
          console.log(subPrefix, line);                                                                     // 258
        }                                                                                                   //
      }                                                                                                     // 254
    } else {                                                                                                //
      options["arguments"].unshift(prefix);                                                                 // 260
      console.log.apply(console, options["arguments"]);                                                     // 260
    }                                                                                                       //
  };                                                                                                        //
                                                                                                            //
  return Logger;                                                                                            //
                                                                                                            //
})();                                                                                                       //
                                                                                                            //
this.SystemLogger = new Logger('System', {                                                                  // 1
  methods: {                                                                                                // 267
    startup: {                                                                                              // 268
      type: 'success',                                                                                      // 269
      level: 0                                                                                              // 269
    }                                                                                                       //
  }                                                                                                         //
});                                                                                                         //
                                                                                                            //
processString = function(string, date) {                                                                    // 1
  if (string[0] === '{') {                                                                                  // 274
    try {                                                                                                   // 275
      return Log.format(EJSON.parse(string), {                                                              // 276
        color: true                                                                                         // 276
      });                                                                                                   //
    } catch (_error) {}                                                                                     //
  }                                                                                                         //
  try {                                                                                                     // 278
    return Log.format({                                                                                     // 279
      message: string,                                                                                      // 279
      time: date,                                                                                           // 279
      level: 'info'                                                                                         // 279
    }, {                                                                                                    //
      color: true                                                                                           // 279
    });                                                                                                     //
  } catch (_error) {}                                                                                       //
  return string;                                                                                            // 281
};                                                                                                          // 273
                                                                                                            //
StdOut = new ((function(superClass) {                                                                       // 1
  extend(_Class, superClass);                                                                               // 284
                                                                                                            //
  function _Class() {                                                                                       // 284
    var write;                                                                                              // 285
    this.queue = [];                                                                                        // 285
    write = process.stdout.write;                                                                           // 285
    process.stdout.write = (function(_this) {                                                               // 285
      return function(string, encoding, fd) {                                                               //
        var date, item, ref;                                                                                // 288
        write.apply(process.stdout, arguments);                                                             // 288
        date = new Date;                                                                                    // 288
        string = processString(string, date);                                                               // 288
        item = {                                                                                            // 288
          id: Random.id(),                                                                                  // 293
          string: string,                                                                                   // 293
          ts: date                                                                                          // 293
        };                                                                                                  //
        _this.queue.push(item);                                                                             // 288
        if (((typeof RocketChat !== "undefined" && RocketChat !== null ? (ref = RocketChat.settings) != null ? ref.get('Log_View_Limit') : void 0 : void 0) != null) && _this.queue.length > RocketChat.settings.get('Log_View_Limit')) {
          _this.queue.shift();                                                                              // 300
        }                                                                                                   //
        return _this.emit('write', string, item);                                                           //
      };                                                                                                    //
    })(this);                                                                                               //
  }                                                                                                         //
                                                                                                            //
  return _Class;                                                                                            //
                                                                                                            //
})(EventEmitter));                                                                                          //
                                                                                                            //
Meteor.publish('stdout', function() {                                                                       // 1
  var i, item, len1, ref;                                                                                   // 306
  if (!this.userId) {                                                                                       // 306
    return this.ready();                                                                                    // 307
  }                                                                                                         //
  if (RocketChat.authz.hasPermission(this.userId, 'view-logs') !== true) {                                  // 309
    return this.ready();                                                                                    // 310
  }                                                                                                         //
  ref = StdOut.queue;                                                                                       // 312
  for (i = 0, len1 = ref.length; i < len1; i++) {                                                           // 312
    item = ref[i];                                                                                          //
    this.added('stdout', item.id, {                                                                         // 313
      string: item.string,                                                                                  // 314
      ts: item.ts                                                                                           // 314
    });                                                                                                     //
  }                                                                                                         // 312
  this.ready();                                                                                             // 306
  StdOut.on('write', (function(_this) {                                                                     // 306
    return function(string, item) {                                                                         //
      return _this.added('stdout', item.id, {                                                               //
        string: item.string,                                                                                // 321
        ts: item.ts                                                                                         // 321
      });                                                                                                   //
    };                                                                                                      //
  })(this));                                                                                                //
});                                                                                                         // 305
                                                                                                            //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:logger'] = {
  Logger: Logger
};

})();

//# sourceMappingURL=rocketchat_logger.js.map
