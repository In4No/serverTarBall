(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Errors;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/tmeasday_errors/packages/tmeasday_errors.js              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['tmeasday:errors'] = {
  Errors: Errors
};

})();

//# sourceMappingURL=tmeasday_errors.js.map
