(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var RateLimiter = Package['rate-limit'].RateLimiter;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var ReactiveDict = Package['reactive-dict'].ReactiveDict;
var ECMAScript = Package.ecmascript.ECMAScript;
var Random = Package.random.Random;
var check = Package.check.check;
var Match = Package.check.Match;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var DDPRateLimiter = Package['ddp-rate-limiter'].DDPRateLimiter;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var s = Package['underscorestring:underscore.string'].s;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var Logger = Package['rocketchat:logger'].Logger;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var __coffeescriptShare, RocketChat, emailValidation, user, translations;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/lib/core.coffee.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                                                       // 1
/*                                                                                                                     // 1
 * Kick off the global namespace for RocketChat.                                                                       //
 * @namespace RocketChat                                                                                               //
 */                                                                                                                    //
                                                                                                                       // 1
                                                                                                                       //
RocketChat = {                                                                                                         // 1
  models: {}                                                                                                           // 7
};                                                                                                                     //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/lib/debug.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
RocketChat.debugLevel = 'debug';                                                                                       // 1
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 3
	RocketChat.settings.onload('Debug_Level', function (key, value, initialLoad) {                                        // 4
		if (value) {                                                                                                         // 5
			RocketChat.debugLevel = value;                                                                                      // 6
		}                                                                                                                    //
	});                                                                                                                   //
                                                                                                                       //
	var value = RocketChat.settings.get('Debug_Level');                                                                   // 10
	if (value) {                                                                                                          // 11
		RocketChat.debugLevel = value;                                                                                       // 12
	}                                                                                                                     //
});                                                                                                                    //
                                                                                                                       //
var wrapMethods = function (name, originalHandler, methodsMap) {                                                       // 16
	methodsMap[name] = function () {                                                                                      // 17
		if (RocketChat.debugLevel === 'debug') {                                                                             // 18
			var args = name === "ufsWrite" ? Array.prototype.slice.call(arguments, 1) : arguments;                              // 19
			console.log('[methods]'.green, name, '-> userId:', Meteor.userId(), ', arguments: ', args);                         // 20
		}                                                                                                                    //
                                                                                                                       //
		return originalHandler.apply(this, arguments);                                                                       // 23
	};                                                                                                                    //
};                                                                                                                     //
                                                                                                                       //
var originalMeteorMethods = Meteor.methods;                                                                            // 27
                                                                                                                       //
Meteor.methods = function (methodMap) {                                                                                // 29
	_.each(methodMap, function (handler, name) {                                                                          // 30
		wrapMethods(name, handler, methodMap);                                                                               // 31
	});                                                                                                                   //
	originalMeteorMethods(methodMap);                                                                                     // 33
};                                                                                                                     //
                                                                                                                       //
var originalMeteorPublish = Meteor.publish;                                                                            // 36
                                                                                                                       //
Meteor.publish = function (name, func) {                                                                               // 38
	return originalMeteorPublish(name, function () {                                                                      // 39
		if (RocketChat.debugLevel === 'debug') {                                                                             // 40
			console.log('[publish]'.green, name, '-> userId:', this.userId, ', arguments: ', arguments);                        // 41
		}                                                                                                                    //
                                                                                                                       //
		return func.apply(this, arguments);                                                                                  // 44
	});                                                                                                                   //
};                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/lib/settings.coffee.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                                                       // 1
/*                                                                                                                     // 1
 * RocketChat.settings holds all packages settings                                                                     //
 * @namespace RocketChat.settings                                                                                      //
 */                                                                                                                    //
RocketChat.settings = {                                                                                                // 1
  callbacks: {},                                                                                                       // 6
  ts: new Date,                                                                                                        // 6
  get: function(_id) {                                                                                                 // 6
    var ref;                                                                                                           // 10
    return (ref = Meteor.settings) != null ? ref[_id] : void 0;                                                        // 10
  },                                                                                                                   //
  get: function(_id, callback) {                                                                                       // 6
    var ref, ref1, ref2;                                                                                               // 13
    if (callback != null) {                                                                                            // 13
      RocketChat.settings.onload(_id, callback);                                                                       // 14
      if (((ref = Meteor.settings) != null ? ref[_id] : void 0) != null) {                                             // 15
        return callback(_id, (ref1 = Meteor.settings) != null ? ref1[_id] : void 0);                                   //
      }                                                                                                                //
    } else {                                                                                                           //
      return (ref2 = Meteor.settings) != null ? ref2[_id] : void 0;                                                    // 18
    }                                                                                                                  //
  },                                                                                                                   //
  set: function(_id, value, callback) {                                                                                // 6
    return Meteor.call('saveSetting', _id, value, callback);                                                           //
  },                                                                                                                   //
  batchSet: function(settings, callback) {                                                                             // 6
    var actions, save;                                                                                                 // 28
    save = function(setting) {                                                                                         // 28
      return function(callback) {                                                                                      // 29
        return Meteor.call('saveSetting', setting._id, setting.value, callback);                                       //
      };                                                                                                               //
    };                                                                                                                 //
    actions = _.map(settings, function(setting) {                                                                      // 28
      return save(setting);                                                                                            //
    });                                                                                                                //
    return _(actions).reduceRight(_.wrap, function(err, success) {                                                     //
      return callback(err, success);                                                                                   // 33
    })();                                                                                                              //
  },                                                                                                                   //
  load: function(key, value, initialLoad) {                                                                            // 6
    var callback, i, j, len, len1, ref, ref1, results;                                                                 // 36
    if (RocketChat.settings.callbacks[key] != null) {                                                                  // 36
      ref = RocketChat.settings.callbacks[key];                                                                        // 37
      for (i = 0, len = ref.length; i < len; i++) {                                                                    // 37
        callback = ref[i];                                                                                             //
        callback(key, value, initialLoad);                                                                             // 38
      }                                                                                                                // 37
    }                                                                                                                  //
    if (RocketChat.settings.callbacks['*'] != null) {                                                                  // 40
      ref1 = RocketChat.settings.callbacks['*'];                                                                       // 41
      results = [];                                                                                                    // 41
      for (j = 0, len1 = ref1.length; j < len1; j++) {                                                                 //
        callback = ref1[j];                                                                                            //
        results.push(callback(key, value, initialLoad));                                                               // 42
      }                                                                                                                // 41
      return results;                                                                                                  //
    }                                                                                                                  //
  },                                                                                                                   //
  onload: function(key, callback) {                                                                                    // 6
    var base, i, k, keys, len, results;                                                                                // 52
    keys = [].concat(key);                                                                                             // 52
    results = [];                                                                                                      // 54
    for (i = 0, len = keys.length; i < len; i++) {                                                                     //
      k = keys[i];                                                                                                     //
      if ((base = RocketChat.settings.callbacks)[k] == null) {                                                         //
        base[k] = [];                                                                                                  //
      }                                                                                                                //
      results.push(RocketChat.settings.callbacks[k].push(callback));                                                   // 55
    }                                                                                                                  // 54
    return results;                                                                                                    //
  }                                                                                                                    //
};                                                                                                                     //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/lib/configLogger.coffee.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.settings.get('Log_Package', function(key, value) {                                                          // 1
  return typeof LoggerManager !== "undefined" && LoggerManager !== null ? LoggerManager.showPackage = value : void 0;  //
});                                                                                                                    // 1
                                                                                                                       //
RocketChat.settings.get('Log_File', function(key, value) {                                                             // 1
  return typeof LoggerManager !== "undefined" && LoggerManager !== null ? LoggerManager.showFileAndLine = value : void 0;
});                                                                                                                    // 4
                                                                                                                       //
RocketChat.settings.get('Log_Level', function(key, value) {                                                            // 1
  if (value != null) {                                                                                                 // 8
    if (typeof LoggerManager !== "undefined" && LoggerManager !== null) {                                              //
      LoggerManager.logLevel = parseInt(value);                                                                        //
    }                                                                                                                  //
    return Meteor.setTimeout(function() {                                                                              //
      return typeof LoggerManager !== "undefined" && LoggerManager !== null ? LoggerManager.enable(true) : void 0;     //
    }, 200);                                                                                                           //
  }                                                                                                                    //
});                                                                                                                    // 7
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/lib/callbacks.coffee.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
                                                                                                                       // 3
/*                                                                                                                     // 3
 * Callback hooks provide an easy way to add extra steps to common operations.                                         //
 * @namespace RocketChat.callbacks                                                                                     //
 */                                                                                                                    //
RocketChat.callbacks = {};                                                                                             // 3
                                                                                                                       //
                                                                                                                       // 9
/*                                                                                                                     // 9
 * Callback priorities                                                                                                 //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.callbacks.priority = {                                                                                      // 3
  HIGH: -1000,                                                                                                         // 13
  MEDIUM: 0,                                                                                                           // 13
  LOW: 1000                                                                                                            // 13
};                                                                                                                     //
                                                                                                                       //
                                                                                                                       // 17
/*                                                                                                                     // 17
 * Add a callback function to a hook                                                                                   //
 * @param {String} hook - The name of the hook                                                                         //
 * @param {Function} callback - The callback function                                                                  //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.callbacks.add = function(hook, callback, priority, id) {                                                    // 3
  var base, cb, i, len, ref;                                                                                           // 25
  if (priority == null) {                                                                                              //
    priority = RocketChat.callbacks.priority.MEDIUM;                                                                   //
  }                                                                                                                    //
  if (!_.isNumber(priority)) {                                                                                         // 26
    priority = RocketChat.callbacks.priority.MEDIUM;                                                                   // 27
  }                                                                                                                    //
  callback.priority = priority;                                                                                        // 25
  callback.id = id || Random.id();                                                                                     // 25
  if ((base = RocketChat.callbacks)[hook] == null) {                                                                   //
    base[hook] = [];                                                                                                   //
  }                                                                                                                    //
  ref = RocketChat.callbacks[hook];                                                                                    // 33
  for (i = 0, len = ref.length; i < len; i++) {                                                                        // 33
    cb = ref[i];                                                                                                       //
    if (cb.id === callback.id) {                                                                                       // 34
      return;                                                                                                          // 35
    }                                                                                                                  //
  }                                                                                                                    // 33
  RocketChat.callbacks[hook].push(callback);                                                                           // 25
};                                                                                                                     // 23
                                                                                                                       //
                                                                                                                       // 40
/*                                                                                                                     // 40
 * Remove a callback from a hook                                                                                       //
 * @param {string} hook - The name of the hook                                                                         //
 * @param {string} id - The callback's id                                                                              //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.callbacks.remove = function(hookName, id) {                                                                 // 3
  RocketChat.callbacks[hookName] = _.reject(RocketChat.callbacks[hookName], function(callback) {                       // 47
    return callback.id === id;                                                                                         //
  });                                                                                                                  //
};                                                                                                                     // 46
                                                                                                                       //
                                                                                                                       // 51
/*                                                                                                                     // 51
 * Successively run all of a hook's callbacks on an item                                                               //
 * @param {String} hook - The name of the hook                                                                         //
 * @param {Object} item - The post, comment, modifier, etc. on which to run the callbacks                              //
 * @param {Object} [constant] - An optional constant that will be passed along to each callback                        //
 * @returns {Object} Returns the item after it's been through all the callbacks for this hook                          //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.callbacks.run = function(hook, item, constant) {                                                            // 3
  var callbacks;                                                                                                       // 60
  callbacks = RocketChat.callbacks[hook];                                                                              // 60
  if (!!(callbacks != null ? callbacks.length : void 0)) {                                                             // 61
    return _.sortBy(callbacks, function(callback) {                                                                    //
      return callback.priority || RocketChat.callbacks.priority.MEDIUM;                                                // 63
    }).reduce(function(result, callback) {                                                                             //
      return callback(result, constant);                                                                               //
    }, item);                                                                                                          //
  } else {                                                                                                             //
    return item;                                                                                                       //
  }                                                                                                                    //
};                                                                                                                     // 59
                                                                                                                       //
                                                                                                                       // 71
/*                                                                                                                     // 71
 * Successively run all of a hook's callbacks on an item, in async mode (only works on server)                         //
 * @param {String} hook - The name of the hook                                                                         //
 * @param {Object} item - The post, comment, modifier, etc. on which to run the callbacks                              //
 * @param {Object} [constant] - An optional constant that will be passed along to each callback                        //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.callbacks.runAsync = function(hook, item, constant) {                                                       // 3
  var callbacks;                                                                                                       // 79
  callbacks = RocketChat.callbacks[hook];                                                                              // 79
  if (Meteor.isServer && !!(callbacks != null ? callbacks.length : void 0)) {                                          // 80
    Meteor.defer(function() {                                                                                          // 82
      _.sortBy(callbacks, function(callback) {                                                                         // 84
        return callback.priority || RocketChat.callbacks.priority.MEDIUM;                                              // 84
      }).forEach(function(callback) {                                                                                  //
        callback(item, constant);                                                                                      // 86
      });                                                                                                              //
    });                                                                                                                //
  } else {                                                                                                             //
    return item;                                                                                                       // 90
  }                                                                                                                    //
};                                                                                                                     // 78
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/lib/slashCommand.coffee.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.slashCommands = {                                                                                           // 1
  commands: {}                                                                                                         // 2
};                                                                                                                     //
                                                                                                                       //
RocketChat.slashCommands.add = function(command, callback, options) {                                                  // 1
  RocketChat.slashCommands.commands[command] = {                                                                       // 5
    command: command,                                                                                                  // 6
    callback: callback,                                                                                                // 6
    params: options != null ? options.params : void 0,                                                                 // 6
    description: options != null ? options.description : void 0                                                        // 6
  };                                                                                                                   //
};                                                                                                                     // 4
                                                                                                                       //
RocketChat.slashCommands.run = function(command, params, item) {                                                       // 1
  var callback, ref;                                                                                                   // 14
  if (((ref = RocketChat.slashCommands.commands[command]) != null ? ref.callback : void 0) != null) {                  // 14
    callback = RocketChat.slashCommands.commands[command].callback;                                                    // 15
    return callback(command, params, item);                                                                            //
  }                                                                                                                    //
};                                                                                                                     // 13
                                                                                                                       //
Meteor.methods({                                                                                                       // 1
  slashCommand: function(command) {                                                                                    // 20
    if (!Meteor.userId()) {                                                                                            // 21
      throw new Meteor.Error(203, t('User_logged_out'));                                                               // 22
    }                                                                                                                  //
    return RocketChat.slashCommands.run(command.cmd, command.params, command.msg);                                     //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/lib/Message.coffee.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.Message = {                                                                                                 // 1
  parse: function(msg, language) {                                                                                     // 2
    var messageType, ref;                                                                                              // 3
    messageType = RocketChat.MessageTypes.getType(msg);                                                                // 3
    if ((messageType != null ? messageType.render : void 0) != null) {                                                 // 4
      return messageType.render(msg);                                                                                  // 5
    } else if ((messageType != null ? messageType.template : void 0) != null) {                                        //
                                                                                                                       // 6
    } else if ((messageType != null ? messageType.message : void 0) != null) {                                         //
      if (!language && (typeof localStorage !== "undefined" && localStorage !== null ? localStorage.getItem('userLanguage') : void 0)) {
        language = localStorage.getItem('userLanguage');                                                               // 10
      }                                                                                                                //
      if ((typeof messageType.data === "function" ? messageType.data(msg) : void 0) != null) {                         // 11
        return TAPi18n.__(messageType.message, messageType.data(msg), language);                                       // 12
      } else {                                                                                                         //
        return TAPi18n.__(messageType.message, {}, language);                                                          // 14
      }                                                                                                                //
    } else {                                                                                                           //
      if (((ref = msg.u) != null ? ref.username : void 0) === RocketChat.settings.get('Chatops_Username')) {           // 16
        msg.html = msg.msg;                                                                                            // 17
        return msg.html;                                                                                               // 18
      }                                                                                                                //
      msg.html = msg.msg;                                                                                              // 16
      if (_.trim(msg.html) !== '') {                                                                                   // 21
        msg.html = _.escapeHTML(msg.html);                                                                             // 22
      }                                                                                                                //
      msg.html = msg.html.replace(/\n/gm, '<br/>');                                                                    // 16
      return msg.html;                                                                                                 // 26
    }                                                                                                                  //
  }                                                                                                                    //
};                                                                                                                     //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/lib/MessageTypes.coffee.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.MessageTypes = new ((function() {                                                                           // 1
  var getType, isSystemMessage, registerType, types;                                                                   // 2
                                                                                                                       //
  function _Class() {}                                                                                                 //
                                                                                                                       //
  types = {};                                                                                                          // 2
                                                                                                                       //
  registerType = function(options) {                                                                                   // 2
    return types[options.id] = options;                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  getType = function(message) {                                                                                        // 2
    return types[message != null ? message.t : void 0];                                                                // 8
  };                                                                                                                   //
                                                                                                                       //
  isSystemMessage = function(message) {                                                                                // 2
    var ref;                                                                                                           // 11
    return (ref = types[message != null ? message.t : void 0]) != null ? ref.system : void 0;                          // 11
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.registerType = registerType;                                                                        // 2
                                                                                                                       //
  _Class.prototype.getType = getType;                                                                                  // 2
                                                                                                                       //
  _Class.prototype.isSystemMessage = isSystemMessage;                                                                  // 2
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})());                                                                                                                 //
                                                                                                                       //
Meteor.startup(function() {                                                                                            // 1
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'r',                                                                                                           // 19
    system: true,                                                                                                      // 19
    message: 'Room_name_changed',                                                                                      // 19
    data: function(message) {                                                                                          // 19
      return {                                                                                                         // 23
        room_name: message.msg,                                                                                        // 23
        user_by: message.u.username                                                                                    // 23
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'au',                                                                                                          // 26
    system: true,                                                                                                      // 26
    message: 'User_added_by',                                                                                          // 26
    data: function(message) {                                                                                          // 26
      return {                                                                                                         // 30
        user_added: message.msg,                                                                                       // 30
        user_by: message.u.username                                                                                    // 30
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'ru',                                                                                                          // 33
    system: true,                                                                                                      // 33
    message: 'User_removed_by',                                                                                        // 33
    data: function(message) {                                                                                          // 33
      return {                                                                                                         // 37
        user_removed: message.msg,                                                                                     // 37
        user_by: message.u.username                                                                                    // 37
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'ul',                                                                                                          // 40
    system: true,                                                                                                      // 40
    message: 'User_left',                                                                                              // 40
    data: function(message) {                                                                                          // 40
      return {                                                                                                         // 44
        user_left: message.u.username                                                                                  // 44
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'uj',                                                                                                          // 47
    system: true,                                                                                                      // 47
    message: 'User_joined_channel',                                                                                    // 47
    data: function(message) {                                                                                          // 47
      return {                                                                                                         // 51
        user: message.u.username                                                                                       // 51
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'wm',                                                                                                          // 54
    system: true,                                                                                                      // 54
    message: 'Welcome',                                                                                                // 54
    data: function(message) {                                                                                          // 54
      return {                                                                                                         // 58
        user: message.u.username                                                                                       // 58
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'rm',                                                                                                          // 61
    system: true,                                                                                                      // 61
    message: 'Message_removed',                                                                                        // 61
    data: function(message) {                                                                                          // 61
      return {                                                                                                         // 65
        user: message.u.username                                                                                       // 65
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'rtc',                                                                                                         // 68
    render: function(message) {                                                                                        // 68
      return RocketChat.callbacks.run('renderRtcMessage', message);                                                    //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'user-muted',                                                                                                  // 73
    system: true,                                                                                                      // 73
    message: 'User_muted_by',                                                                                          // 73
    data: function(message) {                                                                                          // 73
      return {                                                                                                         // 77
        user_muted: message.msg,                                                                                       // 77
        user_by: message.u.username                                                                                    // 77
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'user-unmuted',                                                                                                // 80
    system: true,                                                                                                      // 80
    message: 'User_unmuted_by',                                                                                        // 80
    data: function(message) {                                                                                          // 80
      return {                                                                                                         // 84
        user_unmuted: message.msg,                                                                                     // 84
        user_by: message.u.username                                                                                    // 84
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'new-moderator',                                                                                               // 87
    system: true,                                                                                                      // 87
    message: 'User__username__was_added_as_a_moderator_by__user_by_',                                                  // 87
    data: function(message) {                                                                                          // 87
      return {                                                                                                         // 91
        username: message.msg,                                                                                         // 91
        user_by: message.u.username                                                                                    // 91
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'moderator-removed',                                                                                           // 94
    system: true,                                                                                                      // 94
    message: 'User__username__was_removed_as_a_moderator_by__user_by_',                                                // 94
    data: function(message) {                                                                                          // 94
      return {                                                                                                         // 98
        username: message.msg,                                                                                         // 98
        user_by: message.u.username                                                                                    // 98
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  RocketChat.MessageTypes.registerType({                                                                               // 18
    id: 'new-owner',                                                                                                   // 101
    system: true,                                                                                                      // 101
    message: 'User__username__was_added_as_a_owner_by__user_by_',                                                      // 101
    data: function(message) {                                                                                          // 101
      return {                                                                                                         // 105
        username: message.msg,                                                                                         // 105
        user_by: message.u.username                                                                                    // 105
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
  return RocketChat.MessageTypes.registerType({                                                                        //
    id: 'owner-removed',                                                                                               // 108
    system: true,                                                                                                      // 108
    message: 'User__username__was_removed_as_a_owner_by__user_by_',                                                    // 108
    data: function(message) {                                                                                          // 108
      return {                                                                                                         // 112
        username: message.msg,                                                                                         // 112
        user_by: message.u.username                                                                                    // 112
      };                                                                                                               //
    }                                                                                                                  //
  });                                                                                                                  //
});                                                                                                                    // 17
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/lib/RateLimiter.coffee.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.RateLimiter = new ((function() {                                                                            // 1
  function _Class() {}                                                                                                 //
                                                                                                                       //
  _Class.prototype.limitFunction = function(fn, numRequests, timeInterval, matchers) {                                 // 2
    var rateLimiter;                                                                                                   // 3
    rateLimiter = new RateLimiter();                                                                                   // 3
    rateLimiter.addRule(matchers, numRequests, timeInterval);                                                          // 3
    return function() {                                                                                                // 5
      var args, match, rateLimitResult;                                                                                // 6
      match = {};                                                                                                      // 6
      args = arguments;                                                                                                // 6
      _.each(matchers, function(matcher, key) {                                                                        // 6
        return match[key] = args[key];                                                                                 //
      });                                                                                                              //
      rateLimiter.increment(match);                                                                                    // 6
      rateLimitResult = rateLimiter.check(match);                                                                      // 6
      if (rateLimitResult.allowed) {                                                                                   // 13
        return fn.apply(null, arguments);                                                                              // 14
      } else {                                                                                                         //
        throw new Meteor.Error('too-many-requests', "Error, too many requests. Please slow down. You must wait " + (Math.ceil(rateLimitResult.timeToReset / 1000)) + " seconds before trying again.", {
          timeToReset: rateLimitResult.timeToReset                                                                     // 16
        });                                                                                                            //
      }                                                                                                                //
    };                                                                                                                 //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.limitMethod = function(methodName, numRequests, timeInterval, matchers) {                           // 2
    var match;                                                                                                         // 19
    match = {                                                                                                          // 19
      type: 'method',                                                                                                  // 20
      name: methodName                                                                                                 // 20
    };                                                                                                                 //
    _.each(matchers, function(matcher, key) {                                                                          // 19
      return match[key] = matchers[key];                                                                               //
    });                                                                                                                //
    return DDPRateLimiter.addRule(match, numRequests, timeInterval);                                                   //
  };                                                                                                                   //
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})());                                                                                                                 //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/lib/roomTypes.coffee.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.roomTypes = new ((function() {                                                                              // 1
  var roomTypes, runPublish, setPublish;                                                                               // 2
                                                                                                                       //
  function _Class() {}                                                                                                 //
                                                                                                                       //
  roomTypes = {};                                                                                                      // 2
                                                                                                                       //
                                                                                                                       // 4
  /* add a publish for a room type                                                                                     // 4
  	@param roomType: room type (e.g.: c (for channels), d (for direct channels))                                        //
  	@param callback: function that will return the publish's data                                                       //
   */                                                                                                                  //
                                                                                                                       //
  setPublish = function(roomType, callback) {                                                                          // 2
    var ref;                                                                                                           // 9
    if (((ref = roomTypes[roomType]) != null ? ref.publish : void 0) != null) {                                        // 9
      throw new Meteor.Error('route-publish-exists', 'Publish for the given type already exists');                     // 10
    }                                                                                                                  //
    if (roomTypes[roomType] == null) {                                                                                 // 12
      roomTypes[roomType] = {};                                                                                        // 13
    }                                                                                                                  //
    return roomTypes[roomType].publish = callback;                                                                     //
  };                                                                                                                   //
                                                                                                                       //
                                                                                                                       // 17
  /* run the publish for a room type                                                                                   // 17
  	@param roomType: room type (e.g.: c (for channels), d (for direct channels))                                        //
  	@param identifier: identifier of the room                                                                           //
   */                                                                                                                  //
                                                                                                                       //
  runPublish = function(roomType, identifier) {                                                                        // 2
    if (roomTypes[roomType].publish == null) {                                                                         // 22
      return;                                                                                                          // 22
    }                                                                                                                  //
    return roomTypes[roomType].publish.call(this, identifier);                                                         // 23
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setPublish = setPublish;                                                                            // 2
                                                                                                                       //
  _Class.prototype.runPublish = runPublish;                                                                            // 2
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})());                                                                                                                 //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/lib/sendNotificationsOnMessage.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
RocketChat.callbacks.add('afterSaveMessage', function (message, room) {                                                // 1
	// skips this callback if the message was edited                                                                      //
	if (message.editedAt) {                                                                                               // 3
		return message;                                                                                                      // 4
	}                                                                                                                     //
                                                                                                                       //
	var user = RocketChat.models.Users.findOneById(message.u._id);                                                        // 7
                                                                                                                       //
	/*                                                                                                                    //
 Increment unread couter if direct messages                                                                            //
  */                                                                                                                   //
	var indexOf = [].indexOf || function (item) {                                                                         // 12
		for (var i = 0, l = this.length; i < l; i++) {                                                                       // 12
			if (i in this && this[i] === item) return i;                                                                        // 12
		}return -1;                                                                                                          //
	};                                                                                                                    //
                                                                                                                       //
	var alwaysNotifyDesktopUsers, alwaysNotifyMobileUsers, desktopMentionIds, dontNotifyDesktopUsers, dontNotifyMobileUsers, i, j, len, len1, mentionIds, mobileMentionIds, ref, ref1, toAll, userIdsToNotify, userIdsToPushNotify, userOfMention, userOfMentionId, usersOfDesktopMentions, usersOfMentionId, usersOfMentionItem, usersOfMobileMentions, usersOfRoom;
                                                                                                                       //
	alwaysNotifyDesktopUsers = _.compact(_.map(RocketChat.models.Subscriptions.findAlwaysNotifyDesktopUsersByRoomId(room._id).fetch(), function (subscription) {
		var ref;                                                                                                             // 17
		return subscription != null ? (ref = subscription.u) != null ? ref._id : void 0 : void 0;                            // 18
	}));                                                                                                                  //
                                                                                                                       //
	dontNotifyDesktopUsers = _.compact(_.map(RocketChat.models.Subscriptions.findDontNotifyDesktopUsersByRoomId(room._id).fetch(), function (subscription) {
		var ref;                                                                                                             // 22
		return subscription != null ? (ref = subscription.u) != null ? ref._id : void 0 : void 0;                            // 23
	}));                                                                                                                  //
                                                                                                                       //
	alwaysNotifyMobileUsers = _.compact(_.map(RocketChat.models.Subscriptions.findAlwaysNotifyMobileUsersByRoomId(room._id).fetch(), function (subscription) {
		var ref;                                                                                                             // 27
		return subscription != null ? (ref = subscription.u) != null ? ref._id : void 0 : void 0;                            // 28
	}));                                                                                                                  //
                                                                                                                       //
	dontNotifyMobileUsers = _.compact(_.map(RocketChat.models.Subscriptions.findDontNotifyMobileUsersByRoomId(room._id).fetch(), function (subscription) {
		var ref;                                                                                                             // 32
		return subscription != null ? (ref = subscription.u) != null ? ref._id : void 0 : void 0;                            // 33
	}));                                                                                                                  //
                                                                                                                       //
	userIdsToNotify = [];                                                                                                 // 36
	userIdsToPushNotify = [];                                                                                             // 37
	if (room.t == null || room.t === 'd') {                                                                               // 38
		userOfMentionId = message.rid.replace(message.u._id, '');                                                            // 39
		userOfMention = RocketChat.models.Users.findOne({                                                                    // 40
			_id: userOfMentionId                                                                                                // 41
		}, {                                                                                                                 //
			fields: {                                                                                                           // 43
				username: 1,                                                                                                       // 44
				statusConnection: 1                                                                                                // 45
			}                                                                                                                   //
		});                                                                                                                  //
		if (userOfMention != null && (dontNotifyDesktopUsers.indexOf(userOfMentionId) === -1 || alwaysNotifyDesktopUsers.indexOf(userOfMentionId) !== -1)) {
			RocketChat.Notifications.notifyUser(userOfMention._id, 'notification', {                                            // 49
				title: "@" + user.username,                                                                                        // 50
				text: message.msg,                                                                                                 // 51
				payload: {                                                                                                         // 52
					rid: message.rid,                                                                                                 // 53
					sender: message.u,                                                                                                // 54
					type: room.t,                                                                                                     // 55
					name: room.name                                                                                                   // 56
				}                                                                                                                  //
			});                                                                                                                 //
		}                                                                                                                    //
		if (userOfMention != null && (dontNotifyMobileUsers.indexOf(userOfMentionId) === -1 || alwaysNotifyMobileUsers.indexOf(userOfMentionId) !== -1)) {
			if (Push.enabled === true && userOfMention.statusConnection !== 'online') {                                         // 61
				Push.send({                                                                                                        // 62
					from: 'push',                                                                                                     // 63
					title: "@" + user.username,                                                                                       // 64
					text: message.msg,                                                                                                // 65
					apn: {                                                                                                            // 66
						text: "@" + user.username + ":\n" + message.msg                                                                  // 67
					},                                                                                                                //
					badge: 1,                                                                                                         // 69
					sound: 'chime',                                                                                                   // 70
					payload: {                                                                                                        // 71
						host: Meteor.absoluteUrl(),                                                                                      // 72
						rid: message.rid,                                                                                                // 73
						sender: message.u,                                                                                               // 74
						type: room.t,                                                                                                    // 75
						name: room.name                                                                                                  // 76
					},                                                                                                                //
					query: {                                                                                                          // 78
						userId: userOfMention._id                                                                                        // 79
					}                                                                                                                 //
				});                                                                                                                //
				return message;                                                                                                    // 82
			}                                                                                                                   //
		}                                                                                                                    //
	} else {                                                                                                              //
		mentionIds = [];                                                                                                     // 86
		if ((ref = message.mentions) != null) {                                                                              // 87
			ref.forEach(function (mention) {                                                                                    // 88
				return mentionIds.push(mention._id);                                                                               // 89
			});                                                                                                                 //
		}                                                                                                                    //
		toAll = mentionIds.indexOf('all') > -1;                                                                              // 92
		if (mentionIds.length > 0 || alwaysNotifyDesktopUsers.length > 0) {                                                  // 93
			desktopMentionIds = _.union(mentionIds, alwaysNotifyDesktopUsers);                                                  // 94
			desktopMentionIds = _.difference(desktopMentionIds, dontNotifyDesktopUsers);                                        // 95
			usersOfDesktopMentions = RocketChat.models.Users.find({                                                             // 96
				_id: {                                                                                                             // 97
					$in: desktopMentionIds                                                                                            // 98
				}                                                                                                                  //
			}, {                                                                                                                //
				fields: {                                                                                                          // 101
					_id: 1,                                                                                                           // 102
					username: 1                                                                                                       // 103
				}                                                                                                                  //
			}).fetch();                                                                                                         //
			if (room.t === 'c' && !toAll) {                                                                                     // 106
				for (i = 0, len = usersOfDesktopMentions.length; i < len; i++) {                                                   // 107
					usersOfMentionItem = usersOfDesktopMentions[i];                                                                   // 108
					if (room.usernames.indexOf(usersOfMentionItem.username) === -1) {                                                 // 109
						Meteor.runAsUser(usersOfMentionItem._id, function () {                                                           // 110
							return Meteor.call('joinRoom', room._id);                                                                       // 111
						});                                                                                                              //
					}                                                                                                                 //
				}                                                                                                                  //
			}                                                                                                                   //
			userIdsToNotify = _.pluck(usersOfDesktopMentions, '_id');                                                           // 116
		}                                                                                                                    //
                                                                                                                       //
		if (mentionIds.length > 0 || alwaysNotifyMobileUsers.length > 0) {                                                   // 119
			mobileMentionIds = _.union(mentionIds, alwaysNotifyMobileUsers);                                                    // 120
			mobileMentionIds = _.difference(mobileMentionIds, dontNotifyMobileUsers);                                           // 121
			usersOfMobileMentions = RocketChat.models.Users.find({                                                              // 122
				_id: {                                                                                                             // 123
					$in: mobileMentionIds                                                                                             // 124
				}                                                                                                                  //
			}, {                                                                                                                //
				fields: {                                                                                                          // 127
					_id: 1,                                                                                                           // 128
					username: 1,                                                                                                      // 129
					statusConnection: 1                                                                                               // 130
				}                                                                                                                  //
			}).fetch();                                                                                                         //
			userIdsToPushNotify = _.pluck(_.filter(usersOfMobileMentions, function (user) {                                     // 133
				return user.statusConnection !== 'online';                                                                         // 134
			}), '_id');                                                                                                         //
		}                                                                                                                    //
                                                                                                                       //
		if (toAll && ((ref1 = room.usernames) != null ? ref1.length : void 0) > 0) {                                         // 138
			usersOfRoom = RocketChat.models.Users.find({                                                                        // 139
				username: {                                                                                                        // 140
					$in: room.usernames                                                                                               // 141
				},                                                                                                                 //
				_id: {                                                                                                             // 143
					$ne: user._id                                                                                                     // 144
				}                                                                                                                  //
			}, {                                                                                                                //
				fields: {                                                                                                          // 147
					_id: 1,                                                                                                           // 148
					username: 1,                                                                                                      // 149
					status: 1,                                                                                                        // 150
					statusConnection: 1                                                                                               // 151
				}                                                                                                                  //
			}).forEach(function (user) {                                                                                        //
				var ref2, ref3, ref4;                                                                                              // 154
				if (((ref2 = user.status) === 'online' || ref2 === 'away' || ref2 === 'busy') && (ref3 = user._id, indexOf.call(dontNotifyDesktopUsers, ref3) < 0)) {
					userIdsToNotify.push(user._id);                                                                                   // 156
				}                                                                                                                  //
				if (user.statusConnection !== 'online' && (ref4 = user._id, indexOf.call(dontNotifyMobileUsers, ref4) < 0)) {      // 158
					return userIdsToPushNotify.push(user._id);                                                                        // 159
				}                                                                                                                  //
			});                                                                                                                 //
			userIdsToNotify = _.unique(userIdsToNotify);                                                                        // 162
			userIdsToPushNotify = _.unique(userIdsToPushNotify);                                                                // 163
		}                                                                                                                    //
                                                                                                                       //
		if (userIdsToNotify.length > 0) {                                                                                    // 166
			for (j = 0, len1 = userIdsToNotify.length; j < len1; j++) {                                                         // 167
				usersOfMentionId = userIdsToNotify[j];                                                                             // 168
				RocketChat.Notifications.notifyUser(usersOfMentionId, 'notification', {                                            // 169
					title: "@" + user.username + " @ #" + room.name,                                                                  // 170
					text: message.msg,                                                                                                // 171
					payload: {                                                                                                        // 172
						rid: message.rid,                                                                                                // 173
						sender: message.u,                                                                                               // 174
						type: room.t,                                                                                                    // 175
						name: room.name                                                                                                  // 176
					}                                                                                                                 //
				});                                                                                                                //
			}                                                                                                                   //
		}                                                                                                                    //
                                                                                                                       //
		if (userIdsToPushNotify.length > 0) {                                                                                // 182
			if (Push.enabled === true) {                                                                                        // 183
				Push.send({                                                                                                        // 184
					from: 'push',                                                                                                     // 185
					title: "@" + user.username + " @ #" + room.name,                                                                  // 186
					text: message.msg,                                                                                                // 187
					apn: {                                                                                                            // 188
						text: "@" + user.username + " @ #" + room.name + ":\n" + message.msg                                             // 189
					},                                                                                                                //
					badge: 1,                                                                                                         // 191
					sound: 'chime',                                                                                                   // 192
					payload: {                                                                                                        // 193
						host: Meteor.absoluteUrl(),                                                                                      // 194
						rid: message.rid,                                                                                                // 195
						sender: message.u,                                                                                               // 196
						type: room.t,                                                                                                    // 197
						name: room.name                                                                                                  // 198
					},                                                                                                                //
					query: {                                                                                                          // 200
						userId: {                                                                                                        // 201
							$in: userIdsToPushNotify                                                                                        // 202
						}                                                                                                                //
					}                                                                                                                 //
				});                                                                                                                //
			}                                                                                                                   //
		}                                                                                                                    //
                                                                                                                       //
		if (mentionIds > 0) {                                                                                                // 209
			/*                                                                                                                  //
   Update all other subscriptions of mentioned users to alert their owners and incrementing                            //
   the unread counter for mentions and direct messages                                                                 //
    */                                                                                                                 //
			if (toAll) {                                                                                                        // 214
				RocketChat.models.Subscriptions.incUnreadForRoomIdExcludingUserId(message.rid, user._id, 1);                       // 215
			} else {                                                                                                            //
				RocketChat.models.Subscriptions.incUnreadForRoomIdAndUserIds(message.rid, mentionIds, 1);                          // 217
			}                                                                                                                   //
		}                                                                                                                    //
	}                                                                                                                     //
                                                                                                                       //
	return message;                                                                                                       // 222
}, RocketChat.callbacks.priority.LOW);                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/lib/notifyUsersOnMessage.js                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
RocketChat.callbacks.add('afterSaveMessage', function (message, room) {                                                // 1
	// skips this callback if the message was edited                                                                      //
	if (message.editedAt) {                                                                                               // 3
		return message;                                                                                                      // 4
	}                                                                                                                     //
	if (room.t != null && room.t === 'd') {                                                                               // 6
		// Update the other subscriptions                                                                                    //
		RocketChat.models.Subscriptions.incUnreadOfDirectForRoomIdExcludingUserId(message.rid, message.u._id, 1);            // 8
	} else {                                                                                                              //
		var mentionIds = [];                                                                                                 // 10
		var toAll = false;                                                                                                   // 11
		if (message.mentions != null) {                                                                                      // 12
			message.mentions.forEach(function (mention) {                                                                       // 13
				if (!toAll && mention._id === 'all') {                                                                             // 14
					toAll = true;                                                                                                     // 15
				}                                                                                                                  //
				mentionIds.push(mention._id);                                                                                      // 17
			});                                                                                                                 //
		}                                                                                                                    //
                                                                                                                       //
		if (toAll) {                                                                                                         // 21
			RocketChat.models.Subscriptions.incUnreadForRoomIdExcludingUserId(room._id, message.u._id);                         // 22
		} else if (mentionIds.length > 0) {                                                                                  //
			RocketChat.models.Subscriptions.incUnreadForRoomIdAndUserIds(room._id, mentionIds);                                 // 24
		}                                                                                                                    //
	}                                                                                                                     //
                                                                                                                       //
	// Update all the room activity tracker fields                                                                        //
	RocketChat.models.Rooms.incMsgCountAndSetLastMessageTimestampById(message.rid, 1, message.ts);                        // 29
                                                                                                                       //
	// Update all other subscriptions to alert their owners but witout incrementing                                       //
	// the unread counter, as it is only for mentions and direct messages                                                 //
	RocketChat.models.Subscriptions.setAlertForRoomIdExcludingUserId(message.rid, message.u._id, true);                   // 33
                                                                                                                       //
	return message;                                                                                                       // 35
}, RocketChat.callbacks.priority.LOW);                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/lib/sendEmailOnMessage.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
RocketChat.callbacks.add('afterSaveMessage', function (message, room) {                                                // 1
	// skips this callback if the message was edited                                                                      //
	if (message.editedAt) {                                                                                               // 3
		return message;                                                                                                      // 4
	}                                                                                                                     //
                                                                                                                       //
	var emailSubject,                                                                                                     // 7
	    mentionIds = [];                                                                                                  //
                                                                                                                       //
	if (room.t === 'd') {                                                                                                 // 9
		mentionIds.push(message.rid.replace(message.u._id, ''));                                                             // 10
                                                                                                                       //
		emailSubject = TAPi18n.__("Offline_DM_Email", {                                                                      // 12
			site: RocketChat.settings.get('Site_Name'),                                                                         // 13
			user: message.u.username                                                                                            // 14
		});                                                                                                                  //
	} else {                                                                                                              //
		if (message.mentions) {                                                                                              // 18
			message.mentions.forEach(function (mention) {                                                                       // 19
				return mentionIds.push(mention._id);                                                                               // 20
			});                                                                                                                 //
		}                                                                                                                    //
                                                                                                                       //
		emailSubject = TAPi18n.__("Offline_Mention_Email", {                                                                 // 24
			site: RocketChat.settings.get('Site_Name'),                                                                         // 25
			user: message.u.username,                                                                                           // 26
			room: room.name                                                                                                     // 27
		});                                                                                                                  //
	}                                                                                                                     //
                                                                                                                       //
	// code duplicate of packages/rocketchat-ui-message/message/message.coffee                                            //
	message.html = s.escapeHTML(message.msg);                                                                             // 32
	message = RocketChat.callbacks.run('renderMessage', message);                                                         // 33
	if (message.tokens && message.tokens.length > 0) {                                                                    // 34
		message.tokens.forEach(function (token) {                                                                            // 35
			token.text = token.text.replace(/([^\$])(\$[^\$])/gm, '$1$$$2');                                                    // 36
			message.html = message.html.replace(token.token, token.text);                                                       // 37
		});                                                                                                                  //
	}                                                                                                                     //
	message.html = message.html.replace(/\n/gm, '<br/>');                                                                 // 40
                                                                                                                       //
	if (mentionIds.length > 0) {                                                                                          // 42
		var usersOfMention = RocketChat.models.Users.getUsersToSendOfflineEmail(mentionIds).fetch();                         // 43
                                                                                                                       //
		if (usersOfMention && usersOfMention.length > 0) {                                                                   // 45
			usersOfMention.forEach(function (user) {                                                                            // 46
				user.emails.some(function (email) {                                                                                // 47
					if (email.verified) {                                                                                             // 48
						var email = {                                                                                                    // 49
							to: email.address,                                                                                              // 50
							from: RocketChat.settings.get('From_Email'),                                                                    // 51
							subject: emailSubject,                                                                                          // 52
							html: "&gt; " + message.html                                                                                    // 53
						};                                                                                                               //
                                                                                                                       //
						Email.send(email);                                                                                               // 56
                                                                                                                       //
						return true;                                                                                                     // 58
					}                                                                                                                 //
				});                                                                                                                //
			});                                                                                                                 //
		}                                                                                                                    //
	}                                                                                                                     //
                                                                                                                       //
	return message;                                                                                                       // 65
}, RocketChat.callbacks.priority.LOW);                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/models/_Base.coffee.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.models._Base = (function() {                                                                                // 1
  function _Class() {}                                                                                                 //
                                                                                                                       //
  _Class.prototype._baseName = function() {                                                                            // 2
    return 'rocketchat_';                                                                                              // 3
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype._initModel = function(name) {                                                                       // 2
    check(name, String);                                                                                               // 6
    return this.model = new Mongo.Collection(this._baseName() + name);                                                 //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.find = function() {                                                                                 // 2
    return this.model.find.apply(this.model, arguments);                                                               // 11
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOne = function() {                                                                              // 2
    return this.model.findOne.apply(this.model, arguments);                                                            // 14
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.insert = function() {                                                                               // 2
    return this.model.insert.apply(this.model, arguments);                                                             // 17
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.update = function() {                                                                               // 2
    return this.model.update.apply(this.model, arguments);                                                             // 20
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.upsert = function() {                                                                               // 2
    return this.model.upsert.apply(this.model, arguments);                                                             // 23
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.remove = function() {                                                                               // 2
    return this.model.remove.apply(this.model, arguments);                                                             // 26
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.allow = function() {                                                                                // 2
    return this.model.allow.apply(this.model, arguments);                                                              // 29
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.deny = function() {                                                                                 // 2
    return this.model.deny.apply(this.model, arguments);                                                               // 32
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.ensureIndex = function() {                                                                          // 2
    return this.model._ensureIndex.apply(this.model, arguments);                                                       // 35
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.dropIndex = function() {                                                                            // 2
    return this.model._dropIndex.apply(this.model, arguments);                                                         // 38
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.tryEnsureIndex = function() {                                                                       // 2
    var e;                                                                                                             // 41
    try {                                                                                                              // 41
      return this.ensureIndex.apply(this, arguments);                                                                  // 42
    } catch (_error) {                                                                                                 //
      e = _error;                                                                                                      // 44
      return console.log(e);                                                                                           //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.tryDropIndex = function() {                                                                         // 2
    var e;                                                                                                             // 47
    try {                                                                                                              // 47
      return this.dropIndex.apply(this, arguments);                                                                    // 48
    } catch (_error) {                                                                                                 //
      e = _error;                                                                                                      // 50
      return console.log(e);                                                                                           //
    }                                                                                                                  //
  };                                                                                                                   //
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})();                                                                                                                  //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/models/Messages.coffee.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                         //
                                                                                                                       //
RocketChat.models.Messages = new ((function(superClass) {                                                              // 1
  extend(_Class, superClass);                                                                                          // 2
                                                                                                                       //
  function _Class() {                                                                                                  // 2
    this._initModel('message');                                                                                        // 3
    this.tryEnsureIndex({                                                                                              // 3
      'rid': 1,                                                                                                        // 5
      'ts': 1                                                                                                          // 5
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'editedAt': 1                                                                                                    // 6
    }, {                                                                                                               //
      sparse: 1                                                                                                        // 6
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'editedBy._id': 1                                                                                                // 7
    }, {                                                                                                               //
      sparse: 1                                                                                                        // 7
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'rid': 1,                                                                                                        // 8
      't': 1,                                                                                                          // 8
      'u._id': 1                                                                                                       // 8
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'expireAt': 1                                                                                                    // 9
    }, {                                                                                                               //
      expireAfterSeconds: 0                                                                                            // 9
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'msg': 'text'                                                                                                    // 10
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'file._id': 1                                                                                                    // 11
    }, {                                                                                                               //
      sparse: 1                                                                                                        // 11
    });                                                                                                                //
  }                                                                                                                    //
                                                                                                                       //
  _Class.prototype.findOneById = function(_id, options) {                                                              // 2
    var query;                                                                                                         // 16
    query = {                                                                                                          // 16
      _id: _id                                                                                                         // 17
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 19
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByMention = function(username, options) {                                                       // 2
    var query;                                                                                                         // 23
    query = {                                                                                                          // 23
      "mentions.username": username                                                                                    // 24
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 26
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findVisibleByMentionAndRoomId = function(username, rid, options) {                                  // 2
    var query;                                                                                                         // 29
    query = {                                                                                                          // 29
      _hidden: {                                                                                                       // 30
        $ne: true                                                                                                      // 30
      },                                                                                                               //
      "mentions.username": username,                                                                                   // 30
      "rid": rid                                                                                                       // 30
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 34
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findVisibleByRoomId = function(roomId, options) {                                                   // 2
    var query;                                                                                                         // 37
    query = {                                                                                                          // 37
      _hidden: {                                                                                                       // 38
        $ne: true                                                                                                      // 39
      },                                                                                                               //
      rid: roomId                                                                                                      // 38
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 42
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findInvisibleByRoomId = function(roomId, options) {                                                 // 2
    var query;                                                                                                         // 45
    query = {                                                                                                          // 45
      _hidden: true,                                                                                                   // 46
      rid: roomId                                                                                                      // 46
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 49
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findVisibleByRoomIdAfterTimestamp = function(roomId, timestamp, options) {                          // 2
    var query;                                                                                                         // 52
    query = {                                                                                                          // 52
      _hidden: {                                                                                                       // 53
        $ne: true                                                                                                      // 54
      },                                                                                                               //
      rid: roomId,                                                                                                     // 53
      ts: {                                                                                                            // 53
        $gt: timestamp                                                                                                 // 57
      }                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 59
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findVisibleByRoomIdBeforeTimestamp = function(roomId, timestamp, options) {                         // 2
    var query;                                                                                                         // 62
    query = {                                                                                                          // 62
      _hidden: {                                                                                                       // 63
        $ne: true                                                                                                      // 64
      },                                                                                                               //
      rid: roomId,                                                                                                     // 63
      ts: {                                                                                                            // 63
        $lt: timestamp                                                                                                 // 67
      }                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 69
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findVisibleByRoomIdBetweenTimestamps = function(roomId, afterTimestamp, beforeTimestamp, options) {
    var query;                                                                                                         // 72
    query = {                                                                                                          // 72
      _hidden: {                                                                                                       // 73
        $ne: true                                                                                                      // 74
      },                                                                                                               //
      rid: roomId,                                                                                                     // 73
      ts: {                                                                                                            // 73
        $gt: afterTimestamp,                                                                                           // 77
        $lt: beforeTimestamp                                                                                           // 77
      }                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 80
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findVisibleCreatedOrEditedAfterTimestamp = function(timestamp, options) {                           // 2
    var query;                                                                                                         // 83
    query = {                                                                                                          // 83
      _hidden: {                                                                                                       // 84
        $ne: true                                                                                                      // 84
      },                                                                                                               //
      $or: [                                                                                                           // 84
        {                                                                                                              //
          ts: {                                                                                                        // 86
            $gt: timestamp                                                                                             // 87
          }                                                                                                            //
        }, {                                                                                                           //
          'editedAt': {                                                                                                // 89
            $gt: timestamp                                                                                             // 90
          }                                                                                                            //
        }                                                                                                              //
      ]                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 93
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findStarredByUserAtRoom = function(userId, roomId, options) {                                       // 2
    var query;                                                                                                         // 96
    query = {                                                                                                          // 96
      _hidden: {                                                                                                       // 97
        $ne: true                                                                                                      // 97
      },                                                                                                               //
      'starred._id': userId,                                                                                           // 97
      rid: roomId                                                                                                      // 97
    };                                                                                                                 //
    console.log('findStarredByUserAtRoom', arguments);                                                                 // 96
    return this.find(query, options);                                                                                  // 103
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findPinnedByRoom = function(roomId, options) {                                                      // 2
    var query;                                                                                                         // 106
    query = {                                                                                                          // 106
      _hidden: {                                                                                                       // 107
        $ne: true                                                                                                      // 107
      },                                                                                                               //
      pinned: true,                                                                                                    // 107
      rid: roomId                                                                                                      // 107
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 111
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.getLastTimestamp = function(options) {                                                              // 2
    var query, ref, ref1, ref2;                                                                                        // 114
    if (options == null) {                                                                                             //
      options = {};                                                                                                    //
    }                                                                                                                  //
    query = {                                                                                                          // 114
      ts: {                                                                                                            // 114
        $exists: 1                                                                                                     // 114
      }                                                                                                                //
    };                                                                                                                 //
    options.sort = {                                                                                                   // 114
      ts: -1                                                                                                           // 115
    };                                                                                                                 //
    options.limit = 1;                                                                                                 // 114
    return (ref = this.find(query, options)) != null ? typeof ref.fetch === "function" ? (ref1 = ref.fetch()) != null ? (ref2 = ref1[0]) != null ? ref2.ts : void 0 : void 0 : void 0 : void 0;
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByRoomIdAndMessageIds = function(rid, messageIds, options) {                                    // 2
    var query;                                                                                                         // 121
    query = {                                                                                                          // 121
      rid: rid,                                                                                                        // 122
      _id: {                                                                                                           // 122
        $in: messageIds                                                                                                // 124
      }                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 126
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.cloneAndSaveAsHistoryById = function(_id) {                                                         // 2
    var me, record, ref, ref1;                                                                                         // 129
    me = RocketChat.models.Users.findOneById(Meteor.userId());                                                         // 129
    record = this.findOneById(_id);                                                                                    // 129
    record._hidden = true;                                                                                             // 129
    record.parent = record._id;                                                                                        // 129
    record.editedAt = new Date;                                                                                        // 129
    record.editedBy = {                                                                                                // 129
      _id: Meteor.userId(),                                                                                            // 135
      username: me.username                                                                                            // 135
    };                                                                                                                 //
    record.pinned = record.pinned;                                                                                     // 129
    record.pinnedAt = record.pinnedAt;                                                                                 // 129
    record.pinnedBy = {                                                                                                // 129
      _id: (ref = record.pinnedBy) != null ? ref._id : void 0,                                                         // 140
      username: (ref1 = record.pinnedBy) != null ? ref1.username : void 0                                              // 140
    };                                                                                                                 //
    delete record._id;                                                                                                 // 129
    return this.insert(record);                                                                                        // 144
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setHiddenById = function(_id, hidden) {                                                             // 2
    var query, update;                                                                                                 // 148
    if (hidden == null) {                                                                                              //
      hidden = true;                                                                                                   //
    }                                                                                                                  //
    query = {                                                                                                          // 148
      _id: _id                                                                                                         // 149
    };                                                                                                                 //
    update = {                                                                                                         // 148
      $set: {                                                                                                          // 152
        _hidden: hidden                                                                                                // 153
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 155
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setAsDeletedById = function(_id) {                                                                  // 2
    var me, query, update;                                                                                             // 158
    me = RocketChat.models.Users.findOneById(Meteor.userId());                                                         // 158
    query = {                                                                                                          // 158
      _id: _id                                                                                                         // 160
    };                                                                                                                 //
    update = {                                                                                                         // 158
      $set: {                                                                                                          // 163
        msg: '',                                                                                                       // 164
        t: 'rm',                                                                                                       // 164
        urls: [],                                                                                                      // 164
        mentions: [],                                                                                                  // 164
        attachments: [],                                                                                               // 164
        editedAt: new Date(),                                                                                          // 164
        editedBy: {                                                                                                    // 164
          _id: Meteor.userId(),                                                                                        // 171
          username: me.username                                                                                        // 171
        }                                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 174
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setPinnedByIdAndUserId = function(_id, pinnedBy, pinned) {                                          // 2
    var query, update;                                                                                                 // 177
    if (pinned == null) {                                                                                              //
      pinned = true;                                                                                                   //
    }                                                                                                                  //
    query = {                                                                                                          // 177
      _id: _id                                                                                                         // 178
    };                                                                                                                 //
    update = {                                                                                                         // 177
      $set: {                                                                                                          // 181
        pinned: pinned,                                                                                                // 182
        pinnedAt: new Date,                                                                                            // 182
        pinnedBy: pinnedBy                                                                                             // 182
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 186
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setUrlsById = function(_id, urls) {                                                                 // 2
    var query, update;                                                                                                 // 189
    query = {                                                                                                          // 189
      _id: _id                                                                                                         // 190
    };                                                                                                                 //
    update = {                                                                                                         // 189
      $set: {                                                                                                          // 193
        urls: urls                                                                                                     // 194
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 196
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.updateAllUsernamesByUserId = function(userId, username) {                                           // 2
    var query, update;                                                                                                 // 199
    query = {                                                                                                          // 199
      'u._id': userId                                                                                                  // 200
    };                                                                                                                 //
    update = {                                                                                                         // 199
      $set: {                                                                                                          // 203
        "u.username": username                                                                                         // 204
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 206
      multi: true                                                                                                      // 206
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.updateUsernameOfEditByUserId = function(userId, username) {                                         // 2
    var query, update;                                                                                                 // 209
    query = {                                                                                                          // 209
      'editedBy._id': userId                                                                                           // 210
    };                                                                                                                 //
    update = {                                                                                                         // 209
      $set: {                                                                                                          // 213
        "editedBy.username": username                                                                                  // 214
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 216
      multi: true                                                                                                      // 216
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.updateUsernameAndMessageOfMentionByIdAndOldUsername = function(_id, oldUsername, newUsername, newMessage) {
    var query, update;                                                                                                 // 219
    query = {                                                                                                          // 219
      _id: _id,                                                                                                        // 220
      "mentions.username": oldUsername                                                                                 // 220
    };                                                                                                                 //
    update = {                                                                                                         // 219
      $set: {                                                                                                          // 224
        "mentions.$.username": newUsername,                                                                            // 225
        "msg": newMessage                                                                                              // 225
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 228
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.updateUserStarById = function(_id, userId, starred) {                                               // 2
    var query, update;                                                                                                 // 231
    query = {                                                                                                          // 231
      _id: _id                                                                                                         // 232
    };                                                                                                                 //
    if (starred) {                                                                                                     // 234
      update = {                                                                                                       // 235
        $addToSet: {                                                                                                   // 236
          starred: {                                                                                                   // 237
            _id: userId                                                                                                // 237
          }                                                                                                            //
        }                                                                                                              //
      };                                                                                                               //
    } else {                                                                                                           //
      update = {                                                                                                       // 239
        $pull: {                                                                                                       // 240
          starred: {                                                                                                   // 241
            _id: Meteor.userId()                                                                                       // 241
          }                                                                                                            //
        }                                                                                                              //
      };                                                                                                               //
    }                                                                                                                  //
    return this.update(query, update);                                                                                 // 243
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.upgradeEtsToEditAt = function() {                                                                   // 2
    var query, update;                                                                                                 // 246
    query = {                                                                                                          // 246
      ets: {                                                                                                           // 247
        $exists: 1                                                                                                     // 247
      }                                                                                                                //
    };                                                                                                                 //
    update = {                                                                                                         // 246
      $rename: {                                                                                                       // 250
        "ets": "editedAt"                                                                                              // 251
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 253
      multi: true                                                                                                      // 253
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createWithTypeRoomIdMessageAndUser = function(type, roomId, message, user, extraData) {             // 2
    var record;                                                                                                        // 257
    record = {                                                                                                         // 257
      t: type,                                                                                                         // 258
      rid: roomId,                                                                                                     // 258
      ts: new Date,                                                                                                    // 258
      msg: message,                                                                                                    // 258
      u: {                                                                                                             // 258
        _id: user._id,                                                                                                 // 263
        username: user.username                                                                                        // 263
      }                                                                                                                //
    };                                                                                                                 //
    _.extend(record, extraData);                                                                                       // 257
    record._id = this.insert(record);                                                                                  // 257
    return record;                                                                                                     // 269
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createUserJoinWithRoomIdAndUser = function(roomId, user, extraData) {                               // 2
    var message;                                                                                                       // 272
    message = user.username;                                                                                           // 272
    return this.createWithTypeRoomIdMessageAndUser('uj', roomId, message, user, extraData);                            // 273
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createUserLeaveWithRoomIdAndUser = function(roomId, user, extraData) {                              // 2
    var message;                                                                                                       // 276
    message = user.username;                                                                                           // 276
    return this.createWithTypeRoomIdMessageAndUser('ul', roomId, message, user, extraData);                            // 277
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createUserRemovedWithRoomIdAndUser = function(roomId, user, extraData) {                            // 2
    var message;                                                                                                       // 280
    message = user.username;                                                                                           // 280
    return this.createWithTypeRoomIdMessageAndUser('ru', roomId, message, user, extraData);                            // 281
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createUserAddedWithRoomIdAndUser = function(roomId, user, extraData) {                              // 2
    var message;                                                                                                       // 284
    message = user.username;                                                                                           // 284
    return this.createWithTypeRoomIdMessageAndUser('au', roomId, message, user, extraData);                            // 285
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createCommandWithRoomIdAndUser = function(command, roomId, user, extraData) {                       // 2
    return this.createWithTypeRoomIdMessageAndUser('command', roomId, command, user, extraData);                       // 288
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createUserMutedWithRoomIdAndUser = function(roomId, user, extraData) {                              // 2
    var message;                                                                                                       // 291
    message = user.username;                                                                                           // 291
    return this.createWithTypeRoomIdMessageAndUser('user-muted', roomId, message, user, extraData);                    // 292
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createUserUnmutedWithRoomIdAndUser = function(roomId, user, extraData) {                            // 2
    var message;                                                                                                       // 295
    message = user.username;                                                                                           // 295
    return this.createWithTypeRoomIdMessageAndUser('user-unmuted', roomId, message, user, extraData);                  // 296
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createNewModeratorWithRoomIdAndUser = function(roomId, user, extraData) {                           // 2
    var message;                                                                                                       // 299
    message = user.username;                                                                                           // 299
    return this.createWithTypeRoomIdMessageAndUser('new-moderator', roomId, message, user, extraData);                 // 300
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createModeratorRemovedWithRoomIdAndUser = function(roomId, user, extraData) {                       // 2
    var message;                                                                                                       // 303
    message = user.username;                                                                                           // 303
    return this.createWithTypeRoomIdMessageAndUser('moderator-removed', roomId, message, user, extraData);             // 304
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createNewOwnerWithRoomIdAndUser = function(roomId, user, extraData) {                               // 2
    var message;                                                                                                       // 307
    message = user.username;                                                                                           // 307
    return this.createWithTypeRoomIdMessageAndUser('new-owner', roomId, message, user, extraData);                     // 308
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createOwnerRemovedWithRoomIdAndUser = function(roomId, user, extraData) {                           // 2
    var message;                                                                                                       // 311
    message = user.username;                                                                                           // 311
    return this.createWithTypeRoomIdMessageAndUser('owner-removed', roomId, message, user, extraData);                 // 312
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeById = function(_id) {                                                                        // 2
    var query;                                                                                                         // 316
    query = {                                                                                                          // 316
      _id: _id                                                                                                         // 317
    };                                                                                                                 //
    return this.remove(query);                                                                                         // 319
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeByRoomId = function(roomId) {                                                                 // 2
    var query;                                                                                                         // 322
    query = {                                                                                                          // 322
      rid: roomId                                                                                                      // 323
    };                                                                                                                 //
    return this.remove(query);                                                                                         // 325
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeByUserId = function(userId) {                                                                 // 2
    var query;                                                                                                         // 328
    query = {                                                                                                          // 328
      "u._id": userId                                                                                                  // 329
    };                                                                                                                 //
    return this.remove(query);                                                                                         // 331
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.getMessageByFileId = function(fileID) {                                                             // 2
    return this.findOne({                                                                                              // 334
      'file._id': fileID                                                                                               // 334
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})(RocketChat.models._Base));                                                                                          //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/models/Reports.coffee.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                         //
                                                                                                                       //
RocketChat.models.Reports = new ((function(superClass) {                                                               // 1
  extend(_Class, superClass);                                                                                          // 2
                                                                                                                       //
  function _Class() {                                                                                                  // 2
    this._initModel('reports');                                                                                        // 3
  }                                                                                                                    //
                                                                                                                       //
  _Class.prototype.createWithMessageDescriptionAndUserId = function(message, description, userId, extraData) {         // 2
    var record;                                                                                                        // 8
    record = {                                                                                                         // 8
      message: message,                                                                                                // 9
      description: description,                                                                                        // 9
      ts: new Date(),                                                                                                  // 9
      userId: userId                                                                                                   // 9
    };                                                                                                                 //
    _.extend(record, extraData);                                                                                       // 8
    record._id = this.insert(record);                                                                                  // 8
    return record;                                                                                                     // 17
  };                                                                                                                   //
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})(RocketChat.models._Base));                                                                                          //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/models/Rooms.coffee.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                         //
                                                                                                                       //
RocketChat.models.Rooms = new ((function(superClass) {                                                                 // 1
  extend(_Class, superClass);                                                                                          // 2
                                                                                                                       //
  function _Class() {                                                                                                  // 2
    this._initModel('room');                                                                                           // 3
    this.tryEnsureIndex({                                                                                              // 3
      'name': 1                                                                                                        // 5
    }, {                                                                                                               //
      unique: 1,                                                                                                       // 5
      sparse: 1                                                                                                        // 5
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'default': 1                                                                                                     // 6
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'usernames': 1                                                                                                   // 7
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      't': 1                                                                                                           // 8
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'u._id': 1                                                                                                       // 9
    });                                                                                                                //
  }                                                                                                                    //
                                                                                                                       //
  _Class.prototype.findOneById = function(_id, options) {                                                              // 2
    var query;                                                                                                         // 14
    query = {                                                                                                          // 14
      _id: _id                                                                                                         // 15
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 17
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOneByName = function(name, options) {                                                           // 2
    var query;                                                                                                         // 20
    query = {                                                                                                          // 20
      name: name                                                                                                       // 21
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 23
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOneByNameAndType = function(name, type, options) {                                              // 2
    var query;                                                                                                         // 26
    query = {                                                                                                          // 26
      name: name,                                                                                                      // 27
      t: type                                                                                                          // 27
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 30
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOneByIdContainigUsername = function(_id, username, options) {                                   // 2
    var query;                                                                                                         // 33
    query = {                                                                                                          // 33
      _id: _id,                                                                                                        // 34
      usernames: username                                                                                              // 34
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 37
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOneByNameAndTypeNotContainigUsername = function(name, type, username, options) {                // 2
    var query;                                                                                                         // 40
    query = {                                                                                                          // 40
      name: name,                                                                                                      // 41
      t: type,                                                                                                         // 41
      usernames: {                                                                                                     // 41
        $ne: username                                                                                                  // 44
      }                                                                                                                //
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 46
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByType = function(type, options) {                                                              // 2
    var query;                                                                                                         // 51
    query = {                                                                                                          // 51
      t: type                                                                                                          // 52
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 54
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByTypes = function(types, options) {                                                            // 2
    var query;                                                                                                         // 57
    query = {                                                                                                          // 57
      t: {                                                                                                             // 58
        $in: types                                                                                                     // 59
      }                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 61
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByUserId = function(userId, options) {                                                          // 2
    var query;                                                                                                         // 64
    query = {                                                                                                          // 64
      "u._id": userId                                                                                                  // 65
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 67
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByNameContaining = function(name, options) {                                                    // 2
    var nameRegex, query;                                                                                              // 70
    nameRegex = new RegExp(name, "i");                                                                                 // 70
    query = {                                                                                                          // 70
      $or: [                                                                                                           // 73
        {                                                                                                              //
          name: nameRegex                                                                                              // 74
        }, {                                                                                                           //
          t: 'd',                                                                                                      // 76
          usernames: nameRegex                                                                                         // 76
        }                                                                                                              //
      ]                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 80
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByNameContainingAndTypes = function(name, types, options) {                                     // 2
    var nameRegex, query;                                                                                              // 83
    nameRegex = new RegExp(name, "i");                                                                                 // 83
    query = {                                                                                                          // 83
      t: {                                                                                                             // 86
        $in: types                                                                                                     // 87
      },                                                                                                               //
      $or: [                                                                                                           // 86
        {                                                                                                              //
          name: nameRegex                                                                                              // 89
        }, {                                                                                                           //
          t: 'd',                                                                                                      // 91
          usernames: nameRegex                                                                                         // 91
        }                                                                                                              //
      ]                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 95
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByDefaultAndTypes = function(defaultValue, types, options) {                                    // 2
    var query;                                                                                                         // 98
    query = {                                                                                                          // 98
      "default": defaultValue,                                                                                         // 99
      t: {                                                                                                             // 99
        $in: types                                                                                                     // 101
      }                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 103
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByTypeContainigUsername = function(type, username, options) {                                   // 2
    var query;                                                                                                         // 106
    query = {                                                                                                          // 106
      t: type,                                                                                                         // 107
      usernames: username                                                                                              // 107
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 110
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByTypeContainigUsernames = function(type, username, options) {                                  // 2
    var query;                                                                                                         // 113
    query = {                                                                                                          // 113
      t: type,                                                                                                         // 114
      usernames: {                                                                                                     // 114
        $all: [].concat(username)                                                                                      // 115
      }                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 117
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByTypesAndNotUserIdContainingUsername = function(types, userId, username, options) {            // 2
    var query;                                                                                                         // 120
    query = {                                                                                                          // 120
      t: {                                                                                                             // 121
        $in: types                                                                                                     // 122
      },                                                                                                               //
      uid: {                                                                                                           // 121
        $ne: userId                                                                                                    // 124
      },                                                                                                               //
      usernames: username                                                                                              // 121
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 127
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByContainigUsername = function(username, options) {                                             // 2
    var query;                                                                                                         // 130
    query = {                                                                                                          // 130
      usernames: username                                                                                              // 131
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 133
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByTypeAndName = function(type, name, options) {                                                 // 2
    var query;                                                                                                         // 136
    query = {                                                                                                          // 136
      name: name,                                                                                                      // 137
      t: type                                                                                                          // 137
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 140
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByTypeAndNameContainigUsername = function(type, name, username, options) {                      // 2
    var query;                                                                                                         // 143
    query = {                                                                                                          // 143
      name: name,                                                                                                      // 144
      t: type,                                                                                                         // 144
      usernames: username                                                                                              // 144
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 148
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByTypeAndArchivationState = function(type, archivationstate, options) {                         // 2
    var query;                                                                                                         // 151
    query = {                                                                                                          // 151
      t: type                                                                                                          // 152
    };                                                                                                                 //
    if (archivationstate) {                                                                                            // 154
      query.archived = true;                                                                                           // 155
    } else {                                                                                                           //
      query.archived = {                                                                                               // 157
        $ne: true                                                                                                      // 157
      };                                                                                                               //
    }                                                                                                                  //
    return this.find(query, options);                                                                                  // 159
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByVisitorToken = function(visitorToken, options) {                                              // 2
    var query;                                                                                                         // 162
    query = {                                                                                                          // 162
      "v.token": visitorToken                                                                                          // 163
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 165
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.archiveById = function(_id) {                                                                       // 2
    var query, update;                                                                                                 // 170
    query = {                                                                                                          // 170
      _id: _id                                                                                                         // 171
    };                                                                                                                 //
    update = {                                                                                                         // 170
      $set: {                                                                                                          // 174
        archived: true                                                                                                 // 175
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 177
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.unarchiveById = function(_id) {                                                                     // 2
    var query, update;                                                                                                 // 180
    query = {                                                                                                          // 180
      _id: _id                                                                                                         // 181
    };                                                                                                                 //
    update = {                                                                                                         // 180
      $set: {                                                                                                          // 184
        archived: false                                                                                                // 185
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 187
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.addUsernameById = function(_id, username) {                                                         // 2
    var query, update;                                                                                                 // 190
    query = {                                                                                                          // 190
      _id: _id                                                                                                         // 191
    };                                                                                                                 //
    update = {                                                                                                         // 190
      $addToSet: {                                                                                                     // 194
        usernames: username                                                                                            // 195
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 197
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.addUsernamesById = function(_id, usernames) {                                                       // 2
    var query, update;                                                                                                 // 200
    query = {                                                                                                          // 200
      _id: _id                                                                                                         // 201
    };                                                                                                                 //
    update = {                                                                                                         // 200
      $addToSet: {                                                                                                     // 204
        usernames: {                                                                                                   // 205
          $each: usernames                                                                                             // 206
        }                                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 208
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.addUsernameByName = function(name, username) {                                                      // 2
    var query, update;                                                                                                 // 211
    query = {                                                                                                          // 211
      name: name                                                                                                       // 212
    };                                                                                                                 //
    update = {                                                                                                         // 211
      $addToSet: {                                                                                                     // 215
        usernames: username                                                                                            // 216
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 218
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeUsernameById = function(_id, username) {                                                      // 2
    var query, update;                                                                                                 // 221
    query = {                                                                                                          // 221
      _id: _id                                                                                                         // 222
    };                                                                                                                 //
    update = {                                                                                                         // 221
      $pull: {                                                                                                         // 225
        usernames: username                                                                                            // 226
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 228
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeUsernamesById = function(_id, usernames) {                                                    // 2
    var query, update;                                                                                                 // 231
    query = {                                                                                                          // 231
      _id: _id                                                                                                         // 232
    };                                                                                                                 //
    update = {                                                                                                         // 231
      $pull: {                                                                                                         // 235
        usernames: {                                                                                                   // 236
          $in: usernames                                                                                               // 237
        }                                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 239
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeUsernameFromAll = function(username) {                                                        // 2
    var query, update;                                                                                                 // 242
    query = {};                                                                                                        // 242
    update = {                                                                                                         // 242
      $pull: {                                                                                                         // 245
        usernames: username                                                                                            // 246
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 248
      multi: true                                                                                                      // 248
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeUsernameByName = function(name, username) {                                                   // 2
    var query, update;                                                                                                 // 251
    query = {                                                                                                          // 251
      name: name                                                                                                       // 252
    };                                                                                                                 //
    update = {                                                                                                         // 251
      $pull: {                                                                                                         // 255
        usernames: username                                                                                            // 256
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 258
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setNameById = function(_id, name) {                                                                 // 2
    var query, update;                                                                                                 // 261
    query = {                                                                                                          // 261
      _id: _id                                                                                                         // 262
    };                                                                                                                 //
    update = {                                                                                                         // 261
      $set: {                                                                                                          // 265
        name: name                                                                                                     // 266
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 268
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.incMsgCountAndSetLastMessageTimestampById = function(_id, inc, lastMessageTimestamp) {              // 2
    var query, update;                                                                                                 // 271
    if (inc == null) {                                                                                                 //
      inc = 1;                                                                                                         //
    }                                                                                                                  //
    query = {                                                                                                          // 271
      _id: _id                                                                                                         // 272
    };                                                                                                                 //
    update = {                                                                                                         // 271
      $set: {                                                                                                          // 275
        lm: lastMessageTimestamp                                                                                       // 276
      },                                                                                                               //
      $inc: {                                                                                                          // 275
        msgs: inc                                                                                                      // 278
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 280
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.replaceUsername = function(previousUsername, username) {                                            // 2
    var query, update;                                                                                                 // 283
    query = {                                                                                                          // 283
      usernames: previousUsername                                                                                      // 284
    };                                                                                                                 //
    update = {                                                                                                         // 283
      $set: {                                                                                                          // 287
        "usernames.$": username                                                                                        // 288
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 290
      multi: true                                                                                                      // 290
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.replaceMutedUsername = function(previousUsername, username) {                                       // 2
    var query, update;                                                                                                 // 293
    query = {                                                                                                          // 293
      muted: previousUsername                                                                                          // 294
    };                                                                                                                 //
    update = {                                                                                                         // 293
      $set: {                                                                                                          // 297
        "muted.$": username                                                                                            // 298
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 300
      multi: true                                                                                                      // 300
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.replaceUsernameOfUserByUserId = function(userId, username) {                                        // 2
    var query, update;                                                                                                 // 303
    query = {                                                                                                          // 303
      "u._id": userId                                                                                                  // 304
    };                                                                                                                 //
    update = {                                                                                                         // 303
      $set: {                                                                                                          // 307
        "u.username": username                                                                                         // 308
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 310
      multi: true                                                                                                      // 310
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setUserById = function(_id, user) {                                                                 // 2
    var query, update;                                                                                                 // 313
    query = {                                                                                                          // 313
      _id: _id                                                                                                         // 314
    };                                                                                                                 //
    update = {                                                                                                         // 313
      $set: {                                                                                                          // 317
        u: {                                                                                                           // 318
          _id: user._id,                                                                                               // 319
          username: user.username                                                                                      // 319
        }                                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 322
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setTypeById = function(_id, type) {                                                                 // 2
    var query, update;                                                                                                 // 325
    query = {                                                                                                          // 325
      _id: _id                                                                                                         // 326
    };                                                                                                                 //
    update = {                                                                                                         // 325
      $set: {                                                                                                          // 329
        t: type                                                                                                        // 330
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 332
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setTopicById = function(_id, topic) {                                                               // 2
    var query, update;                                                                                                 // 335
    query = {                                                                                                          // 335
      _id: _id                                                                                                         // 336
    };                                                                                                                 //
    update = {                                                                                                         // 335
      $set: {                                                                                                          // 339
        topic: topic                                                                                                   // 340
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 342
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.muteUsernameByRoomId = function(_id, username) {                                                    // 2
    var query, update;                                                                                                 // 345
    query = {                                                                                                          // 345
      _id: _id                                                                                                         // 346
    };                                                                                                                 //
    update = {                                                                                                         // 345
      $addToSet: {                                                                                                     // 349
        muted: username                                                                                                // 350
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 352
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.unmuteUsernameByRoomId = function(_id, username) {                                                  // 2
    var query, update;                                                                                                 // 355
    query = {                                                                                                          // 355
      _id: _id                                                                                                         // 356
    };                                                                                                                 //
    update = {                                                                                                         // 355
      $pull: {                                                                                                         // 359
        muted: username                                                                                                // 360
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 362
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createWithTypeNameUserAndUsernames = function(type, name, user, usernames, extraData) {             // 2
    var room;                                                                                                          // 367
    room = {                                                                                                           // 367
      name: name,                                                                                                      // 368
      t: type,                                                                                                         // 368
      usernames: usernames,                                                                                            // 368
      msgs: 0,                                                                                                         // 368
      u: {                                                                                                             // 368
        _id: user._id,                                                                                                 // 373
        username: user.username                                                                                        // 373
      }                                                                                                                //
    };                                                                                                                 //
    _.extend(room, extraData);                                                                                         // 367
    room._id = this.insert(room);                                                                                      // 367
    return room;                                                                                                       // 379
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createWithIdTypeAndName = function(_id, type, name, extraData) {                                    // 2
    var room;                                                                                                          // 382
    room = {                                                                                                           // 382
      _id: _id,                                                                                                        // 383
      ts: new Date(),                                                                                                  // 383
      t: type,                                                                                                         // 383
      name: name,                                                                                                      // 383
      usernames: [],                                                                                                   // 383
      msgs: 0                                                                                                          // 383
    };                                                                                                                 //
    _.extend(room, extraData);                                                                                         // 382
    this.insert(room);                                                                                                 // 382
    return room;                                                                                                       // 393
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeById = function(_id) {                                                                        // 2
    var query;                                                                                                         // 398
    query = {                                                                                                          // 398
      _id: _id                                                                                                         // 399
    };                                                                                                                 //
    return this.remove(query);                                                                                         // 401
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeByTypeContainingUsername = function(type, username) {                                         // 2
    var query;                                                                                                         // 404
    query = {                                                                                                          // 404
      t: type,                                                                                                         // 405
      usernames: username                                                                                              // 405
    };                                                                                                                 //
    return this.remove(query);                                                                                         // 408
  };                                                                                                                   //
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})(RocketChat.models._Base));                                                                                          //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/models/Settings.coffee.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                         //
                                                                                                                       //
RocketChat.models.Settings = new ((function(superClass) {                                                              // 1
  extend(_Class, superClass);                                                                                          // 2
                                                                                                                       //
  function _Class() {                                                                                                  // 2
    this._initModel('settings');                                                                                       // 3
  }                                                                                                                    //
                                                                                                                       //
  _Class.prototype.findOneById = function(_id, options) {                                                              // 2
    var query;                                                                                                         // 8
    query = {                                                                                                          // 8
      _id: _id                                                                                                         // 9
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 11
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByRole = function(role, options) {                                                              // 2
    var query;                                                                                                         // 16
    query = {                                                                                                          // 16
      role: role                                                                                                       // 17
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 19
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findPublic = function(options) {                                                                    // 2
    var query;                                                                                                         // 22
    query = {                                                                                                          // 22
      "public": true                                                                                                   // 23
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 25
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.updateValueById = function(_id, value) {                                                            // 2
    var query, update;                                                                                                 // 30
    query = {                                                                                                          // 30
      _id: _id                                                                                                         // 31
    };                                                                                                                 //
    update = {                                                                                                         // 30
      $set: {                                                                                                          // 34
        value: value                                                                                                   // 35
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 37
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.updateOptionsById = function(_id, options) {                                                        // 2
    var query, update;                                                                                                 // 41
    query = {                                                                                                          // 41
      _id: _id                                                                                                         // 42
    };                                                                                                                 //
    update = {                                                                                                         // 41
      $set: options                                                                                                    // 45
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 47
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createWithIdAndValue = function(_id, value) {                                                       // 2
    var record;                                                                                                        // 52
    record = {                                                                                                         // 52
      _id: _id,                                                                                                        // 53
      value: value,                                                                                                    // 53
      _createdAt: new Date                                                                                             // 53
    };                                                                                                                 //
    return this.insert(record);                                                                                        // 57
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeById = function(_id) {                                                                        // 2
    var query;                                                                                                         // 62
    query = {                                                                                                          // 62
      _id: _id                                                                                                         // 63
    };                                                                                                                 //
    return this.remove(query);                                                                                         // 65
  };                                                                                                                   //
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})(RocketChat.models._Base));                                                                                          //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/models/Subscriptions.coffee.js                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                         //
                                                                                                                       //
RocketChat.models.Subscriptions = new ((function(superClass) {                                                         // 1
  extend(_Class, superClass);                                                                                          // 2
                                                                                                                       //
  function _Class() {                                                                                                  // 2
    this._initModel('subscription');                                                                                   // 3
    this.tryEnsureIndex({                                                                                              // 3
      'rid': 1,                                                                                                        // 5
      'u._id': 1                                                                                                       // 5
    }, {                                                                                                               //
      unique: 1                                                                                                        // 5
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'u._id': 1,                                                                                                      // 6
      'name': 1,                                                                                                       // 6
      't': 1                                                                                                           // 6
    }, {                                                                                                               //
      unique: 1                                                                                                        // 6
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'open': 1                                                                                                        // 7
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'alert': 1                                                                                                       // 8
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'unread': 1                                                                                                      // 9
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'ts': 1                                                                                                          // 10
    });                                                                                                                //
  }                                                                                                                    //
                                                                                                                       //
  _Class.prototype.findOneByRoomIdAndUserId = function(roomId, userId) {                                               // 2
    var query;                                                                                                         // 15
    query = {                                                                                                          // 15
      rid: roomId,                                                                                                     // 16
      "u._id": userId                                                                                                  // 16
    };                                                                                                                 //
    return this.findOne(query);                                                                                        // 19
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByUserId = function(userId, options) {                                                          // 2
    var query;                                                                                                         // 23
    query = {                                                                                                          // 23
      "u._id": userId                                                                                                  // 24
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 26
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByRoomIdAndRoles = function(roomId, roles, options) {                                           // 2
    var query;                                                                                                         // 30
    roles = [].concat(roles);                                                                                          // 30
    query = {                                                                                                          // 30
      "rid": roomId,                                                                                                   // 32
      "roles": {                                                                                                       // 32
        $in: roles                                                                                                     // 33
      }                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 35
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.getLastSeen = function(options) {                                                                   // 2
    var query, ref, ref1, ref2;                                                                                        // 38
    if (options == null) {                                                                                             //
      options = {};                                                                                                    //
    }                                                                                                                  //
    query = {                                                                                                          // 38
      ls: {                                                                                                            // 38
        $exists: 1                                                                                                     // 38
      }                                                                                                                //
    };                                                                                                                 //
    options.sort = {                                                                                                   // 38
      ls: -1                                                                                                           // 39
    };                                                                                                                 //
    options.limit = 1;                                                                                                 // 38
    return (ref = this.find(query, options)) != null ? typeof ref.fetch === "function" ? (ref1 = ref.fetch()) != null ? (ref2 = ref1[0]) != null ? ref2.ls : void 0 : void 0 : void 0 : void 0;
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.archiveByRoomIdAndUserId = function(roomId, userId) {                                               // 2
    var query, update;                                                                                                 // 46
    query = {                                                                                                          // 46
      rid: roomId,                                                                                                     // 47
      'u._id': userId                                                                                                  // 47
    };                                                                                                                 //
    update = {                                                                                                         // 46
      $set: {                                                                                                          // 51
        alert: false,                                                                                                  // 52
        open: false,                                                                                                   // 52
        archived: true                                                                                                 // 52
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 56
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.unarchiveByRoomIdAndUserId = function(roomId, userId) {                                             // 2
    var query, update;                                                                                                 // 59
    query = {                                                                                                          // 59
      rid: roomId,                                                                                                     // 60
      'u._id': userId                                                                                                  // 60
    };                                                                                                                 //
    update = {                                                                                                         // 59
      $set: {                                                                                                          // 64
        alert: false,                                                                                                  // 65
        open: true,                                                                                                    // 65
        archived: false                                                                                                // 65
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 69
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.hideByRoomIdAndUserId = function(roomId, userId) {                                                  // 2
    var query, update;                                                                                                 // 72
    query = {                                                                                                          // 72
      rid: roomId,                                                                                                     // 73
      'u._id': userId                                                                                                  // 73
    };                                                                                                                 //
    update = {                                                                                                         // 72
      $set: {                                                                                                          // 77
        alert: false,                                                                                                  // 78
        open: false                                                                                                    // 78
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 81
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.openByRoomIdAndUserId = function(roomId, userId) {                                                  // 2
    var query, update;                                                                                                 // 84
    query = {                                                                                                          // 84
      rid: roomId,                                                                                                     // 85
      'u._id': userId                                                                                                  // 85
    };                                                                                                                 //
    update = {                                                                                                         // 84
      $set: {                                                                                                          // 89
        open: true                                                                                                     // 90
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 92
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setAsReadByRoomIdAndUserId = function(roomId, userId) {                                             // 2
    var query, update;                                                                                                 // 95
    query = {                                                                                                          // 95
      rid: roomId,                                                                                                     // 96
      'u._id': userId                                                                                                  // 96
    };                                                                                                                 //
    update = {                                                                                                         // 95
      $set: {                                                                                                          // 100
        open: true,                                                                                                    // 101
        alert: false,                                                                                                  // 101
        unread: 0,                                                                                                     // 101
        ls: new Date                                                                                                   // 101
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 106
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setFavoriteByRoomIdAndUserId = function(roomId, userId, favorite) {                                 // 2
    var query, update;                                                                                                 // 109
    if (favorite == null) {                                                                                            //
      favorite = true;                                                                                                 //
    }                                                                                                                  //
    query = {                                                                                                          // 109
      rid: roomId,                                                                                                     // 110
      'u._id': userId                                                                                                  // 110
    };                                                                                                                 //
    update = {                                                                                                         // 109
      $set: {                                                                                                          // 114
        f: favorite                                                                                                    // 115
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 117
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.updateNameByRoomId = function(roomId, name) {                                                       // 2
    var query, update;                                                                                                 // 120
    query = {                                                                                                          // 120
      rid: roomId                                                                                                      // 121
    };                                                                                                                 //
    update = {                                                                                                         // 120
      $set: {                                                                                                          // 124
        name: name,                                                                                                    // 125
        alert: true                                                                                                    // 125
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 128
      multi: true                                                                                                      // 128
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setUserUsernameByUserId = function(userId, username) {                                              // 2
    var query, update;                                                                                                 // 131
    query = {                                                                                                          // 131
      "u._id": userId                                                                                                  // 132
    };                                                                                                                 //
    update = {                                                                                                         // 131
      $set: {                                                                                                          // 135
        "u.username": username                                                                                         // 136
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 138
      multi: true                                                                                                      // 138
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setNameForDirectRoomsWithOldName = function(oldName, name) {                                        // 2
    var query, update;                                                                                                 // 141
    query = {                                                                                                          // 141
      name: oldName,                                                                                                   // 142
      t: "d"                                                                                                           // 142
    };                                                                                                                 //
    update = {                                                                                                         // 141
      $set: {                                                                                                          // 146
        name: name                                                                                                     // 147
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 149
      multi: true                                                                                                      // 149
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.incUnreadOfDirectForRoomIdExcludingUserId = function(roomId, userId, inc) {                         // 2
    var query, update;                                                                                                 // 152
    if (inc == null) {                                                                                                 //
      inc = 1;                                                                                                         //
    }                                                                                                                  //
    query = {                                                                                                          // 152
      rid: roomId,                                                                                                     // 153
      t: 'd',                                                                                                          // 153
      'u._id': {                                                                                                       // 153
        $ne: userId                                                                                                    // 156
      }                                                                                                                //
    };                                                                                                                 //
    update = {                                                                                                         // 152
      $set: {                                                                                                          // 159
        alert: true,                                                                                                   // 160
        open: true                                                                                                     // 160
      },                                                                                                               //
      $inc: {                                                                                                          // 159
        unread: inc                                                                                                    // 163
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 165
      multi: true                                                                                                      // 165
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.incUnreadForRoomIdExcludingUserId = function(roomId, userId, inc) {                                 // 2
    var query, update;                                                                                                 // 168
    if (inc == null) {                                                                                                 //
      inc = 1;                                                                                                         //
    }                                                                                                                  //
    query = {                                                                                                          // 168
      rid: roomId,                                                                                                     // 169
      'u._id': {                                                                                                       // 169
        $ne: userId                                                                                                    // 171
      }                                                                                                                //
    };                                                                                                                 //
    update = {                                                                                                         // 168
      $set: {                                                                                                          // 174
        alert: true,                                                                                                   // 175
        open: true                                                                                                     // 175
      },                                                                                                               //
      $inc: {                                                                                                          // 174
        unread: inc                                                                                                    // 178
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 180
      multi: true                                                                                                      // 180
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.incUnreadForRoomIdAndUserIds = function(roomId, userIds, inc) {                                     // 2
    var query, update;                                                                                                 // 183
    if (inc == null) {                                                                                                 //
      inc = 1;                                                                                                         //
    }                                                                                                                  //
    query = {                                                                                                          // 183
      rid: roomId,                                                                                                     // 184
      'u._id': {                                                                                                       // 184
        $in: userIds                                                                                                   // 186
      }                                                                                                                //
    };                                                                                                                 //
    update = {                                                                                                         // 183
      $set: {                                                                                                          // 189
        alert: true,                                                                                                   // 190
        open: true                                                                                                     // 190
      },                                                                                                               //
      $inc: {                                                                                                          // 189
        unread: inc                                                                                                    // 193
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 195
      multi: true                                                                                                      // 195
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setAlertForRoomIdExcludingUserId = function(roomId, userId, alert) {                                // 2
    var query, update;                                                                                                 // 198
    if (alert == null) {                                                                                               //
      alert = true;                                                                                                    //
    }                                                                                                                  //
    query = {                                                                                                          // 198
      rid: roomId,                                                                                                     // 199
      alert: {                                                                                                         // 199
        $ne: alert                                                                                                     // 201
      },                                                                                                               //
      'u._id': {                                                                                                       // 199
        $ne: userId                                                                                                    // 203
      }                                                                                                                //
    };                                                                                                                 //
    update = {                                                                                                         // 198
      $set: {                                                                                                          // 206
        alert: alert,                                                                                                  // 207
        open: true                                                                                                     // 207
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 210
      multi: true                                                                                                      // 210
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.updateTypeByRoomId = function(roomId, type) {                                                       // 2
    var query, update;                                                                                                 // 213
    query = {                                                                                                          // 213
      rid: roomId                                                                                                      // 214
    };                                                                                                                 //
    update = {                                                                                                         // 213
      $set: {                                                                                                          // 217
        t: type                                                                                                        // 218
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update, {                                                                                // 220
      multi: true                                                                                                      // 220
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.addRoleById = function(_id, role) {                                                                 // 2
    var query, update;                                                                                                 // 223
    query = {                                                                                                          // 223
      _id: _id                                                                                                         // 224
    };                                                                                                                 //
    update = {                                                                                                         // 223
      $addToSet: {                                                                                                     // 227
        roles: role                                                                                                    // 228
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 230
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeRoleById = function(_id, role) {                                                              // 2
    var query, update;                                                                                                 // 233
    query = {                                                                                                          // 233
      _id: _id                                                                                                         // 234
    };                                                                                                                 //
    update = {                                                                                                         // 233
      $pull: {                                                                                                         // 237
        roles: role                                                                                                    // 238
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 240
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.createWithRoomAndUser = function(room, user, extraData) {                                           // 2
    var subscription;                                                                                                  // 244
    subscription = {                                                                                                   // 244
      open: false,                                                                                                     // 245
      alert: false,                                                                                                    // 245
      unread: 0,                                                                                                       // 245
      ts: room.ts,                                                                                                     // 245
      rid: room._id,                                                                                                   // 245
      name: room.name,                                                                                                 // 245
      t: room.t,                                                                                                       // 245
      u: {                                                                                                             // 245
        _id: user._id,                                                                                                 // 253
        username: user.username                                                                                        // 253
      }                                                                                                                //
    };                                                                                                                 //
    _.extend(subscription, extraData);                                                                                 // 244
    return this.insert(subscription);                                                                                  // 258
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeByUserId = function(userId) {                                                                 // 2
    var query;                                                                                                         // 263
    query = {                                                                                                          // 263
      "u._id": userId                                                                                                  // 264
    };                                                                                                                 //
    return this.remove(query);                                                                                         // 266
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeByRoomId = function(roomId) {                                                                 // 2
    var query;                                                                                                         // 269
    query = {                                                                                                          // 269
      rid: roomId                                                                                                      // 270
    };                                                                                                                 //
    return this.remove(query);                                                                                         // 272
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeByRoomIdAndUserId = function(roomId, userId) {                                                // 2
    var query;                                                                                                         // 275
    query = {                                                                                                          // 275
      rid: roomId,                                                                                                     // 276
      "u._id": userId                                                                                                  // 276
    };                                                                                                                 //
    return this.remove(query);                                                                                         // 279
  };                                                                                                                   //
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})(RocketChat.models._Base));                                                                                          //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/models/Uploads.coffee.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                         //
                                                                                                                       //
RocketChat.models.Uploads = new ((function(superClass) {                                                               // 1
  extend(_Class, superClass);                                                                                          // 2
                                                                                                                       //
  function _Class() {                                                                                                  // 2
    this._initModel('uploads');                                                                                        // 3
    this.tryEnsureIndex({                                                                                              // 3
      'rid': 1                                                                                                         // 5
    });                                                                                                                //
    this.tryEnsureIndex({                                                                                              // 3
      'uploadedAt': 1                                                                                                  // 6
    });                                                                                                                //
  }                                                                                                                    //
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})(RocketChat.models._Base));                                                                                          //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/models/Users.coffee.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                         //
                                                                                                                       //
RocketChat.models.Users = new ((function(superClass) {                                                                 // 1
  extend(_Class, superClass);                                                                                          // 2
                                                                                                                       //
  function _Class() {                                                                                                  // 2
    this.model = Meteor.users;                                                                                         // 3
  }                                                                                                                    //
                                                                                                                       //
  _Class.prototype.findOneById = function(_id, options) {                                                              // 2
    return this.findOne(_id, options);                                                                                 // 8
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOneByUsername = function(username, options) {                                                   // 2
    var query;                                                                                                         // 11
    query = {                                                                                                          // 11
      username: username                                                                                               // 12
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 14
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOneByEmailAddress = function(emailAddress, options) {                                           // 2
    var query;                                                                                                         // 17
    query = {                                                                                                          // 17
      'emails.address': emailAddress                                                                                   // 18
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 20
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOneByVerifiedEmailAddress = function(emailAddress, verified, options) {                         // 2
    var query;                                                                                                         // 23
    if (verified == null) {                                                                                            //
      verified = true;                                                                                                 //
    }                                                                                                                  //
    query = {                                                                                                          // 23
      emails: {                                                                                                        // 24
        $elemMatch: {                                                                                                  // 25
          address: emailAddress,                                                                                       // 26
          verified: verified                                                                                           // 26
        }                                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 29
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOneVerifiedFromSameDomain = function(email, options) {                                          // 2
    var domain, query;                                                                                                 // 32
    domain = s.strRight(email, '@');                                                                                   // 32
    query = {                                                                                                          // 32
      emails: {                                                                                                        // 34
        $elemMatch: {                                                                                                  // 35
          address: {                                                                                                   // 36
            $regex: new RegExp("@" + domain + "$", "i"),                                                               // 37
            $ne: email                                                                                                 // 37
          },                                                                                                           //
          verified: true                                                                                               // 36
        }                                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 41
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOneAdmin = function(admin, options) {                                                           // 2
    var query;                                                                                                         // 44
    query = {                                                                                                          // 44
      admin: admin                                                                                                     // 45
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 47
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findOneByIdAndLoginToken = function(_id, token, options) {                                          // 2
    var query;                                                                                                         // 50
    query = {                                                                                                          // 50
      _id: _id,                                                                                                        // 51
      'services.resume.loginTokens.hashedToken': Accounts._hashLoginToken(token)                                       // 51
    };                                                                                                                 //
    return this.findOne(query, options);                                                                               // 54
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findUsersNotOffline = function(options) {                                                           // 2
    var query;                                                                                                         // 59
    query = {                                                                                                          // 59
      username: {                                                                                                      // 60
        $exists: 1                                                                                                     // 61
      },                                                                                                               //
      status: {                                                                                                        // 60
        $in: ['online', 'away', 'busy']                                                                                // 63
      }                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 65
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByUsername = function(username, options) {                                                      // 2
    var query;                                                                                                         // 69
    query = {                                                                                                          // 69
      username: username                                                                                               // 70
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 72
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findActiveByUsernameRegexWithExceptions = function(username, exceptions, options) {                 // 2
    var query, usernameRegex;                                                                                          // 75
    if (exceptions == null) {                                                                                          //
      exceptions = [];                                                                                                 //
    }                                                                                                                  //
    if (options == null) {                                                                                             //
      options = {};                                                                                                    //
    }                                                                                                                  //
    console.log('findActiveByUsernameRegexWithExceptions', username, exceptions);                                      // 75
    if (!_.isArray(exceptions)) {                                                                                      // 76
      exceptions = [exceptions];                                                                                       // 77
    }                                                                                                                  //
    usernameRegex = new RegExp(username, "i");                                                                         // 75
    query = {                                                                                                          // 75
      $and: [                                                                                                          // 81
        {                                                                                                              //
          active: true                                                                                                 // 82
        }, {                                                                                                           //
          username: {                                                                                                  // 83
            $nin: exceptions                                                                                           // 83
          }                                                                                                            //
        }, {                                                                                                           //
          username: usernameRegex                                                                                      // 84
        }                                                                                                              //
      ]                                                                                                                //
    };                                                                                                                 //
    console.log('findActiveByUsernameRegexWithExceptions query', JSON.stringify(query, null, ' '));                    // 75
    return this.find(query, options);                                                                                  // 90
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByActiveUsersNameOrUsername = function(nameOrUsername, options) {                               // 2
    var query;                                                                                                         // 93
    query = {                                                                                                          // 93
      username: {                                                                                                      // 94
        $exists: 1                                                                                                     // 95
      },                                                                                                               //
      active: true,                                                                                                    // 94
      $or: [                                                                                                           // 94
        {                                                                                                              //
          name: nameOrUsername                                                                                         // 99
        }, {                                                                                                           //
          username: nameOrUsername                                                                                     // 100
        }                                                                                                              //
      ]                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 103
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findUsersByNameOrUsername = function(nameOrUsername, options) {                                     // 2
    var query;                                                                                                         // 106
    query = {                                                                                                          // 106
      username: {                                                                                                      // 107
        $exists: 1                                                                                                     // 108
      },                                                                                                               //
      $or: [                                                                                                           // 107
        {                                                                                                              //
          name: nameOrUsername                                                                                         // 111
        }, {                                                                                                           //
          username: nameOrUsername                                                                                     // 112
        }                                                                                                              //
      ]                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 115
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.findByUsernameNameOrEmailAddress = function(usernameNameOrEmailAddress, options) {                  // 2
    var query;                                                                                                         // 118
    query = {                                                                                                          // 118
      $or: [                                                                                                           // 119
        {                                                                                                              //
          name: usernameNameOrEmailAddress                                                                             // 120
        }, {                                                                                                           //
          username: usernameNameOrEmailAddress                                                                         // 121
        }, {                                                                                                           //
          'emails.address': usernameNameOrEmailAddress                                                                 // 122
        }                                                                                                              //
      ]                                                                                                                //
    };                                                                                                                 //
    return this.find(query, options);                                                                                  // 125
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.getLastLogin = function(options) {                                                                  // 2
    var query, ref, ref1, ref2;                                                                                        // 128
    if (options == null) {                                                                                             //
      options = {};                                                                                                    //
    }                                                                                                                  //
    query = {                                                                                                          // 128
      lastLogin: {                                                                                                     // 128
        $exists: 1                                                                                                     // 128
      }                                                                                                                //
    };                                                                                                                 //
    options.sort = {                                                                                                   // 128
      lastLogin: -1                                                                                                    // 129
    };                                                                                                                 //
    options.limit = 1;                                                                                                 // 128
    return (ref = this.find(query, options)) != null ? typeof ref.fetch === "function" ? (ref1 = ref.fetch()) != null ? (ref2 = ref1[0]) != null ? ref2.lastLogin : void 0 : void 0 : void 0 : void 0;
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.updateLastLoginById = function(_id) {                                                               // 2
    var update;                                                                                                        // 136
    update = {                                                                                                         // 136
      $set: {                                                                                                          // 137
        lastLogin: new Date                                                                                            // 138
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 140
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setServiceId = function(_id, serviceName, serviceId) {                                              // 2
    var serviceIdKey, update;                                                                                          // 143
    update = {                                                                                                         // 143
      $set: {}                                                                                                         // 144
    };                                                                                                                 //
    serviceIdKey = "services." + serviceName + ".id";                                                                  // 143
    update.$set[serviceIdKey] = serviceId;                                                                             // 143
    return this.update(_id, update);                                                                                   // 149
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setUsername = function(_id, username) {                                                             // 2
    var update;                                                                                                        // 152
    update = {                                                                                                         // 152
      $set: {                                                                                                          // 153
        username: username                                                                                             // 153
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 155
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setEmail = function(_id, email) {                                                                   // 2
    var update;                                                                                                        // 158
    update = {                                                                                                         // 158
      $set: {                                                                                                          // 159
        'emails.0.address': email,                                                                                     // 160
        'emails.0.verified': false                                                                                     // 160
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 163
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setName = function(_id, name) {                                                                     // 2
    var update;                                                                                                        // 166
    update = {                                                                                                         // 166
      $set: {                                                                                                          // 167
        name: name                                                                                                     // 168
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 170
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setAvatarOrigin = function(_id, origin) {                                                           // 2
    var update;                                                                                                        // 173
    update = {                                                                                                         // 173
      $set: {                                                                                                          // 174
        avatarOrigin: origin                                                                                           // 175
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 177
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.unsetAvatarOrigin = function(_id) {                                                                 // 2
    var update;                                                                                                        // 180
    update = {                                                                                                         // 180
      $unset: {                                                                                                        // 181
        avatarOrigin: 1                                                                                                // 182
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 184
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setUserActive = function(_id, active) {                                                             // 2
    var update;                                                                                                        // 187
    if (active == null) {                                                                                              //
      active = true;                                                                                                   //
    }                                                                                                                  //
    update = {                                                                                                         // 187
      $set: {                                                                                                          // 188
        active: active                                                                                                 // 189
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 191
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setAllUsersActive = function(active) {                                                              // 2
    var update;                                                                                                        // 194
    update = {                                                                                                         // 194
      $set: {                                                                                                          // 195
        active: active                                                                                                 // 196
      }                                                                                                                //
    };                                                                                                                 //
    return this.update({}, update, {                                                                                   // 198
      multi: true                                                                                                      // 198
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.unsetLoginTokens = function(_id) {                                                                  // 2
    var update;                                                                                                        // 201
    update = {                                                                                                         // 201
      $set: {                                                                                                          // 202
        "services.resume.loginTokens": []                                                                              // 203
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 205
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.unsetRequirePasswordChange = function(_id) {                                                        // 2
    var update;                                                                                                        // 208
    update = {                                                                                                         // 208
      $unset: {                                                                                                        // 209
        "requirePasswordChange": true                                                                                  // 210
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 212
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setLanguage = function(_id, language) {                                                             // 2
    var update;                                                                                                        // 215
    update = {                                                                                                         // 215
      $set: {                                                                                                          // 216
        language: language                                                                                             // 217
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 219
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setProfile = function(_id, profile) {                                                               // 2
    var update;                                                                                                        // 222
    update = {                                                                                                         // 222
      $set: {                                                                                                          // 223
        "settings.profile": profile                                                                                    // 224
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 226
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setPreferences = function(_id, preferences) {                                                       // 2
    var update;                                                                                                        // 229
    update = {                                                                                                         // 229
      $set: {                                                                                                          // 230
        "settings.preferences": preferences                                                                            // 231
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(_id, update);                                                                                   // 233
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.setUtcOffset = function(_id, utcOffset) {                                                           // 2
    var query, update;                                                                                                 // 236
    query = {                                                                                                          // 236
      _id: _id,                                                                                                        // 237
      utcOffset: {                                                                                                     // 237
        $ne: utcOffset                                                                                                 // 239
      }                                                                                                                //
    };                                                                                                                 //
    update = {                                                                                                         // 236
      $set: {                                                                                                          // 242
        utcOffset: utcOffset                                                                                           // 243
      }                                                                                                                //
    };                                                                                                                 //
    return this.update(query, update);                                                                                 // 245
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.create = function(data) {                                                                           // 2
    var user;                                                                                                          // 250
    user = {                                                                                                           // 250
      createdAt: new Date,                                                                                             // 251
      avatarOrigin: 'none'                                                                                             // 251
    };                                                                                                                 //
    _.extend(user, data);                                                                                              // 250
    return this.insert(user);                                                                                          // 256
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeById = function(_id) {                                                                        // 2
    return this.remove(_id);                                                                                           // 261
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.removeByUnverifiedEmail = function(email) {                                                         // 2
    var query;                                                                                                         // 264
    query = {                                                                                                          // 264
      emails: {                                                                                                        // 265
        $elemMatch: {                                                                                                  // 266
          address: email,                                                                                              // 267
          verified: false                                                                                              // 267
        }                                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
    return this.remove(query);                                                                                         // 270
  };                                                                                                                   //
                                                                                                                       //
                                                                                                                       // 272
  /*                                                                                                                   // 272
  	Find users to send a message by email if:                                                                           //
  	- he is not online                                                                                                  //
  	- has a verified email                                                                                              //
  	- has not disabled email notifications                                                                              //
   */                                                                                                                  //
                                                                                                                       //
  _Class.prototype.getUsersToSendOfflineEmail = function(usersIds) {                                                   // 2
    var query;                                                                                                         // 279
    query = {                                                                                                          // 279
      _id: {                                                                                                           // 280
        $in: usersIds                                                                                                  // 281
      },                                                                                                               //
      status: 'offline',                                                                                               // 280
      statusConnection: {                                                                                              // 280
        $ne: 'online'                                                                                                  // 284
      },                                                                                                               //
      'emails.verified': true,                                                                                         // 280
      'settings.preferences.emailNotificationMode': {                                                                  // 280
        $ne: 'disabled'                                                                                                // 287
      }                                                                                                                //
    };                                                                                                                 //
    return this.find(query, {                                                                                          // 289
      fields: {                                                                                                        // 289
        emails: 1                                                                                                      // 289
      }                                                                                                                //
    });                                                                                                                //
  };                                                                                                                   //
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})(RocketChat.models._Base));                                                                                          //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/publications/settings.coffee.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('settings', function(ids) {                                                                             // 1
  var filter;                                                                                                          // 2
  if (ids == null) {                                                                                                   //
    ids = [];                                                                                                          //
  }                                                                                                                    //
  filter = {                                                                                                           // 2
    hidden: {                                                                                                          // 3
      $ne: true                                                                                                        // 3
    },                                                                                                                 //
    "public": true                                                                                                     // 3
  };                                                                                                                   //
  if (ids.length > 0) {                                                                                                // 6
    filter._id = {                                                                                                     // 7
      $in: ids                                                                                                         // 8
    };                                                                                                                 //
  }                                                                                                                    //
  return RocketChat.models.Settings.find(filter, {                                                                     // 10
    fields: {                                                                                                          // 10
      _id: 1,                                                                                                          // 10
      value: 1                                                                                                         // 10
    }                                                                                                                  //
  });                                                                                                                  //
});                                                                                                                    // 1
                                                                                                                       //
Meteor.publish('admin-settings', function() {                                                                          // 1
  if (!this.userId) {                                                                                                  // 13
    return this.ready();                                                                                               // 14
  }                                                                                                                    //
  if (RocketChat.authz.hasPermission(this.userId, 'view-privileged-setting')) {                                        // 16
    return RocketChat.models.Settings.find({                                                                           // 17
      hidden: {                                                                                                        // 17
        $ne: true                                                                                                      // 17
      }                                                                                                                //
    });                                                                                                                //
  } else {                                                                                                             //
    return this.ready();                                                                                               // 19
  }                                                                                                                    //
});                                                                                                                    // 12
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/functions/checkUsernameAvailability.coffee.js                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.checkUsernameAvailability = function(username) {                                                            // 1
  return !Meteor.users.findOne({                                                                                       // 2
    username: {                                                                                                        // 2
      $regex: new RegExp("^" + s.trim(s.escapeRegExp(username)) + "$", "i")                                            // 2
    }                                                                                                                  //
  });                                                                                                                  //
};                                                                                                                     // 1
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/functions/checkEmailAvailability.js                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
RocketChat.checkEmailAvailability = function (email) {                                                                 // 1
	return !Meteor.users.findOne({ "emails.address": { $regex: new RegExp("^" + s.trim(s.escapeRegExp(email)) + "$", "i") } });
};                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/functions/sendMessage.coffee.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.sendMessage = function(user, message, room, options) {                                                      // 1
  var urls;                                                                                                            // 2
  if (!user || !message || !room._id) {                                                                                // 2
    return false;                                                                                                      // 3
  }                                                                                                                    //
  if (message.ts == null) {                                                                                            // 5
    message.ts = new Date();                                                                                           // 6
  }                                                                                                                    //
  message.u = _.pick(user, ['_id', 'username']);                                                                       // 2
  message.rid = room._id;                                                                                              // 2
  if (message.parseUrls !== false) {                                                                                   // 12
    if (urls = message.msg.match(/([A-Za-z]{3,9}):\/\/([-;:&=\+\$,\w]+@{1})?([-A-Za-z0-9\.]+)+:?(\d+)?((\/[-\+=!:~%\/\.@\,\w]+)?\??([-\+=&!:;%@\/\.\,\w]+)?(?:#([^\s\)]+))?)?/g)) {
      message.urls = urls.map(function(url) {                                                                          // 14
        return {                                                                                                       //
          url: url                                                                                                     // 14
        };                                                                                                             //
      });                                                                                                              //
    }                                                                                                                  //
  }                                                                                                                    //
  message = RocketChat.callbacks.run('beforeSaveMessage', message);                                                    // 2
  if ((message._id != null) && (options != null ? options.upsert : void 0) === true) {                                 // 18
    RocketChat.models.Messages.upsert({                                                                                // 19
      _id: message._id                                                                                                 // 19
    }, message);                                                                                                       //
  } else {                                                                                                             //
    message._id = RocketChat.models.Messages.insert(message);                                                          // 21
  }                                                                                                                    //
                                                                                                                       // 23
  /*                                                                                                                   // 23
  	Defer other updates as their return is not interesting to the user                                                  //
   */                                                                                                                  //
  Meteor.defer(function() {                                                                                            // 2
    return RocketChat.callbacks.run('afterSaveMessage', message, room);                                                //
  });                                                                                                                  //
  return message;                                                                                                      // 30
};                                                                                                                     // 1
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/functions/settings.coffee.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.settings._sorter = 0;                                                                                       // 1
                                                                                                                       //
                                                                                                                       // 3
/*                                                                                                                     // 3
 * Add a setting                                                                                                       //
 * @param {String} _id                                                                                                 //
 * @param {Mixed} value                                                                                                //
 * @param {Object} setting                                                                                             //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.settings.add = function(_id, value, options) {                                                              // 1
  var ref, ref1, updateOperations;                                                                                     // 12
  if (options == null) {                                                                                               //
    options = {};                                                                                                      //
  }                                                                                                                    //
  if (!_id || (value == null)) {                                                                                       // 12
    return false;                                                                                                      // 13
  }                                                                                                                    //
  options.packageValue = value;                                                                                        // 12
  options.valueSource = 'packageValue';                                                                                // 12
  options.ts = new Date;                                                                                               // 12
  options.hidden = false;                                                                                              // 12
  if (options.sorter == null) {                                                                                        //
    options.sorter = RocketChat.settings._sorter++;                                                                    //
  }                                                                                                                    //
  if (options.enableQuery != null) {                                                                                   // 21
    options.enableQuery = JSON.stringify(options.enableQuery);                                                         // 22
  }                                                                                                                    //
  if ((typeof process !== "undefined" && process !== null ? (ref = process.env) != null ? ref[_id] : void 0 : void 0) != null) {
    value = process.env[_id];                                                                                          // 25
    if (value.toLowerCase() === "true") {                                                                              // 26
      value = true;                                                                                                    // 27
    } else if (value.toLowerCase() === "false") {                                                                      //
      value = false;                                                                                                   // 29
    }                                                                                                                  //
    options.processEnvValue = value;                                                                                   // 25
    options.valueSource = 'processEnvValue';                                                                           // 25
  } else if (((ref1 = Meteor.settings) != null ? ref1[_id] : void 0) != null) {                                        //
    value = Meteor.settings[_id];                                                                                      // 34
    options.meteorSettingsValue = value;                                                                               // 34
    options.valueSource = 'meteorSettingsValue';                                                                       // 34
  }                                                                                                                    //
  if (options.i18nLabel == null) {                                                                                     // 38
    options.i18nLabel = _id;                                                                                           // 39
  }                                                                                                                    //
  if (options.i18nDescription == null) {                                                                               // 42
    options.i18nDescription = _id + "_Description";                                                                    // 43
  }                                                                                                                    //
  updateOperations = {                                                                                                 // 12
    $set: options,                                                                                                     // 46
    $setOnInsert: {                                                                                                    // 46
      value: value,                                                                                                    // 48
      createdAt: new Date                                                                                              // 48
    }                                                                                                                  //
  };                                                                                                                   //
  if (options.section == null) {                                                                                       // 51
    updateOperations.$unset = {                                                                                        // 52
      section: 1                                                                                                       // 52
    };                                                                                                                 //
  }                                                                                                                    //
  return RocketChat.models.Settings.upsert({                                                                           // 54
    _id: _id                                                                                                           // 54
  }, updateOperations);                                                                                                //
};                                                                                                                     // 9
                                                                                                                       //
                                                                                                                       // 58
/*                                                                                                                     // 58
 * Add a setting group                                                                                                 //
 * @param {String} _id                                                                                                 //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.settings.addGroup = function(_id, options, cb) {                                                            // 1
  if (options == null) {                                                                                               //
    options = {};                                                                                                      //
  }                                                                                                                    //
  if (!_id) {                                                                                                          // 65
    return false;                                                                                                      // 66
  }                                                                                                                    //
  if (_.isFunction(options)) {                                                                                         // 68
    cb = options;                                                                                                      // 69
    options = {};                                                                                                      // 69
  }                                                                                                                    //
  if (options.i18nLabel == null) {                                                                                     // 72
    options.i18nLabel = _id;                                                                                           // 73
  }                                                                                                                    //
  if (options.i18nDescription == null) {                                                                               // 75
    options.i18nDescription = _id + "_Description";                                                                    // 76
  }                                                                                                                    //
  options.ts = new Date;                                                                                               // 65
  options.hidden = false;                                                                                              // 65
  RocketChat.models.Settings.upsert({                                                                                  // 65
    _id: _id                                                                                                           // 81
  }, {                                                                                                                 //
    $set: options,                                                                                                     // 82
    $setOnInsert: {                                                                                                    // 82
      type: 'group',                                                                                                   // 84
      createdAt: new Date                                                                                              // 84
    }                                                                                                                  //
  });                                                                                                                  //
  if (cb != null) {                                                                                                    // 87
    cb.call({                                                                                                          // 88
      add: function(id, value, options) {                                                                              // 89
        if (options == null) {                                                                                         //
          options = {};                                                                                                //
        }                                                                                                              //
        options.group = _id;                                                                                           // 90
        return RocketChat.settings.add(id, value, options);                                                            //
      },                                                                                                               //
      section: function(section, cb) {                                                                                 // 89
        return cb.call({                                                                                               //
          add: function(id, value, options) {                                                                          // 95
            if (options == null) {                                                                                     //
              options = {};                                                                                            //
            }                                                                                                          //
            options.group = _id;                                                                                       // 96
            options.section = section;                                                                                 // 96
            return RocketChat.settings.add(id, value, options);                                                        //
          }                                                                                                            //
        });                                                                                                            //
      }                                                                                                                //
    });                                                                                                                //
  }                                                                                                                    //
};                                                                                                                     // 62
                                                                                                                       //
                                                                                                                       // 103
/*                                                                                                                     // 103
 * Remove a setting by id                                                                                              //
 * @param {String} _id                                                                                                 //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.settings.removeById = function(_id) {                                                                       // 1
  if (!_id) {                                                                                                          // 110
    return false;                                                                                                      // 111
  }                                                                                                                    //
  return RocketChat.models.Settings.removeById(_id);                                                                   // 113
};                                                                                                                     // 107
                                                                                                                       //
                                                                                                                       // 116
/*                                                                                                                     // 116
 * Update a setting by id                                                                                              //
 * @param {String} _id                                                                                                 //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.settings.updateById = function(_id, value) {                                                                // 1
  if (!_id || (value == null)) {                                                                                       // 123
    return false;                                                                                                      // 124
  }                                                                                                                    //
  return RocketChat.models.Settings.updateValueById(_id, value);                                                       // 126
};                                                                                                                     // 120
                                                                                                                       //
                                                                                                                       // 129
/*                                                                                                                     // 129
 * Update options of a setting by id                                                                                   //
 * @param {String} _id                                                                                                 //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.settings.updateOptionsById = function(_id, options) {                                                       // 1
  if (!_id || (options == null)) {                                                                                     // 136
    return false;                                                                                                      // 137
  }                                                                                                                    //
  return RocketChat.models.Settings.updateOptionsById(_id, options);                                                   // 139
};                                                                                                                     // 133
                                                                                                                       //
                                                                                                                       // 142
/*                                                                                                                     // 142
 * Update a setting by id                                                                                              //
 * @param {String} _id                                                                                                 //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.settings.clearById = function(_id) {                                                                        // 1
  if (_id == null) {                                                                                                   // 149
    return false;                                                                                                      // 150
  }                                                                                                                    //
  return RocketChat.models.Settings.updateValueById(_id, void 0);                                                      // 152
};                                                                                                                     // 146
                                                                                                                       //
                                                                                                                       // 155
/*                                                                                                                     // 155
 * Update a setting by id                                                                                              //
 */                                                                                                                    //
                                                                                                                       //
RocketChat.settings.init = function() {                                                                                // 1
  var initialLoad;                                                                                                     // 159
  initialLoad = true;                                                                                                  // 159
  RocketChat.models.Settings.find().observe({                                                                          // 159
    added: function(record) {                                                                                          // 161
      Meteor.settings[record._id] = record.value;                                                                      // 162
      if (record.env === true) {                                                                                       // 163
        process.env[record._id] = record.value;                                                                        // 164
      }                                                                                                                //
      return RocketChat.settings.load(record._id, record.value, initialLoad);                                          //
    },                                                                                                                 //
    changed: function(record) {                                                                                        // 161
      Meteor.settings[record._id] = record.value;                                                                      // 167
      if (record.env === true) {                                                                                       // 168
        process.env[record._id] = record.value;                                                                        // 169
      }                                                                                                                //
      return RocketChat.settings.load(record._id, record.value, initialLoad);                                          //
    },                                                                                                                 //
    removed: function(record) {                                                                                        // 161
      delete Meteor.settings[record._id];                                                                              // 172
      if (record.env === true) {                                                                                       // 173
        delete process.env[record._id];                                                                                // 174
      }                                                                                                                //
      return RocketChat.settings.load(record._id, void 0, initialLoad);                                                //
    }                                                                                                                  //
  });                                                                                                                  //
  return initialLoad = false;                                                                                          //
};                                                                                                                     // 158
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/functions/setUsername.coffee.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat._setUsername = function(userId, username) {                                                                 // 1
  var nameValidation, previousUsername, ref, rs, user, ws;                                                             // 2
  username = s.trim(username);                                                                                         // 2
  if (!userId || !username) {                                                                                          // 3
    return false;                                                                                                      // 4
  }                                                                                                                    //
  try {                                                                                                                // 6
    nameValidation = new RegExp('^' + RocketChat.settings.get('UTF8_Names_Validation') + '$');                         // 7
  } catch (_error) {                                                                                                   //
    nameValidation = new RegExp('^[0-9a-zA-Z-_.]+$');                                                                  // 9
  }                                                                                                                    //
  if (!nameValidation.test(username)) {                                                                                // 11
    return false;                                                                                                      // 12
  }                                                                                                                    //
  user = RocketChat.models.Users.findOneById(userId);                                                                  // 2
  if (user.username === username) {                                                                                    // 17
    return user;                                                                                                       // 18
  }                                                                                                                    //
  previousUsername = user.username;                                                                                    // 2
  if (!previousUsername || !(username.toLowerCase() === previousUsername.toLowerCase())) {                             // 23
    if (!RocketChat.checkUsernameAvailability(username)) {                                                             // 24
      return false;                                                                                                    // 25
    }                                                                                                                  //
  }                                                                                                                    //
  if (!previousUsername && ((ref = user.emails) != null ? ref.length : void 0) > 0 && RocketChat.settings.get('Accounts_Enrollment_Email')) {
    Accounts.sendEnrollmentEmail(user._id);                                                                            // 31
  }                                                                                                                    //
  if (previousUsername) {                                                                                              // 34
    RocketChat.models.Messages.updateAllUsernamesByUserId(user._id, username);                                         // 35
    RocketChat.models.Messages.updateUsernameOfEditByUserId(user._id, username);                                       // 35
    RocketChat.models.Messages.findByMention(previousUsername).forEach(function(msg) {                                 // 35
      var updatedMsg;                                                                                                  // 39
      updatedMsg = msg.msg.replace(new RegExp("@" + previousUsername, "ig"), "@" + username);                          // 39
      return RocketChat.models.Messages.updateUsernameAndMessageOfMentionByIdAndOldUsername(msg._id, previousUsername, username, updatedMsg);
    });                                                                                                                //
    RocketChat.models.Rooms.replaceUsername(previousUsername, username);                                               // 35
    RocketChat.models.Rooms.replaceMutedUsername(previousUsername, username);                                          // 35
    RocketChat.models.Rooms.replaceUsernameOfUserByUserId(user._id, username);                                         // 35
    RocketChat.models.Subscriptions.setUserUsernameByUserId(user._id, username);                                       // 35
    RocketChat.models.Subscriptions.setNameForDirectRoomsWithOldName(previousUsername, username);                      // 35
    rs = RocketChatFileAvatarInstance.getFileWithReadStream(encodeURIComponent(previousUsername + ".jpg"));            // 35
    if (rs != null) {                                                                                                  // 50
      RocketChatFileAvatarInstance.deleteFile(encodeURIComponent(username + ".jpg"));                                  // 51
      ws = RocketChatFileAvatarInstance.createWriteStream(encodeURIComponent(username + ".jpg"), rs.contentType);      // 51
      ws.on('end', Meteor.bindEnvironment(function() {                                                                 // 51
        return RocketChatFileAvatarInstance.deleteFile(encodeURIComponent(previousUsername + ".jpg"));                 //
      }));                                                                                                             //
      rs.readStream.pipe(ws);                                                                                          // 51
    }                                                                                                                  //
  }                                                                                                                    //
  RocketChat.models.Users.setUsername(user._id, username);                                                             // 2
  user.username = username;                                                                                            // 2
  return user;                                                                                                         // 60
};                                                                                                                     // 1
                                                                                                                       //
RocketChat.setUsername = RocketChat.RateLimiter.limitFunction(RocketChat._setUsername, 1, 60000, {                     // 1
  0: function(userId) {                                                                                                // 63
    return !RocketChat.authz.hasPermission(userId, 'edit-other-user-info');                                            // 63
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/functions/setEmail.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
RocketChat._setEmail = function (userId, email) {                                                                      // 1
	email = s.trim(email);                                                                                                // 2
	if (!userId) {                                                                                                        // 3
		throw new Meteor.Error('invalid-user', "[methods] setEmail -> Invalid user");                                        // 4
	}                                                                                                                     //
                                                                                                                       //
	if (!email) {                                                                                                         // 7
		throw new Meteor.Error('invalid-email', "[methods] setEmail -> Invalid email");                                      // 8
	}                                                                                                                     //
                                                                                                                       //
	emailValidation = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
	if (!emailValidation.test(email)) {                                                                                   // 12
		throw new Meteor.Error('email-invalid', "#{email} is not a valid e-mail");                                           // 13
	}                                                                                                                     //
                                                                                                                       //
	user = RocketChat.models.Users.findOneById(userId);                                                                   // 16
                                                                                                                       //
	// User already has desired username, return                                                                          //
	if (user.emails && user.emails[0] && user.emails[0].address === email) {                                              // 19
		return user;                                                                                                         // 20
	}                                                                                                                     //
                                                                                                                       //
	// Check e-mail availability                                                                                          //
	if (!RocketChat.checkEmailAvailability(email)) {                                                                      // 24
		throw new Meteor.Error('email-unavailable', "#{email} is already in use :(");                                        // 25
	}                                                                                                                     //
                                                                                                                       //
	// Set new email                                                                                                      //
	RocketChat.models.Users.setEmail(user._id, email);                                                                    // 29
	user.email = email;                                                                                                   // 30
	return user;                                                                                                          // 31
};                                                                                                                     //
                                                                                                                       //
RocketChat.setEmail = RocketChat.RateLimiter.limitFunction(RocketChat._setEmail, 1, 60000, {                           // 34
	0: function (userId) {                                                                                                // 35
		return !RocketChat.authz.hasPermission(userId, 'edit-other-user-info');                                              // 35
	} // Administrators have permission to change others emails, so don't limit those                                     //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/functions/Notifications.coffee.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var func,                                                                                                              // 1
  slice = [].slice;                                                                                                    //
                                                                                                                       //
RocketChat.Notifications = new ((function() {                                                                          // 1
  function _Class() {                                                                                                  // 2
    var self;                                                                                                          // 3
    self = this;                                                                                                       // 3
    this.debug = false;                                                                                                // 3
    this.streamAll = new Meteor.Stream('notify-all');                                                                  // 3
    this.streamRoom = new Meteor.Stream('notify-room');                                                                // 3
    this.streamUser = new Meteor.Stream('notify-user');                                                                // 3
    this.streamAll.permissions.write(function() {                                                                      // 3
      return false;                                                                                                    // 12
    });                                                                                                                //
    this.streamAll.permissions.read(function() {                                                                       // 3
      return this.userId != null;                                                                                      // 13
    });                                                                                                                //
    this.streamRoom.permissions.write(function() {                                                                     // 3
      return false;                                                                                                    // 15
    });                                                                                                                //
    this.streamRoom.permissions.read(function(eventName) {                                                             // 3
      var roomId, user;                                                                                                // 17
      if (this.userId == null) {                                                                                       // 17
        return false;                                                                                                  // 17
      }                                                                                                                //
      roomId = eventName.split('/')[0];                                                                                // 17
      user = Meteor.users.findOne(this.userId, {                                                                       // 17
        fields: {                                                                                                      // 21
          username: 1                                                                                                  // 21
        }                                                                                                              //
      });                                                                                                              //
      return RocketChat.models.Rooms.findOneByIdContainigUsername(roomId, user.username, {                             // 22
        fields: {                                                                                                      //
          _id: 1                                                                                                       //
        }                                                                                                              //
      }) != null;                                                                                                      //
    });                                                                                                                //
    this.streamUser.permissions.write(function() {                                                                     // 3
      return this.userId != null;                                                                                      // 24
    });                                                                                                                //
    this.streamUser.permissions.read(function(eventName) {                                                             // 3
      var userId;                                                                                                      // 26
      userId = eventName.split('/')[0];                                                                                // 26
      return (this.userId != null) && this.userId === userId;                                                          // 27
    });                                                                                                                //
  }                                                                                                                    //
                                                                                                                       //
  _Class.prototype.notifyAll = function() {                                                                            // 2
    var args, eventName;                                                                                               // 31
    eventName = arguments[0], args = 2 <= arguments.length ? slice.call(arguments, 1) : [];                            // 31
    if (this.debug === true) {                                                                                         // 31
      console.log('notifyAll', arguments);                                                                             // 31
    }                                                                                                                  //
    args.unshift(eventName);                                                                                           // 31
    return this.streamAll.emit.apply(this.streamAll, args);                                                            //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.notifyRoom = function() {                                                                           // 2
    var args, eventName, room;                                                                                         // 37
    room = arguments[0], eventName = arguments[1], args = 3 <= arguments.length ? slice.call(arguments, 2) : [];       // 37
    if (this.debug === true) {                                                                                         // 37
      console.log('notifyRoom', arguments);                                                                            // 37
    }                                                                                                                  //
    args.unshift(room + "/" + eventName);                                                                              // 37
    return this.streamRoom.emit.apply(this.streamRoom, args);                                                          //
  };                                                                                                                   //
                                                                                                                       //
  _Class.prototype.notifyUser = function() {                                                                           // 2
    var args, eventName, userId;                                                                                       // 43
    userId = arguments[0], eventName = arguments[1], args = 3 <= arguments.length ? slice.call(arguments, 2) : [];     // 43
    if (this.debug === true) {                                                                                         // 43
      console.log('notifyUser', arguments);                                                                            // 43
    }                                                                                                                  //
    args.unshift(userId + "/" + eventName);                                                                            // 43
    return this.streamUser.emit.apply(this.streamUser, args);                                                          //
  };                                                                                                                   //
                                                                                                                       //
  return _Class;                                                                                                       //
                                                                                                                       //
})());                                                                                                                 //
                                                                                                                       //
func = function(eventName, username, typing) {                                                                         // 1
  var e, ref, room, user;                                                                                              // 53
  ref = eventName.split('/'), room = ref[0], e = ref[1];                                                               // 53
  if (e === 'webrtc') {                                                                                                // 55
    return true;                                                                                                       // 56
  }                                                                                                                    //
  if (e === 'typing') {                                                                                                // 58
    user = Meteor.users.findOne(this.userId, {                                                                         // 59
      fields: {                                                                                                        // 59
        username: 1                                                                                                    // 59
      }                                                                                                                //
    });                                                                                                                //
    if ((user != null ? user.username : void 0) === username) {                                                        // 60
      return true;                                                                                                     // 61
    }                                                                                                                  //
  }                                                                                                                    //
  return false;                                                                                                        // 63
};                                                                                                                     // 52
                                                                                                                       //
RocketChat.Notifications.streamRoom.permissions.write(func, false);                                                    // 1
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/addOAuthService.coffee.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  addOAuthService: function(name) {                                                                                    // 2
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] addOAuthService -> Invalid user");                             // 4
    }                                                                                                                  //
    if (RocketChat.authz.hasPermission(Meteor.userId(), 'add-oauth-service') !== true) {                               // 6
      throw new Meteor.Error('not-authorized', '[methods] addOAuthService -> Not authorized');                         // 7
    }                                                                                                                  //
    name = name.toLowerCase().replace(/[^a-z0-9]/g, '');                                                               // 3
    name = s.capitalize(name);                                                                                         // 3
    RocketChat.settings.add("Accounts_OAuth_Custom_" + name, false, {                                                  // 3
      type: 'boolean',                                                                                                 // 11
      group: 'Accounts',                                                                                               // 11
      section: "Custom OAuth: " + name,                                                                                // 11
      i18nLabel: 'Accounts_OAuth_Custom_Enable',                                                                       // 11
      persistent: true                                                                                                 // 11
    });                                                                                                                //
    RocketChat.settings.add("Accounts_OAuth_Custom_" + name + "_url", '', {                                            // 3
      type: 'string',                                                                                                  // 12
      group: 'Accounts',                                                                                               // 12
      section: "Custom OAuth: " + name,                                                                                // 12
      i18nLabel: 'Accounts_OAuth_Custom_URL',                                                                          // 12
      persistent: true                                                                                                 // 12
    });                                                                                                                //
    RocketChat.settings.add("Accounts_OAuth_Custom_" + name + "_token_path", '/oauth/token', {                         // 3
      type: 'string',                                                                                                  // 13
      group: 'Accounts',                                                                                               // 13
      section: "Custom OAuth: " + name,                                                                                // 13
      i18nLabel: 'Accounts_OAuth_Custom_Token_Path',                                                                   // 13
      persistent: true                                                                                                 // 13
    });                                                                                                                //
    RocketChat.settings.add("Accounts_OAuth_Custom_" + name + "_identity_path", '/me', {                               // 3
      type: 'string',                                                                                                  // 14
      group: 'Accounts',                                                                                               // 14
      section: "Custom OAuth: " + name,                                                                                // 14
      i18nLabel: 'Accounts_OAuth_Custom_Identity_Path',                                                                // 14
      persistent: true                                                                                                 // 14
    });                                                                                                                //
    RocketChat.settings.add("Accounts_OAuth_Custom_" + name + "_authorize_path", '/oauth/authorize', {                 // 3
      type: 'string',                                                                                                  // 15
      group: 'Accounts',                                                                                               // 15
      section: "Custom OAuth: " + name,                                                                                // 15
      i18nLabel: 'Accounts_OAuth_Custom_Authorize_Path',                                                               // 15
      persistent: true                                                                                                 // 15
    });                                                                                                                //
    RocketChat.settings.add("Accounts_OAuth_Custom_" + name + "_id", '', {                                             // 3
      type: 'string',                                                                                                  // 16
      group: 'Accounts',                                                                                               // 16
      section: "Custom OAuth: " + name,                                                                                // 16
      i18nLabel: 'Accounts_OAuth_Custom_id',                                                                           // 16
      persistent: true                                                                                                 // 16
    });                                                                                                                //
    RocketChat.settings.add("Accounts_OAuth_Custom_" + name + "_secret", '', {                                         // 3
      type: 'string',                                                                                                  // 17
      group: 'Accounts',                                                                                               // 17
      section: "Custom OAuth: " + name,                                                                                // 17
      i18nLabel: 'Accounts_OAuth_Custom_Secret',                                                                       // 17
      persistent: true                                                                                                 // 17
    });                                                                                                                //
    RocketChat.settings.add("Accounts_OAuth_Custom_" + name + "_login_style", 'popup', {                               // 3
      type: 'select',                                                                                                  // 18
      group: 'Accounts',                                                                                               // 18
      section: "Custom OAuth: " + name,                                                                                // 18
      i18nLabel: 'Accounts_OAuth_Custom_Login_Style',                                                                  // 18
      persistent: true,                                                                                                // 18
      values: [                                                                                                        // 18
        {                                                                                                              //
          key: 'redirect',                                                                                             // 18
          i18nLabel: 'Redirect'                                                                                        // 18
        }, {                                                                                                           //
          key: 'popup',                                                                                                // 18
          i18nLabel: 'Popup'                                                                                           // 18
        }, {                                                                                                           //
          key: '',                                                                                                     // 18
          i18nLabel: 'Default'                                                                                         // 18
        }                                                                                                              //
      ]                                                                                                                //
    });                                                                                                                //
    RocketChat.settings.add("Accounts_OAuth_Custom_" + name + "_button_label_text", '', {                              // 3
      type: 'string',                                                                                                  // 19
      group: 'Accounts',                                                                                               // 19
      section: "Custom OAuth: " + name,                                                                                // 19
      i18nLabel: 'Accounts_OAuth_Custom_Button_Label_Text',                                                            // 19
      persistent: true                                                                                                 // 19
    });                                                                                                                //
    RocketChat.settings.add("Accounts_OAuth_Custom_" + name + "_button_label_color", '#FFFFFF', {                      // 3
      type: 'string',                                                                                                  // 20
      group: 'Accounts',                                                                                               // 20
      section: "Custom OAuth: " + name,                                                                                // 20
      i18nLabel: 'Accounts_OAuth_Custom_Button_Label_Color',                                                           // 20
      persistent: true                                                                                                 // 20
    });                                                                                                                //
    return RocketChat.settings.add("Accounts_OAuth_Custom_" + name + "_button_color", '#13679A', {                     //
      type: 'string',                                                                                                  // 21
      group: 'Accounts',                                                                                               // 21
      section: "Custom OAuth: " + name,                                                                                // 21
      i18nLabel: 'Accounts_OAuth_Custom_Button_Color',                                                                 // 21
      persistent: true                                                                                                 // 21
    });                                                                                                                //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/checkRegistrationSecretURL.coffee.js                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  checkRegistrationSecretURL: function(hash) {                                                                         // 2
    return hash === RocketChat.settings.get('Accounts_RegistrationForm_SecretURL');                                    // 3
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/clearRequirePasswordChange.js                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({                                                                                                       // 1
	clearRequirePasswordChange: function () {                                                                             // 2
		if (!Meteor.userId()) {                                                                                              // 3
			throw new Meteor.Error('invalid-user', "[methods] clearRequirePasswordChange -> Invalid user");                     // 4
		}                                                                                                                    //
                                                                                                                       //
		return RocketChat.models.Users.unsetRequirePasswordChange(Meteor.userId());                                          // 7
	}                                                                                                                     //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/joinDefaultChannels.coffee.js                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  joinDefaultChannels: function(silenced) {                                                                            // 2
    var user;                                                                                                          // 3
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] joinDefaultChannels -> Invalid user");                         // 4
    }                                                                                                                  //
    user = Meteor.user();                                                                                              // 3
    RocketChat.callbacks.run('beforeJoinDefaultChannels', user);                                                       // 3
    return RocketChat.models.Rooms.findByDefaultAndTypes(true, ['c', 'p'], {                                           //
      fields: {                                                                                                        // 10
        usernames: 0                                                                                                   // 10
      }                                                                                                                //
    }).forEach(function(room) {                                                                                        //
      RocketChat.models.Rooms.addUsernameById(room._id, user.username);                                                // 13
      if (RocketChat.models.Subscriptions.findOneByRoomIdAndUserId(room._id, user._id) == null) {                      // 15
        RocketChat.models.Subscriptions.createWithRoomAndUser(room, user, {                                            // 18
          ts: new Date(),                                                                                              // 19
          open: true,                                                                                                  // 19
          alert: true,                                                                                                 // 19
          unread: 1                                                                                                    // 19
        });                                                                                                            //
        if (!silenced) {                                                                                               // 25
          return RocketChat.models.Messages.createUserJoinWithRoomIdAndUser(room._id, user);                           //
        }                                                                                                              //
      }                                                                                                                //
    });                                                                                                                //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/removeOAuthService.coffee.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  removeOAuthService: function(name) {                                                                                 // 2
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] addOAuthService -> Invalid user");                             // 4
    }                                                                                                                  //
    if (RocketChat.authz.hasPermission(Meteor.userId(), 'add-oauth-service') !== true) {                               // 6
      throw new Meteor.Error('not-authorized', '[methods] addOAuthService -> Not authorized');                         // 7
    }                                                                                                                  //
    name = name.toLowerCase().replace(/[^a-z0-9]/g, '');                                                               // 3
    name = s.capitalize(name);                                                                                         // 3
    RocketChat.settings.removeById("Accounts_OAuth_Custom_" + name);                                                   // 3
    RocketChat.settings.removeById("Accounts_OAuth_Custom_" + name + "_url");                                          // 3
    RocketChat.settings.removeById("Accounts_OAuth_Custom_" + name + "_token_path");                                   // 3
    RocketChat.settings.removeById("Accounts_OAuth_Custom_" + name + "_identity_path");                                // 3
    RocketChat.settings.removeById("Accounts_OAuth_Custom_" + name + "_authorize_path");                               // 3
    RocketChat.settings.removeById("Accounts_OAuth_Custom_" + name + "_id");                                           // 3
    RocketChat.settings.removeById("Accounts_OAuth_Custom_" + name + "_secret");                                       // 3
    RocketChat.settings.removeById("Accounts_OAuth_Custom_" + name + "_button_label_text");                            // 3
    RocketChat.settings.removeById("Accounts_OAuth_Custom_" + name + "_button_label_color");                           // 3
    return RocketChat.settings.removeById("Accounts_OAuth_Custom_" + name + "_button_color");                          //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/robotMethods.coffee.js                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  'robot.modelCall': function(model, method, args) {                                                                   // 2
    var call, ref;                                                                                                     // 3
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', '[methods] robot.modelCall -> Invalid user');                             // 4
    }                                                                                                                  //
    if (!RocketChat.authz.hasRole(Meteor.userId(), 'robot')) {                                                         // 6
      throw new Meteor.Error('unauthorized', '[methods] robot.modelCall -> Unauthorized');                             // 7
    }                                                                                                                  //
    if (!_.isFunction((ref = RocketChat.models[model]) != null ? ref[method] : void 0)) {                              // 9
      throw new Meteor.Error('invalid-method', '[methods] robot.modelCall -> Invalid method');                         // 10
    }                                                                                                                  //
    call = RocketChat.models[model][method].apply(RocketChat.models[model], args);                                     // 3
    if ((call != null ? typeof call.fetch === "function" ? call.fetch() : void 0 : void 0) != null) {                  // 14
      return call.fetch();                                                                                             // 15
    } else {                                                                                                           //
      return call;                                                                                                     // 17
    }                                                                                                                  //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/saveSetting.coffee.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  saveSetting: function(_id, value) {                                                                                  // 2
    var user;                                                                                                          // 3
    if (Meteor.userId() != null) {                                                                                     // 3
      user = Meteor.users.findOne(Meteor.userId());                                                                    // 4
    }                                                                                                                  //
    if (RocketChat.authz.hasPermission(Meteor.userId(), 'edit-privileged-setting') !== true) {                         // 6
      throw new Meteor.Error(503, 'Not authorized');                                                                   // 7
    }                                                                                                                  //
    RocketChat.settings.updateById(_id, value);                                                                        // 3
    return true;                                                                                                       // 11
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/sendInvitationEmail.coffee.js                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  sendInvitationEmail: function(emails) {                                                                              // 2
    var email, i, len, rfcMailPattern, validEmails;                                                                    // 3
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] sendInvitationEmail -> Invalid user");                         // 4
    }                                                                                                                  //
    if (!RocketChat.authz.hasRole(Meteor.userId(), 'admin')) {                                                         // 6
      throw new Meteor.Error('not-authorized', '[methods] sendInvitationEmail -> Not authorized');                     // 7
    }                                                                                                                  //
    rfcMailPattern = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    validEmails = _.compact(_.map(emails, function(email) {                                                            // 3
      if (rfcMailPattern.test(email)) {                                                                                // 10
        return email;                                                                                                  // 10
      }                                                                                                                //
    }));                                                                                                               //
    for (i = 0, len = validEmails.length; i < len; i++) {                                                              // 12
      email = validEmails[i];                                                                                          //
      this.unblock();                                                                                                  // 13
      Email.send({                                                                                                     // 13
        to: email,                                                                                                     // 16
        from: RocketChat.settings.get('From_Email'),                                                                   // 16
        subject: RocketChat.settings.get('Invitation_Subject'),                                                        // 16
        html: RocketChat.settings.get('Invitation_HTML')                                                               // 16
      });                                                                                                              //
    }                                                                                                                  // 12
    return validEmails;                                                                                                // 22
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/sendMessage.coffee.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var indexOf = [].indexOf || function(item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };
                                                                                                                       //
Meteor.methods({                                                                                                       // 1
  sendMessage: function(message, options) {                                                                            // 2
    var ref, ref1, room, user;                                                                                         // 3
    if (((ref = message.msg) != null ? ref.length : void 0) > RocketChat.settings.get('Message_MaxAllowedSize')) {     // 3
      throw new Meteor.Error(400, '[methods] sendMessage -> Message size exceed Message_MaxAllowedSize');              // 4
    }                                                                                                                  //
    if (!Meteor.userId()) {                                                                                            // 6
      throw new Meteor.Error('invalid-user', "[methods] sendMessage -> Invalid user");                                 // 7
    }                                                                                                                  //
    user = RocketChat.models.Users.findOneById(Meteor.userId(), {                                                      // 3
      fields: {                                                                                                        // 9
        username: 1                                                                                                    // 9
      }                                                                                                                //
    });                                                                                                                //
    room = Meteor.call('canAccessRoom', message.rid, user._id);                                                        // 3
    if (!room) {                                                                                                       // 13
      return false;                                                                                                    // 14
    }                                                                                                                  //
    if (ref1 = user.username, indexOf.call(room.muted || [], ref1) >= 0) {                                             // 16
      RocketChat.Notifications.notifyUser(Meteor.userId(), 'message', {                                                // 17
        _id: Random.id(),                                                                                              // 17
        rid: room._id,                                                                                                 // 17
        ts: new Date,                                                                                                  // 17
        msg: TAPi18n.__('You_have_been_muted', {}, user.language)                                                      // 17
      });                                                                                                              //
      return false;                                                                                                    // 23
    }                                                                                                                  //
    return RocketChat.sendMessage(user, message, room, options);                                                       //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
DDPRateLimiter.addRule({                                                                                               // 1
  type: 'method',                                                                                                      // 29
  name: 'sendMessage',                                                                                                 // 29
  userId: function(userId) {                                                                                           // 29
    var ref;                                                                                                           // 32
    return ((ref = RocketChat.models.Users.findOneById(userId)) != null ? ref.username : void 0) !== RocketChat.settings.get('RocketBot_Name');
  }                                                                                                                    //
}, 5, 1000);                                                                                                           //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/sendSMTPTestEmail.coffee.js                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  sendSMTPTestEmail: function() {                                                                                      // 2
    var ref, ref1, user;                                                                                               // 3
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] sendSMTPTestEmail -> Invalid user");                           // 4
    }                                                                                                                  //
    user = Meteor.user();                                                                                              // 3
    if (!((ref = user.emails) != null ? (ref1 = ref[0]) != null ? ref1.address : void 0 : void 0)) {                   // 7
      throw new Meteor.Error('invalid-email', "[methods] sendSMTPTestEmail -> Invalid e-mail");                        // 8
    }                                                                                                                  //
    Email.send({                                                                                                       // 3
      to: user.emails[0].address,                                                                                      // 11
      from: RocketChat.settings.get('From_Email'),                                                                     // 11
      subject: "SMTP Test E-mail",                                                                                     // 11
      html: "You have successfully sent an e-mail"                                                                     // 11
    });                                                                                                                //
    console.log('Sending email to ' + user.emails[0].address);                                                         // 3
    return {                                                                                                           // 18
      message: "Your_mail_was_sent_to_s",                                                                              // 18
      params: [user.emails[0].address]                                                                                 // 18
    };                                                                                                                 //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
DDPRateLimiter.addRule({                                                                                               // 1
  type: 'method',                                                                                                      // 25
  name: 'sendSMTPTestEmail',                                                                                           // 25
  userId: function(userId) {                                                                                           // 25
    return true;                                                                                                       // 28
  }                                                                                                                    //
}, 1, 1000);                                                                                                           //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/setAdminStatus.coffee.js                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  setAdminStatus: function(userId, admin) {                                                                            // 2
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] setAdminStatus -> Invalid user");                              // 4
    }                                                                                                                  //
    if (RocketChat.authz.hasPermission(Meteor.userId(), 'assign-admin-role') !== true) {                               // 6
      throw new Meteor.Error('not-authorized', '[methods] setAdminStatus -> Not authorized');                          // 7
    }                                                                                                                  //
    if (admin) {                                                                                                       // 9
      RocketChat.authz.addUserRoles(userId, 'admin');                                                                  // 10
    } else {                                                                                                           //
      RocketChat.authz.removeUserFromRoles(userId, 'admin');                                                           // 12
    }                                                                                                                  //
    return true;                                                                                                       // 14
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/setRealName.coffee.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  setRealName: function(name) {                                                                                        // 2
    var user;                                                                                                          // 3
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] setRealName -> Invalid user");                                 // 4
    }                                                                                                                  //
    user = Meteor.user();                                                                                              // 3
    if (user.name === name) {                                                                                          // 8
      return name;                                                                                                     // 9
    }                                                                                                                  //
    if (_.trim(name)) {                                                                                                // 11
      name = _.trim(name);                                                                                             // 12
    }                                                                                                                  //
    if (!RocketChat.models.Users.setName(Meteor.userId(), name)) {                                                     // 14
      throw new Meteor.Error('could-not-change-name', "Could not change name");                                        // 15
    }                                                                                                                  //
    return name;                                                                                                       // 17
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/setUsername.coffee.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  setUsername: function(username) {                                                                                    // 2
    var nameValidation, user;                                                                                          // 3
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] setUsername -> Invalid user");                                 // 4
    }                                                                                                                  //
    user = Meteor.user();                                                                                              // 3
    if ((user.username != null) && !RocketChat.settings.get("Accounts_AllowUsernameChange")) {                         // 8
      throw new Meteor.Error(403, "[methods] setUsername -> Username change not allowed");                             // 9
    }                                                                                                                  //
    if (user.username === username) {                                                                                  // 11
      return username;                                                                                                 // 12
    }                                                                                                                  //
    try {                                                                                                              // 14
      nameValidation = new RegExp('^' + RocketChat.settings.get('UTF8_Names_Validation') + '$');                       // 15
    } catch (_error) {                                                                                                 //
      nameValidation = new RegExp('^[0-9a-zA-Z-_.]+$');                                                                // 17
    }                                                                                                                  //
    if (!nameValidation.test(username)) {                                                                              // 19
      throw new Meteor.Error('username-invalid', username + " is not a valid username, use only letters, numbers, dots and dashes");
    }                                                                                                                  //
    if (user.username !== void 0) {                                                                                    // 22
      if (!username.toLowerCase() === user.username.toLowerCase()) {                                                   // 23
        if (!RocketChat.checkUsernameAvailability(username)) {                                                         // 24
          throw new Meteor.Error('username-unavailable', username + " is already in use :(");                          // 25
        }                                                                                                              //
      }                                                                                                                //
    } else {                                                                                                           //
      if (!RocketChat.checkUsernameAvailability(username)) {                                                           // 27
        throw new Meteor.Error('username-unavailable', username + " is already in use :(");                            // 28
      }                                                                                                                //
    }                                                                                                                  //
    if (!RocketChat.setUsername(user._id, username)) {                                                                 // 30
      throw new Meteor.Error('could-not-change-username', "Could not change username");                                // 31
    }                                                                                                                  //
    return username;                                                                                                   // 33
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
RocketChat.RateLimiter.limitMethod('setUsername', 1, 1000, {                                                           // 1
  userId: function(userId) {                                                                                           // 36
    return true;                                                                                                       // 36
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/insertOrUpdateUser.coffee.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  insertOrUpdateUser: function(userData) {                                                                             // 2
    var _id, canAddUser, canEditUser, canEditUserPassword, createUser, nameValidation, user;                           // 3
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] updateUser -> Invalid user");                                  // 4
    }                                                                                                                  //
    user = Meteor.user();                                                                                              // 3
    canEditUser = RocketChat.authz.hasPermission(user._id, 'edit-other-user-info');                                    // 3
    canAddUser = RocketChat.authz.hasPermission(user._id, 'add-user');                                                 // 3
    if (userData._id && user._id !== userData._id && canEditUser !== true) {                                           // 11
      throw new Meteor.Error('not-authorized', '[methods] updateUser -> Not authorized');                              // 12
    }                                                                                                                  //
    if (!userData._id && canAddUser !== true) {                                                                        // 14
      throw new Meteor.Error('not-authorized', '[methods] updateUser -> Not authorized');                              // 15
    }                                                                                                                  //
    if (!s.trim(userData.name)) {                                                                                      // 17
      throw new Meteor.Error('name-is-required', 'Name field is required');                                            // 18
    }                                                                                                                  //
    if (!s.trim(userData.username)) {                                                                                  // 20
      throw new Meteor.Error('user-name-is-required', 'Username field is required');                                   // 21
    }                                                                                                                  //
    try {                                                                                                              // 23
      nameValidation = new RegExp('^' + RocketChat.settings.get('UTF8_Names_Validation') + '$');                       // 24
    } catch (_error) {                                                                                                 //
      nameValidation = new RegExp('^[0-9a-zA-Z-_.]+$');                                                                // 26
    }                                                                                                                  //
    if (!nameValidation.test(userData.username)) {                                                                     // 28
      throw new Meteor.Error('username-invalid', username + " is not a valid username");                               // 29
    }                                                                                                                  //
    if (!userData._id && !userData.password) {                                                                         // 31
      throw new Meteor.Error('password-is-required', 'Password is required when adding a user');                       // 32
    }                                                                                                                  //
    if (!userData._id) {                                                                                               // 34
      if (!RocketChat.checkUsernameAvailability(userData.username)) {                                                  // 35
        throw new Meteor.Error('username-unavailable', userData.username + " is already in use :(");                   // 36
      }                                                                                                                //
      if (userData.email && !RocketChat.checkEmailAvailability(userData.email)) {                                      // 38
        throw new Meteor.Error('email-unavailable', userData.email + " is already in use :(");                         // 39
      }                                                                                                                //
      createUser = {                                                                                                   // 35
        username: userData.username,                                                                                   // 42
        password: userData.password                                                                                    // 42
      };                                                                                                               //
      if (userData.email) {                                                                                            // 43
        createUser.email = userData.email;                                                                             // 44
      }                                                                                                                //
      _id = Accounts.createUser(createUser);                                                                           // 35
      if (userData.requirePasswordChange) {                                                                            // 47
        Meteor.users.update({                                                                                          // 48
          _id: _id                                                                                                     // 48
        }, {                                                                                                           //
          $set: {                                                                                                      // 48
            name: userData.name,                                                                                       // 48
            requirePasswordChange: userData.requirePasswordChange                                                      // 48
          }                                                                                                            //
        });                                                                                                            //
      }                                                                                                                //
      return _id;                                                                                                      // 50
    } else {                                                                                                           //
      Meteor.users.update({                                                                                            // 53
        _id: userData._id                                                                                              // 53
      }, {                                                                                                             //
        $set: {                                                                                                        // 53
          name: userData.name,                                                                                         // 53
          requirePasswordChange: userData.requirePasswordChange                                                        // 53
        }                                                                                                              //
      });                                                                                                              //
      Meteor.runAsUser(userData._id, function() {                                                                      // 53
        return Meteor.call('setUsername', userData.username);                                                          //
      });                                                                                                              //
      canEditUserPassword = RocketChat.authz.hasPermission(user._id, 'edit-other-user-password');                      // 53
      if (canEditUserPassword && userData.password.trim()) {                                                           // 59
        Accounts.setPassword(userData._id, userData.password.trim());                                                  // 60
      }                                                                                                                //
      return true;                                                                                                     // 62
    }                                                                                                                  //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/setEmail.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({                                                                                                       // 1
	setEmail: function (email) {                                                                                          // 2
		if (!Meteor.userId()) {                                                                                              // 3
			throw new Meteor.Error('invalid-user', "[methods] setEmail -> Invalid user");                                       // 4
		}                                                                                                                    //
                                                                                                                       //
		user = Meteor.user();                                                                                                // 7
                                                                                                                       //
		if (!RocketChat.settings.get("Accounts_AllowEmailChange")) {                                                         // 9
			throw new Meteor.Error(403, "[methods] setEmail -> E-mail change not allowed");                                     // 10
		}                                                                                                                    //
                                                                                                                       //
		if (user.emails && user.emails[0] && user.emails[0].address === email) {                                             // 13
			return email;                                                                                                       // 14
		}                                                                                                                    //
                                                                                                                       //
		emailValidation = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
		if (!emailValidation.test(email)) {                                                                                  // 18
			throw new Meteor.Error('email-invalid', "#{email} is not a valid e-mail");                                          // 19
		}                                                                                                                    //
                                                                                                                       //
		if (!RocketChat.checkEmailAvailability(email)) {                                                                     // 22
			throw new Meteor.Error('email-unavailable', "#{email} is already in use :(");                                       // 23
		}                                                                                                                    //
                                                                                                                       //
		if (!RocketChat.setEmail(user._id, email)) {                                                                         // 26
			throw new Meteor.Error('could-not-change-email', "Could not change email");                                         // 27
		}                                                                                                                    //
                                                                                                                       //
		return email;                                                                                                        // 30
	}                                                                                                                     //
});                                                                                                                    //
                                                                                                                       //
RocketChat.RateLimiter.limitMethod('setEmail', 1, 1000, {                                                              // 34
	userId: function (userId) {                                                                                           // 35
		return true;                                                                                                         // 35
	}                                                                                                                     //
});                                                                                                                    //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/methods/restartServer.coffee.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                       // 1
  restart_server: function() {                                                                                         // 2
    if (!Meteor.userId()) {                                                                                            // 3
      throw new Meteor.Error('invalid-user', "[methods] restart_server -> Invalid user");                              // 4
    }                                                                                                                  //
    if (RocketChat.authz.hasRole(Meteor.userId(), 'admin') !== true) {                                                 // 6
      throw new Meteor.Error('not-authorized', '[methods] restart_server -> Not authorized');                          // 7
    }                                                                                                                  //
    Meteor.setTimeout(function() {                                                                                     // 3
      return process.exit(1);                                                                                          //
    }, 2000);                                                                                                          //
    return {                                                                                                           // 13
      message: "The_server_will_restart_in_s_seconds",                                                                 // 14
      params: [2]                                                                                                      // 14
    };                                                                                                                 //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/startup/settingsOnLoadCdnPrefix.coffee.js                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.settings.onload('CDN_PREFIX', function(key, value, initialLoad) {                                           // 1
  if (_.isString(value)) {                                                                                             // 2
    return typeof WebAppInternals !== "undefined" && WebAppInternals !== null ? WebAppInternals.setBundledJsCssPrefix(value) : void 0;
  }                                                                                                                    //
});                                                                                                                    // 1
                                                                                                                       //
Meteor.startup(function() {                                                                                            // 1
  var value;                                                                                                           // 6
  value = RocketChat.settings.get('CDN_PREFIX');                                                                       // 6
  if (_.isString(value)) {                                                                                             // 7
    return typeof WebAppInternals !== "undefined" && WebAppInternals !== null ? WebAppInternals.setBundledJsCssPrefix(value) : void 0;
  }                                                                                                                    //
});                                                                                                                    // 5
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/startup/settingsOnLoadSMTP.coffee.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var buildMailURL;                                                                                                      // 1
                                                                                                                       //
buildMailURL = _.debounce(function() {                                                                                 // 1
  console.log('Updating process.env.MAIL_URL');                                                                        // 2
  if (RocketChat.settings.get('SMTP_Host')) {                                                                          // 3
    process.env.MAIL_URL = "smtp://";                                                                                  // 4
    if (RocketChat.settings.get('SMTP_Username') && RocketChat.settings.get('SMTP_Password')) {                        // 5
      process.env.MAIL_URL += encodeURIComponent(RocketChat.settings.get('SMTP_Username')) + ':' + encodeURIComponent(RocketChat.settings.get('SMTP_Password')) + '@';
    }                                                                                                                  //
    process.env.MAIL_URL += encodeURIComponent(RocketChat.settings.get('SMTP_Host'));                                  // 4
    if (RocketChat.settings.get('SMTP_Port')) {                                                                        // 8
      return process.env.MAIL_URL += ':' + parseInt(RocketChat.settings.get('SMTP_Port'));                             //
    }                                                                                                                  //
  }                                                                                                                    //
}, 500);                                                                                                               // 1
                                                                                                                       //
RocketChat.settings.onload('SMTP_Host', function(key, value, initialLoad) {                                            // 1
  if (_.isString(value)) {                                                                                             // 13
    return buildMailURL();                                                                                             //
  }                                                                                                                    //
});                                                                                                                    // 12
                                                                                                                       //
RocketChat.settings.onload('SMTP_Port', function(key, value, initialLoad) {                                            // 1
  return buildMailURL();                                                                                               //
});                                                                                                                    // 16
                                                                                                                       //
RocketChat.settings.onload('SMTP_Username', function(key, value, initialLoad) {                                        // 1
  if (_.isString(value)) {                                                                                             // 20
    return buildMailURL();                                                                                             //
  }                                                                                                                    //
});                                                                                                                    // 19
                                                                                                                       //
RocketChat.settings.onload('SMTP_Password', function(key, value, initialLoad) {                                        // 1
  if (_.isString(value)) {                                                                                             // 24
    return buildMailURL();                                                                                             //
  }                                                                                                                    //
});                                                                                                                    // 23
                                                                                                                       //
Meteor.startup(function() {                                                                                            // 1
  return buildMailURL();                                                                                               //
});                                                                                                                    // 27
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/startup/oAuthServicesUpdate.coffee.js                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var logger, oAuthServicesRemove, oAuthServicesUpdate, timer;                                                           // 1
                                                                                                                       //
logger = new Logger('rocketchat:lib', {                                                                                // 1
  methods: {                                                                                                           // 2
    oauth_updated: {                                                                                                   // 3
      type: 'info'                                                                                                     // 4
    }                                                                                                                  //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
timer = void 0;                                                                                                        // 1
                                                                                                                       //
oAuthServicesUpdate = function() {                                                                                     // 1
  if (timer != null) {                                                                                                 // 8
    Meteor.clearTimeout(timer);                                                                                        // 8
  }                                                                                                                    //
  return timer = Meteor.setTimeout(function() {                                                                        //
    var data, i, len, ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, ref9, results, service, serviceName, services;
    services = RocketChat.models.Settings.find({                                                                       // 11
      _id: /^(Accounts_OAuth_|Accounts_OAuth_Custom_)[a-z_-]+$/i                                                       // 11
    }).fetch();                                                                                                        //
    results = [];                                                                                                      // 12
    for (i = 0, len = services.length; i < len; i++) {                                                                 //
      service = services[i];                                                                                           //
      logger.oauth_updated(service._id);                                                                               // 13
      serviceName = service._id.replace('Accounts_OAuth_', '');                                                        // 13
      if (serviceName === 'Meteor') {                                                                                  // 17
        serviceName = 'meteor-developer';                                                                              // 18
      }                                                                                                                //
      if (/Accounts_OAuth_Custom_/.test(service._id)) {                                                                // 20
        serviceName = service._id.replace('Accounts_OAuth_Custom_', '');                                               // 21
      }                                                                                                                //
      if (service.value === true) {                                                                                    // 23
        data = {                                                                                                       // 24
          clientId: (ref = RocketChat.models.Settings.findOneById(service._id + "_id")) != null ? ref.value : void 0,  // 25
          secret: (ref1 = RocketChat.models.Settings.findOneById(service._id + "_secret")) != null ? ref1.value : void 0
        };                                                                                                             //
        if (/Accounts_OAuth_Custom_/.test(service._id)) {                                                              // 29
          data.custom = true;                                                                                          // 30
          data.serverURL = (ref2 = RocketChat.models.Settings.findOneById(service._id + "_url")) != null ? ref2.value : void 0;
          data.tokenPath = (ref3 = RocketChat.models.Settings.findOneById(service._id + "_token_path")) != null ? ref3.value : void 0;
          data.identityPath = (ref4 = RocketChat.models.Settings.findOneById(service._id + "_identity_path")) != null ? ref4.value : void 0;
          data.authorizePath = (ref5 = RocketChat.models.Settings.findOneById(service._id + "_authorize_path")) != null ? ref5.value : void 0;
          data.buttonLabelText = (ref6 = RocketChat.models.Settings.findOneById(service._id + "_button_label_text")) != null ? ref6.value : void 0;
          data.buttonLabelColor = (ref7 = RocketChat.models.Settings.findOneById(service._id + "_button_label_color")) != null ? ref7.value : void 0;
          data.loginStyle = (ref8 = RocketChat.models.Settings.findOneById(service._id + "_login_style")) != null ? ref8.value : void 0;
          data.buttonColor = (ref9 = RocketChat.models.Settings.findOneById(service._id + "_button_color")) != null ? ref9.value : void 0;
          new CustomOAuth(serviceName.toLowerCase(), {                                                                 // 30
            serverURL: data.serverURL,                                                                                 // 40
            tokenPath: data.tokenPath,                                                                                 // 40
            identityPath: data.identityPath,                                                                           // 40
            authorizePath: data.authorizePath,                                                                         // 40
            loginStyle: data.loginStyle                                                                                // 40
          });                                                                                                          //
        }                                                                                                              //
        if (serviceName === 'Facebook') {                                                                              // 46
          data.appId = data.clientId;                                                                                  // 47
          delete data.clientId;                                                                                        // 47
        }                                                                                                              //
        if (serviceName === 'Twitter') {                                                                               // 50
          data.consumerKey = data.clientId;                                                                            // 51
          delete data.clientId;                                                                                        // 51
        }                                                                                                              //
        results.push(ServiceConfiguration.configurations.upsert({                                                      // 24
          service: serviceName.toLowerCase()                                                                           // 53
        }, {                                                                                                           //
          $set: data                                                                                                   // 53
        }));                                                                                                           //
      } else {                                                                                                         //
        results.push(ServiceConfiguration.configurations.remove({                                                      //
          service: serviceName.toLowerCase()                                                                           // 55
        }));                                                                                                           //
      }                                                                                                                //
    }                                                                                                                  // 12
    return results;                                                                                                    //
  }, 2000);                                                                                                            //
};                                                                                                                     // 7
                                                                                                                       //
oAuthServicesRemove = function(_id) {                                                                                  // 1
  var serviceName;                                                                                                     // 60
  serviceName = _id.replace('Accounts_OAuth_Custom_', '');                                                             // 60
  return ServiceConfiguration.configurations.remove({                                                                  //
    service: serviceName.toLowerCase()                                                                                 // 61
  });                                                                                                                  //
};                                                                                                                     // 59
                                                                                                                       //
RocketChat.models.Settings.find().observe({                                                                            // 1
  added: function(record) {                                                                                            // 65
    if (/^Accounts_OAuth_.+/.test(record._id)) {                                                                       // 66
      return oAuthServicesUpdate();                                                                                    //
    }                                                                                                                  //
  },                                                                                                                   //
  changed: function(record) {                                                                                          // 65
    if (/^Accounts_OAuth_.+/.test(record._id)) {                                                                       // 70
      return oAuthServicesUpdate();                                                                                    //
    }                                                                                                                  //
  },                                                                                                                   //
  removed: function(record) {                                                                                          // 65
    if (/^Accounts_OAuth_Custom.+/.test(record._id)) {                                                                 // 74
      return oAuthServicesRemove(record._id);                                                                          //
    }                                                                                                                  //
  }                                                                                                                    //
});                                                                                                                    //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/server/startup/settings.coffee.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
if (!RocketChat.models.Settings.findOneById('uniqueID')) {                                                             // 2
  RocketChat.models.Settings.createWithIdAndValue('uniqueID', process.env.DEPLOYMENT_ID || Random.id());               // 3
}                                                                                                                      //
                                                                                                                       //
RocketChat.settings.addGroup('Accounts', function() {                                                                  // 2
  this.add('Accounts_AllowUserProfileChange', true, {                                                                  // 6
    type: 'boolean',                                                                                                   // 6
    "public": true                                                                                                     // 6
  });                                                                                                                  //
  this.add('Accounts_AllowUserAvatarChange', true, {                                                                   // 6
    type: 'boolean',                                                                                                   // 7
    "public": true                                                                                                     // 7
  });                                                                                                                  //
  this.add('Accounts_AllowUsernameChange', true, {                                                                     // 6
    type: 'boolean',                                                                                                   // 8
    "public": true                                                                                                     // 8
  });                                                                                                                  //
  this.add('Accounts_AllowEmailChange', true, {                                                                        // 6
    type: 'boolean',                                                                                                   // 9
    "public": true                                                                                                     // 9
  });                                                                                                                  //
  this.add('Accounts_AllowPasswordChange', true, {                                                                     // 6
    type: 'boolean',                                                                                                   // 10
    "public": true                                                                                                     // 10
  });                                                                                                                  //
  this.add('Accounts_RequireNameForSignUp', true, {                                                                    // 6
    type: 'boolean',                                                                                                   // 11
    "public": true                                                                                                     // 11
  });                                                                                                                  //
  this.add('Accounts_LoginExpiration', 90, {                                                                           // 6
    type: 'int',                                                                                                       // 12
    "public": true                                                                                                     // 12
  });                                                                                                                  //
  this.add('Accounts_ShowFormLogin', true, {                                                                           // 6
    type: 'boolean',                                                                                                   // 13
    "public": true                                                                                                     // 13
  });                                                                                                                  //
  this.section('Registration', function() {                                                                            // 6
    this.add('Accounts_EmailVerification', false, {                                                                    // 16
      type: 'boolean',                                                                                                 // 16
      "public": true                                                                                                   // 16
    });                                                                                                                //
    this.add('Accounts_ManuallyApproveNewUsers', false, {                                                              // 16
      type: 'boolean'                                                                                                  // 17
    });                                                                                                                //
    this.add('Accounts_AllowedDomainsList', '', {                                                                      // 16
      type: 'string',                                                                                                  // 18
      "public": true                                                                                                   // 18
    });                                                                                                                //
    this.add('Accounts_RegistrationForm', 'Public', {                                                                  // 16
      type: 'select',                                                                                                  // 19
      "public": true,                                                                                                  // 19
      values: [                                                                                                        // 19
        {                                                                                                              //
          key: 'Public',                                                                                               // 19
          i18nLabel: 'Accounts_RegistrationForm_Public'                                                                // 19
        }, {                                                                                                           //
          key: 'Disabled',                                                                                             // 19
          i18nLabel: 'Accounts_RegistrationForm_Disabled'                                                              // 19
        }, {                                                                                                           //
          key: 'Secret URL',                                                                                           // 19
          i18nLabel: 'Accounts_RegistrationForm_Secret_URL'                                                            // 19
        }                                                                                                              //
      ]                                                                                                                //
    });                                                                                                                //
    this.add('Accounts_RegistrationForm_SecretURL', Random.id(), {                                                     // 16
      type: 'string'                                                                                                   // 20
    });                                                                                                                //
    this.add('Accounts_RegistrationForm_LinkReplacementText', 'New user registration is currently disabled', {         // 16
      type: 'string',                                                                                                  // 21
      "public": true                                                                                                   // 21
    });                                                                                                                //
    this.add('Accounts_Registration_AuthenticationServices_Enabled', true, {                                           // 16
      type: 'boolean',                                                                                                 // 22
      "public": true                                                                                                   // 22
    });                                                                                                                //
    return this.add('Accounts_PasswordReset', true, {                                                                  //
      type: 'boolean',                                                                                                 // 23
      "public": true                                                                                                   // 23
    });                                                                                                                //
  });                                                                                                                  //
  this.section('Avatar', function() {                                                                                  // 6
    this.add('Accounts_AvatarResize', true, {                                                                          // 26
      type: 'boolean'                                                                                                  // 26
    });                                                                                                                //
    this.add('Accounts_AvatarSize', 200, {                                                                             // 26
      type: 'int',                                                                                                     // 27
      enableQuery: {                                                                                                   // 27
        _id: 'Accounts_AvatarResize',                                                                                  // 27
        value: true                                                                                                    // 27
      }                                                                                                                //
    });                                                                                                                //
    this.add('Accounts_AvatarStoreType', 'GridFS', {                                                                   // 26
      type: 'select',                                                                                                  // 28
      values: [                                                                                                        // 28
        {                                                                                                              //
          key: 'GridFS',                                                                                               // 28
          i18nLabel: 'GridFS'                                                                                          // 28
        }, {                                                                                                           //
          key: 'FileSystem',                                                                                           // 28
          i18nLabel: 'FileSystem'                                                                                      // 28
        }                                                                                                              //
      ]                                                                                                                //
    });                                                                                                                //
    return this.add('Accounts_AvatarStorePath', '', {                                                                  //
      type: 'string',                                                                                                  // 29
      enableQuery: {                                                                                                   // 29
        _id: 'Accounts_AvatarStoreType',                                                                               // 29
        value: 'FileSystem'                                                                                            // 29
      }                                                                                                                //
    });                                                                                                                //
  });                                                                                                                  //
  this.section('Facebook', function() {                                                                                // 6
    this.add('Accounts_OAuth_Facebook', false, {                                                                       // 32
      type: 'boolean',                                                                                                 // 32
      "public": true                                                                                                   // 32
    });                                                                                                                //
    this.add('Accounts_OAuth_Facebook_id', '', {                                                                       // 32
      type: 'string',                                                                                                  // 33
      enableQuery: {                                                                                                   // 33
        _id: 'Accounts_OAuth_Facebook',                                                                                // 33
        value: true                                                                                                    // 33
      }                                                                                                                //
    });                                                                                                                //
    return this.add('Accounts_OAuth_Facebook_secret', '', {                                                            //
      type: 'string',                                                                                                  // 34
      enableQuery: {                                                                                                   // 34
        _id: 'Accounts_OAuth_Facebook',                                                                                // 34
        value: true                                                                                                    // 34
      }                                                                                                                //
    });                                                                                                                //
  });                                                                                                                  //
  this.section('Google', function() {                                                                                  // 6
    this.add('Accounts_OAuth_Google', false, {                                                                         // 37
      type: 'boolean',                                                                                                 // 37
      "public": true                                                                                                   // 37
    });                                                                                                                //
    this.add('Accounts_OAuth_Google_id', '', {                                                                         // 37
      type: 'string',                                                                                                  // 38
      enableQuery: {                                                                                                   // 38
        _id: 'Accounts_OAuth_Google',                                                                                  // 38
        value: true                                                                                                    // 38
      }                                                                                                                //
    });                                                                                                                //
    return this.add('Accounts_OAuth_Google_secret', '', {                                                              //
      type: 'string',                                                                                                  // 39
      enableQuery: {                                                                                                   // 39
        _id: 'Accounts_OAuth_Google',                                                                                  // 39
        value: true                                                                                                    // 39
      }                                                                                                                //
    });                                                                                                                //
  });                                                                                                                  //
  this.section('Github', function() {                                                                                  // 6
    this.add('Accounts_OAuth_Github', false, {                                                                         // 42
      type: 'boolean',                                                                                                 // 42
      "public": true                                                                                                   // 42
    });                                                                                                                //
    this.add('Accounts_OAuth_Github_id', '', {                                                                         // 42
      type: 'string',                                                                                                  // 43
      enableQuery: {                                                                                                   // 43
        _id: 'Accounts_OAuth_Github',                                                                                  // 43
        value: true                                                                                                    // 43
      }                                                                                                                //
    });                                                                                                                //
    return this.add('Accounts_OAuth_Github_secret', '', {                                                              //
      type: 'string',                                                                                                  // 44
      enableQuery: {                                                                                                   // 44
        _id: 'Accounts_OAuth_Github',                                                                                  // 44
        value: true                                                                                                    // 44
      }                                                                                                                //
    });                                                                                                                //
  });                                                                                                                  //
  this.section('Gitlab', function() {                                                                                  // 6
    this.add('Accounts_OAuth_Gitlab', false, {                                                                         // 47
      type: 'boolean',                                                                                                 // 47
      "public": true                                                                                                   // 47
    });                                                                                                                //
    this.add('Accounts_OAuth_Gitlab_id', '', {                                                                         // 47
      type: 'string',                                                                                                  // 48
      enableQuery: {                                                                                                   // 48
        _id: 'Accounts_OAuth_Gitlab',                                                                                  // 48
        value: true                                                                                                    // 48
      }                                                                                                                //
    });                                                                                                                //
    return this.add('Accounts_OAuth_Gitlab_secret', '', {                                                              //
      type: 'string',                                                                                                  // 49
      enableQuery: {                                                                                                   // 49
        _id: 'Accounts_OAuth_Gitlab',                                                                                  // 49
        value: true                                                                                                    // 49
      }                                                                                                                //
    });                                                                                                                //
  });                                                                                                                  //
  this.section('Linkedin', function() {                                                                                // 6
    this.add('Accounts_OAuth_Linkedin', false, {                                                                       // 52
      type: 'boolean',                                                                                                 // 52
      "public": true                                                                                                   // 52
    });                                                                                                                //
    this.add('Accounts_OAuth_Linkedin_id', '', {                                                                       // 52
      type: 'string',                                                                                                  // 53
      enableQuery: {                                                                                                   // 53
        _id: 'Accounts_OAuth_Linkedin',                                                                                // 53
        value: true                                                                                                    // 53
      }                                                                                                                //
    });                                                                                                                //
    return this.add('Accounts_OAuth_Linkedin_secret', '', {                                                            //
      type: 'string',                                                                                                  // 54
      enableQuery: {                                                                                                   // 54
        _id: 'Accounts_OAuth_Linkedin',                                                                                // 54
        value: true                                                                                                    // 54
      }                                                                                                                //
    });                                                                                                                //
  });                                                                                                                  //
  this.section('Meteor', function() {                                                                                  // 6
    this.add('Accounts_OAuth_Meteor', false, {                                                                         // 57
      type: 'boolean',                                                                                                 // 57
      "public": true                                                                                                   // 57
    });                                                                                                                //
    this.add('Accounts_OAuth_Meteor_id', '', {                                                                         // 57
      type: 'string',                                                                                                  // 58
      enableQuery: {                                                                                                   // 58
        _id: 'Accounts_OAuth_Meteor',                                                                                  // 58
        value: true                                                                                                    // 58
      }                                                                                                                //
    });                                                                                                                //
    return this.add('Accounts_OAuth_Meteor_secret', '', {                                                              //
      type: 'string',                                                                                                  // 59
      enableQuery: {                                                                                                   // 59
        _id: 'Accounts_OAuth_Meteor',                                                                                  // 59
        value: true                                                                                                    // 59
      }                                                                                                                //
    });                                                                                                                //
  });                                                                                                                  //
  return this.section('Twitter', function() {                                                                          //
    this.add('Accounts_OAuth_Twitter', false, {                                                                        // 62
      type: 'boolean',                                                                                                 // 62
      "public": true                                                                                                   // 62
    });                                                                                                                //
    this.add('Accounts_OAuth_Twitter_id', '', {                                                                        // 62
      type: 'string',                                                                                                  // 63
      enableQuery: {                                                                                                   // 63
        _id: 'Accounts_OAuth_Twitter',                                                                                 // 63
        value: true                                                                                                    // 63
      }                                                                                                                //
    });                                                                                                                //
    return this.add('Accounts_OAuth_Twitter_secret', '', {                                                             //
      type: 'string',                                                                                                  // 64
      enableQuery: {                                                                                                   // 64
        _id: 'Accounts_OAuth_Twitter',                                                                                 // 64
        value: true                                                                                                    // 64
      }                                                                                                                //
    });                                                                                                                //
  });                                                                                                                  //
});                                                                                                                    // 5
                                                                                                                       //
RocketChat.settings.addGroup('FileUpload', function() {                                                                // 2
  this.add('FileUpload_Enabled', true, {                                                                               // 68
    type: 'boolean',                                                                                                   // 68
    "public": true                                                                                                     // 68
  });                                                                                                                  //
  this.add('FileUpload_MaxFileSize', 2097152, {                                                                        // 68
    type: 'int',                                                                                                       // 69
    "public": true                                                                                                     // 69
  });                                                                                                                  //
  this.add('FileUpload_MediaTypeWhiteList', 'image/*,audio/*,application/pdf,text/plain,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document', {
    type: 'string',                                                                                                    // 70
    "public": true,                                                                                                    // 70
    i18nDescription: 'FileUpload_MediaTypeWhiteListDescription'                                                        // 70
  });                                                                                                                  //
  return this.add('FileUpload_ProtectFiles', true, {                                                                   //
    type: 'boolean',                                                                                                   // 71
    "public": true,                                                                                                    // 71
    i18nDescription: 'FileUpload_ProtectFilesDescription'                                                              // 71
  });                                                                                                                  //
});                                                                                                                    // 67
                                                                                                                       //
RocketChat.settings.addGroup('General', function() {                                                                   // 2
  this.add('Site_Url', typeof __meteor_runtime_config__ !== "undefined" && __meteor_runtime_config__ !== null ? __meteor_runtime_config__.ROOT_URL : void 0, {
    type: 'string',                                                                                                    // 75
    i18nDescription: 'Site_Url_Description',                                                                           // 75
    "public": true                                                                                                     // 75
  });                                                                                                                  //
  this.add('Site_Name', 'Rocket.Chat', {                                                                               // 75
    type: 'string',                                                                                                    // 76
    "public": true                                                                                                     // 76
  });                                                                                                                  //
  this.add('Language', '', {                                                                                           // 75
    type: 'language',                                                                                                  // 77
    "public": true                                                                                                     // 77
  });                                                                                                                  //
  this.add('Allow_Invalid_SelfSigned_Certs', false, {                                                                  // 75
    type: 'boolean'                                                                                                    // 78
  });                                                                                                                  //
  this.add('Disable_Favorite_Rooms', false, {                                                                          // 75
    type: 'boolean'                                                                                                    // 79
  });                                                                                                                  //
  this.add('CDN_PREFIX', '', {                                                                                         // 75
    type: 'string'                                                                                                     // 80
  });                                                                                                                  //
  this.add('Force_SSL', false, {                                                                                       // 75
    type: 'boolean',                                                                                                   // 81
    "public": true                                                                                                     // 81
  });                                                                                                                  //
  this.add('Debug_Level', 'error', {                                                                                   // 75
    type: 'select',                                                                                                    // 82
    values: [                                                                                                          // 82
      {                                                                                                                //
        key: 'error',                                                                                                  // 82
        i18nLabel: 'Only_errors'                                                                                       // 82
      }, {                                                                                                             //
        key: 'debug',                                                                                                  // 82
        i18nLabel: 'All_logs'                                                                                          // 82
      }                                                                                                                //
    ]                                                                                                                  //
  });                                                                                                                  //
  this.add('Restart', 'restart_server', {                                                                              // 75
    type: 'action',                                                                                                    // 83
    actionText: 'Restart_the_server'                                                                                   // 83
  });                                                                                                                  //
  this.section('UTF8', function() {                                                                                    // 75
    this.add('UTF8_Names_Validation', '[0-9a-zA-Z-_.]+', {                                                             // 86
      type: 'string',                                                                                                  // 86
      "public": true,                                                                                                  // 86
      i18nDescription: 'UTF8_Names_Validation_Description'                                                             // 86
    });                                                                                                                //
    return this.add('UTF8_Names_Slugify', true, {                                                                      //
      type: 'boolean',                                                                                                 // 87
      "public": true                                                                                                   // 87
    });                                                                                                                //
  });                                                                                                                  //
  return this.section('Reporting', function() {                                                                        //
    return this.add('Statistics_opt_out', false, {                                                                     //
      type: 'boolean',                                                                                                 // 90
      i18nLabel: "Opt_out_statistics"                                                                                  // 90
    });                                                                                                                //
  });                                                                                                                  //
});                                                                                                                    // 74
                                                                                                                       //
RocketChat.settings.addGroup('API', function() {                                                                       // 2
  this.add('API_Analytics', '', {                                                                                      // 93
    type: 'string',                                                                                                    // 93
    "public": true                                                                                                     // 93
  });                                                                                                                  //
  this.add('API_Embed', true, {                                                                                        // 93
    type: 'boolean',                                                                                                   // 94
    "public": true                                                                                                     // 94
  });                                                                                                                  //
  return this.add('API_EmbedDisabledFor', '', {                                                                        //
    type: 'string',                                                                                                    // 95
    "public": true,                                                                                                    // 95
    i18nDescription: 'API_EmbedDisabledFor_Description'                                                                // 95
  });                                                                                                                  //
});                                                                                                                    // 92
                                                                                                                       //
RocketChat.settings.addGroup('SMTP', function() {                                                                      // 2
  this.add('SMTP_Host', '', {                                                                                          // 99
    type: 'string',                                                                                                    // 99
    env: true                                                                                                          // 99
  });                                                                                                                  //
  this.add('SMTP_Port', '', {                                                                                          // 99
    type: 'string',                                                                                                    // 100
    env: true                                                                                                          // 100
  });                                                                                                                  //
  this.add('SMTP_Username', '', {                                                                                      // 99
    type: 'string',                                                                                                    // 101
    env: true                                                                                                          // 101
  });                                                                                                                  //
  this.add('SMTP_Password', '', {                                                                                      // 99
    type: 'string',                                                                                                    // 102
    env: true                                                                                                          // 102
  });                                                                                                                  //
  this.add('From_Email', '', {                                                                                         // 99
    type: 'string',                                                                                                    // 103
    placeholder: 'email@domain'                                                                                        // 103
  });                                                                                                                  //
  this.add('SMTP_Test_Button', 'sendSMTPTestEmail', {                                                                  // 99
    type: 'action',                                                                                                    // 104
    actionText: 'Send_a_test_mail_to_my_user'                                                                          // 104
  });                                                                                                                  //
  return this.section('Invitation', function() {                                                                       //
    this.add('Invitation_Subject', 'You have been invited to Rocket.Chat', {                                           // 107
      type: 'string'                                                                                                   // 107
    });                                                                                                                //
    this.add('Invitation_HTML', '<h2>You have been invited to <h1>Rocket.Chat</h1></h2><p>Go to ' + (typeof __meteor_runtime_config__ !== "undefined" && __meteor_runtime_config__ !== null ? __meteor_runtime_config__.ROOT_URL : void 0) + ' and try the best open source chat solution available today!</p>', {
      type: 'string',                                                                                                  // 108
      multiline: true                                                                                                  // 108
    });                                                                                                                //
    return this.add('Accounts_Enrollment_Email', '', {                                                                 //
      type: 'string',                                                                                                  // 109
      multiline: true                                                                                                  // 109
    });                                                                                                                //
  });                                                                                                                  //
});                                                                                                                    // 98
                                                                                                                       //
RocketChat.settings.addGroup('Message', function() {                                                                   // 2
  this.add('Message_AllowEditing', true, {                                                                             // 113
    type: 'boolean',                                                                                                   // 113
    "public": true                                                                                                     // 113
  });                                                                                                                  //
  this.add('Message_AllowEditing_BlockEditInMinutes', 0, {                                                             // 113
    type: 'int',                                                                                                       // 114
    "public": true,                                                                                                    // 114
    i18nDescription: 'Message_AllowEditing_BlockEditInMinutesDescription'                                              // 114
  });                                                                                                                  //
  this.add('Message_AllowDeleting', true, {                                                                            // 113
    type: 'boolean',                                                                                                   // 115
    "public": true                                                                                                     // 115
  });                                                                                                                  //
  this.add('Message_AllowPinning', true, {                                                                             // 113
    type: 'boolean',                                                                                                   // 116
    "public": true                                                                                                     // 116
  });                                                                                                                  //
  this.add('Message_ShowEditedStatus', true, {                                                                         // 113
    type: 'boolean',                                                                                                   // 117
    "public": true                                                                                                     // 117
  });                                                                                                                  //
  this.add('Message_ShowDeletedStatus', false, {                                                                       // 113
    type: 'boolean',                                                                                                   // 118
    "public": true                                                                                                     // 118
  });                                                                                                                  //
  this.add('Message_KeepHistory', false, {                                                                             // 113
    type: 'boolean',                                                                                                   // 119
    "public": true                                                                                                     // 119
  });                                                                                                                  //
  this.add('Message_MaxAllowedSize', 5000, {                                                                           // 113
    type: 'int',                                                                                                       // 120
    "public": true                                                                                                     // 120
  });                                                                                                                  //
  this.add('Message_ShowFormattingTips', true, {                                                                       // 113
    type: 'boolean',                                                                                                   // 121
    "public": true                                                                                                     // 121
  });                                                                                                                  //
  this.add('Message_AudioRecorderEnabled', true, {                                                                     // 113
    type: 'boolean',                                                                                                   // 122
    "public": true,                                                                                                    // 122
    i18nDescription: 'Message_AudioRecorderEnabledDescription'                                                         // 122
  });                                                                                                                  //
  return this.add('Message_GroupingPeriod', 300, {                                                                     //
    type: 'int',                                                                                                       // 123
    "public": true,                                                                                                    // 123
    i18nDescription: 'Message_GroupingPeriodDescription'                                                               // 123
  });                                                                                                                  //
});                                                                                                                    // 112
                                                                                                                       //
RocketChat.settings.addGroup('Meta', function() {                                                                      // 2
  this.add('Meta_language', '', {                                                                                      // 127
    type: 'string'                                                                                                     // 127
  });                                                                                                                  //
  this.add('Meta_fb_app_id', '', {                                                                                     // 127
    type: 'string'                                                                                                     // 128
  });                                                                                                                  //
  this.add('Meta_robots', '', {                                                                                        // 127
    type: 'string'                                                                                                     // 129
  });                                                                                                                  //
  this.add('Meta_google-site-verification', '', {                                                                      // 127
    type: 'string'                                                                                                     // 130
  });                                                                                                                  //
  return this.add('Meta_msvalidate01', '', {                                                                           //
    type: 'string'                                                                                                     // 131
  });                                                                                                                  //
});                                                                                                                    // 126
                                                                                                                       //
RocketChat.settings.addGroup('Push', function() {                                                                      // 2
  this.add('Push_debug', false, {                                                                                      // 135
    type: 'boolean',                                                                                                   // 135
    "public": true                                                                                                     // 135
  });                                                                                                                  //
  this.add('Push_enable', true, {                                                                                      // 135
    type: 'boolean',                                                                                                   // 136
    "public": true                                                                                                     // 136
  });                                                                                                                  //
  this.add('Push_enable_gateway', true, {                                                                              // 135
    type: 'boolean'                                                                                                    // 137
  });                                                                                                                  //
  this.add('Push_gateway', 'https://rocket.chat', {                                                                    // 135
    type: 'string'                                                                                                     // 138
  });                                                                                                                  //
  this.add('Push_production', true, {                                                                                  // 135
    type: 'boolean',                                                                                                   // 139
    "public": true                                                                                                     // 139
  });                                                                                                                  //
  this.add('Push_test_push', 'push_test', {                                                                            // 135
    type: 'action',                                                                                                    // 140
    actionText: 'Send_a_test_push_to_my_user'                                                                          // 140
  });                                                                                                                  //
  return this.section('Certificates_and_Keys', function() {                                                            //
    this.add('Push_apn_passphrase', '', {                                                                              // 143
      type: 'string'                                                                                                   // 143
    });                                                                                                                //
    this.add('Push_apn_key', '', {                                                                                     // 143
      type: 'string',                                                                                                  // 144
      multiline: true                                                                                                  // 144
    });                                                                                                                //
    this.add('Push_apn_cert', '', {                                                                                    // 143
      type: 'string',                                                                                                  // 145
      multiline: true                                                                                                  // 145
    });                                                                                                                //
    this.add('Push_apn_dev_passphrase', '', {                                                                          // 143
      type: 'string'                                                                                                   // 146
    });                                                                                                                //
    this.add('Push_apn_dev_key', '', {                                                                                 // 143
      type: 'string',                                                                                                  // 147
      multiline: true                                                                                                  // 147
    });                                                                                                                //
    this.add('Push_apn_dev_cert', '', {                                                                                // 143
      type: 'string',                                                                                                  // 148
      multiline: true                                                                                                  // 148
    });                                                                                                                //
    this.add('Push_gcm_api_key', '', {                                                                                 // 143
      type: 'string'                                                                                                   // 149
    });                                                                                                                //
    return this.add('Push_gcm_project_number', '', {                                                                   //
      type: 'string',                                                                                                  // 150
      "public": true                                                                                                   // 150
    });                                                                                                                //
  });                                                                                                                  //
});                                                                                                                    // 134
                                                                                                                       //
RocketChat.settings.addGroup('Layout', function() {                                                                    // 2
  this.add('Layout_Sidenav_Footer', '<div><a href="https://github.com/RocketChat/Rocket.Chat" class="logo" target="_blank"> <img src="/images/logo/logo.svg?v=3" /></a><div class="github-tagline"><span class="octicon octicon-pencil" style="color: #994C00"></span> with <span class="octicon octicon-heart" style="color: red"></span> on <span class="octicon octicon-mark-github"></span></div></div>', {
    type: 'string',                                                                                                    // 154
    "public": true,                                                                                                    // 154
    i18nDescription: 'Layout_Sidenav_Footer_description'                                                               // 154
  });                                                                                                                  //
  this.section('Content', function() {                                                                                 // 154
    this.add('Layout_Home_Title', 'Home', {                                                                            // 157
      type: 'string',                                                                                                  // 157
      "public": true                                                                                                   // 157
    });                                                                                                                //
    this.add('Layout_Home_Body', 'Welcome to Rocket.Chat <br> Go to APP SETTINGS -> Layout to customize this intro.', {
      type: 'string',                                                                                                  // 158
      multiline: true,                                                                                                 // 158
      "public": true                                                                                                   // 158
    });                                                                                                                //
    this.add('Layout_Terms_of_Service', 'Terms of Service <br> Go to APP SETTINGS -> Layout to customize this page.', {
      type: 'string',                                                                                                  // 159
      multiline: true,                                                                                                 // 159
      "public": true                                                                                                   // 159
    });                                                                                                                //
    return this.add('Layout_Privacy_Policy', 'Privacy Policy <br> Go to APP SETTINGS -> Layout to customize this page.', {
      type: 'string',                                                                                                  // 160
      multiline: true,                                                                                                 // 160
      "public": true                                                                                                   // 160
    });                                                                                                                //
  });                                                                                                                  //
  return this.section('Login', function() {                                                                            //
    this.add('Layout_Login_Header', '<a class="logo" href="/"><img src="/images/logo/logo.svg?v=3" /></a>', {          // 163
      type: 'string',                                                                                                  // 163
      multiline: true,                                                                                                 // 163
      "public": true                                                                                                   // 163
    });                                                                                                                //
    return this.add('Layout_Login_Terms', 'By proceeding to create your account and use Rocket.Chat, you are agreeing to our <a href="/terms-of-service">Terms of Service</a> and <a href="/privacy-policy">Privacy Policy</a>. If you do not agree, you cannot use Rocket.Chat.', {
      type: 'string',                                                                                                  // 164
      multiline: true,                                                                                                 // 164
      "public": true                                                                                                   // 164
    });                                                                                                                //
  });                                                                                                                  //
});                                                                                                                    // 153
                                                                                                                       //
RocketChat.settings.addGroup('Logs', function() {                                                                      // 2
  this.add('Log_Level', '0', {                                                                                         // 168
    type: 'select',                                                                                                    // 168
    values: [                                                                                                          // 168
      {                                                                                                                //
        key: '0',                                                                                                      // 168
        i18nLabel: '0_Errors_Only'                                                                                     // 168
      }, {                                                                                                             //
        key: '1',                                                                                                      // 168
        i18nLabel: '1_Errors_and_Information'                                                                          // 168
      }, {                                                                                                             //
        key: '2',                                                                                                      // 168
        i18nLabel: '2_Erros_Information_and_Debug'                                                                     // 168
      }                                                                                                                //
    ],                                                                                                                 //
    "public": true                                                                                                     // 168
  });                                                                                                                  //
  this.add('Log_Package', false, {                                                                                     // 168
    type: 'boolean',                                                                                                   // 169
    "public": true                                                                                                     // 169
  });                                                                                                                  //
  this.add('Log_File', false, {                                                                                        // 168
    type: 'boolean',                                                                                                   // 170
    "public": true                                                                                                     // 170
  });                                                                                                                  //
  return this.add('Log_View_Limit', 1000, {                                                                            //
    type: 'int'                                                                                                        // 171
  });                                                                                                                  //
});                                                                                                                    // 167
                                                                                                                       //
RocketChat.settings.init();                                                                                            // 2
                                                                                                                       //
Meteor.startup(function() {                                                                                            // 2
  RocketChat.models.Settings.update({                                                                                  // 178
    ts: {                                                                                                              // 178
      $lt: RocketChat.settings.ts                                                                                      // 178
    },                                                                                                                 //
    persistent: {                                                                                                      // 178
      $ne: true                                                                                                        // 178
    }                                                                                                                  //
  }, {                                                                                                                 //
    $set: {                                                                                                            // 178
      hidden: true                                                                                                     // 178
    }                                                                                                                  //
  }, {                                                                                                                 //
    multi: true                                                                                                        // 178
  });                                                                                                                  //
  return RocketChat.models.Settings.update({                                                                           //
    ts: {                                                                                                              // 179
      $gte: RocketChat.settings.ts                                                                                     // 179
    }                                                                                                                  //
  }, {                                                                                                                 //
    $unset: {                                                                                                          // 179
      hidden: 1                                                                                                        // 179
    }                                                                                                                  //
  }, {                                                                                                                 //
    multi: true                                                                                                        // 179
  });                                                                                                                  //
});                                                                                                                    // 177
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/lib/startup/settingsOnLoadSiteUrl.coffee.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.settings.onload('Site_Url', function(key, value, initialLoad) {                                             // 1
  var ref;                                                                                                             // 2
  if ((value != null ? value.trim() : void 0) !== '') {                                                                // 2
    __meteor_runtime_config__.ROOT_URL = value;                                                                        // 3
    if (((ref = Meteor.absoluteUrl.defaultOptions) != null ? ref.rootUrl : void 0) != null) {                          // 4
      return Meteor.absoluteUrl.defaultOptions.rootUrl = value;                                                        //
    }                                                                                                                  //
  }                                                                                                                    //
});                                                                                                                    // 1
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/ar.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["ar"] = ["Arabic","العربية"];                                                                  // 8
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];                                                                 // 10
if(_.isUndefined(TAPi18n.translations["ar"])) {                                                                        // 11
  TAPi18n.translations["ar"] = {};                                                                                     // 12
}                                                                                                                      // 13
                                                                                                                       // 14
if(_.isUndefined(TAPi18n.translations["ar"][namespace])) {                                                             // 15
  TAPi18n.translations["ar"][namespace] = {};                                                                          // 16
}                                                                                                                      // 17
                                                                                                                       // 18
_.extend(TAPi18n.translations["ar"][namespace], {"All_logs":"كل السجلات","Delete":"حذف","Edit":"تعديل"});              // 19
TAPi18n._registerServerTranslator("ar", namespace);                                                                    // 20
                                                                                                                       // 21
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/de.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["de"] = ["German","Deutsch"];                                                                  // 8
if(_.isUndefined(TAPi18n.translations["de"])) {                                                                        // 9
  TAPi18n.translations["de"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["de"][namespace])) {                                                             // 13
  TAPi18n.translations["de"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["de"][namespace], {"All_logs":"Alle Protokolle","Debug_Level":"Debug-Level","Delete":"Löschen","Edit":"Bearbeiten","Only_errors":"Nur Fehler"});
TAPi18n._registerServerTranslator("de", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/en.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
// integrate the fallback language translations                                                                        // 8
translations = {};                                                                                                     // 9
translations[namespace] = {"All_logs":"All logs","Debug_Level":"Debug Level","Delete":"Delete","Edit":"Edit","Only_errors":"Only errors"};
TAPi18n._loadLangFileObject("en", translations);                                                                       // 11
TAPi18n._registerServerTranslator("en", namespace);                                                                    // 12
                                                                                                                       // 13
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/fi.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["fi"] = ["Finnish","Suomi"];                                                                   // 8
if(_.isUndefined(TAPi18n.translations["fi"])) {                                                                        // 9
  TAPi18n.translations["fi"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["fi"][namespace])) {                                                             // 13
  TAPi18n.translations["fi"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["fi"][namespace], {"All_logs":"Kaikki lokit","Debug_Level":"Debug-taso","Delete":"Poista","Edit":"Muokkaa","Only_errors":"Vain virheet"});
TAPi18n._registerServerTranslator("fi", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/fr.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["fr"] = ["French (France)","Français"];                                                        // 8
if(_.isUndefined(TAPi18n.translations["fr"])) {                                                                        // 9
  TAPi18n.translations["fr"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["fr"][namespace])) {                                                             // 13
  TAPi18n.translations["fr"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["fr"][namespace], {"All_logs":"Tous les journaux","Delete":"Supprimer","Edit":"Modifier","Only_errors":"Seules les erreurs"});
TAPi18n._registerServerTranslator("fr", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/he.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["he"] = ["Hebrew","עברית"];                                                                    // 8
if(_.isUndefined(TAPi18n.translations["he"])) {                                                                        // 9
  TAPi18n.translations["he"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["he"][namespace])) {                                                             // 13
  TAPi18n.translations["he"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["he"][namespace], {"All_logs":"כל היומנים","Debug_Level":"רמת פירוט","Delete":"מחיקה","Only_errors":"שגיאות בלבד"});
TAPi18n._registerServerTranslator("he", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/hr.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["hr"] = ["Croatian","Hrvatski"];                                                               // 8
if(_.isUndefined(TAPi18n.translations["hr"])) {                                                                        // 9
  TAPi18n.translations["hr"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["hr"][namespace])) {                                                             // 13
  TAPi18n.translations["hr"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["hr"][namespace], {"Delete":"Obriši","Edit":"Uredi"});                                   // 17
TAPi18n._registerServerTranslator("hr", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/km.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["km"] = ["Khmer","ភាសាខ្មែរ"];                                                                 // 8
if(_.isUndefined(TAPi18n.translations["km"])) {                                                                        // 9
  TAPi18n.translations["km"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["km"][namespace])) {                                                             // 13
  TAPi18n.translations["km"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["km"][namespace], {"Delete":"លុប","Edit":"កែ​សម្រួល"});                                  // 17
TAPi18n._registerServerTranslator("km", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/ko.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["ko"] = ["Korean","한국어"];                                                                      // 8
if(_.isUndefined(TAPi18n.translations["ko"])) {                                                                        // 9
  TAPi18n.translations["ko"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["ko"][namespace])) {                                                             // 13
  TAPi18n.translations["ko"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["ko"][namespace], {"Delete":"삭제","Edit":"수정"});                                          // 17
TAPi18n._registerServerTranslator("ko", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/ms-MY.i18n.js                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["ms-MY"] = ["ms-MY","ms-MY"];                                                                  // 8
if(_.isUndefined(TAPi18n.translations["ms-MY"])) {                                                                     // 9
  TAPi18n.translations["ms-MY"] = {};                                                                                  // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["ms-MY"][namespace])) {                                                          // 13
  TAPi18n.translations["ms-MY"][namespace] = {};                                                                       // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["ms-MY"][namespace], {"Delete":"Padam","Edit":"Sunting"});                               // 17
TAPi18n._registerServerTranslator("ms-MY", namespace);                                                                 // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/nl.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["nl"] = ["Dutch","Nederlands"];                                                                // 8
if(_.isUndefined(TAPi18n.translations["nl"])) {                                                                        // 9
  TAPi18n.translations["nl"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["nl"][namespace])) {                                                             // 13
  TAPi18n.translations["nl"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["nl"][namespace], {"All_logs":"Alle logs","Debug_Level":"Debug Nivo","Delete":"Verwijder","Edit":"Wijzig","Only_errors":"Alleen fouten"});
TAPi18n._registerServerTranslator("nl", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/pl.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["pl"] = ["Polish","Polski"];                                                                   // 8
if(_.isUndefined(TAPi18n.translations["pl"])) {                                                                        // 9
  TAPi18n.translations["pl"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["pl"][namespace])) {                                                             // 13
  TAPi18n.translations["pl"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["pl"][namespace], {"Delete":"Usuń","Edit":"Edycja"});                                    // 17
TAPi18n._registerServerTranslator("pl", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/pt.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["pt"] = ["Portuguese (Portugal)","Português"];                                                 // 8
if(_.isUndefined(TAPi18n.translations["pt"])) {                                                                        // 9
  TAPi18n.translations["pt"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["pt"][namespace])) {                                                             // 13
  TAPi18n.translations["pt"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["pt"][namespace], {"Delete":"Deletar","Edit":"Editar"});                                 // 17
TAPi18n._registerServerTranslator("pt", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/ro.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["ro"] = ["Romanian","Română"];                                                                 // 8
if(_.isUndefined(TAPi18n.translations["ro"])) {                                                                        // 9
  TAPi18n.translations["ro"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["ro"][namespace])) {                                                             // 13
  TAPi18n.translations["ro"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["ro"][namespace], {"All_logs":"Toate înregistrările","Debug_Level":"Debug Level","Delete":"Șterge","Edit":"Editează","Only_errors":"Doar erori"});
TAPi18n._registerServerTranslator("ro", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/ru.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["ru"] = ["Russian","Русский"];                                                                 // 8
if(_.isUndefined(TAPi18n.translations["ru"])) {                                                                        // 9
  TAPi18n.translations["ru"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["ru"][namespace])) {                                                             // 13
  TAPi18n.translations["ru"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["ru"][namespace], {"Delete":"Удалить","Edit":"Редактировать"});                          // 17
TAPi18n._registerServerTranslator("ru", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/tr.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["tr"] = ["Turkish","Türkçe"];                                                                  // 8
if(_.isUndefined(TAPi18n.translations["tr"])) {                                                                        // 9
  TAPi18n.translations["tr"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["tr"][namespace])) {                                                             // 13
  TAPi18n.translations["tr"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["tr"][namespace], {"Delete":"Sil","Edit":"Düzenle"});                                    // 17
TAPi18n._registerServerTranslator("tr", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/rocketchat_lib/packages/rocketchat_libi18n/zh.i18n.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _ = Package.underscore._,                                                                                          // 1
    package_name = "project",                                                                                          // 2
    namespace = "project";                                                                                             // 3
                                                                                                                       // 4
if (package_name != "project") {                                                                                       // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                              // 6
}                                                                                                                      // 7
TAPi18n.languages_names["zh"] = ["Chinese","中文"];                                                                      // 8
if(_.isUndefined(TAPi18n.translations["zh"])) {                                                                        // 9
  TAPi18n.translations["zh"] = {};                                                                                     // 10
}                                                                                                                      // 11
                                                                                                                       // 12
if(_.isUndefined(TAPi18n.translations["zh"][namespace])) {                                                             // 13
  TAPi18n.translations["zh"][namespace] = {};                                                                          // 14
}                                                                                                                      // 15
                                                                                                                       // 16
_.extend(TAPi18n.translations["zh"][namespace], {"Delete":"删除","Edit":"编辑"});                                          // 17
TAPi18n._registerServerTranslator("zh", namespace);                                                                    // 18
                                                                                                                       // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:lib'] = {
  RocketChat: RocketChat
};

})();

//# sourceMappingURL=rocketchat_lib.js.map
