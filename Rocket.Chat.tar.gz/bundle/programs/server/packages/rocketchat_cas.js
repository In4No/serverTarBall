(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var RoutePolicy = Package.routepolicy.RoutePolicy;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var _ = Package.underscore._;

/* Package-scope variables */
var timer, data, middleware;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// packages/rocketchat_cas/cas_rocketchat.js                                                 //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
Meteor.startup(function(){                                                                   // 1
    RocketChat.settings.addGroup('CAS', function() {                                         // 2
        this.add("CAS_enabled", false, { type: 'boolean', group: 'CAS'});                    // 3
        this.add("CAS_base_url" , '' , { type: 'string' , group: 'CAS' });                   // 4
        this.add("CAS_login_url" , '' , { type: 'string' , group: 'CAS' });                  // 5
                                                                                             // 6
        this.section('CAS Login Layout', function() {                                        // 7
            this.add("CAS_popup_width" , '810' , { type: 'string' , group: 'CAS'});          // 8
            this.add("CAS_popup_height" , '610' , { type: 'string' , group: 'CAS'});         // 9
            this.add("CAS_button_label_text" , 'CAS' , { type: 'string' , group: 'CAS'});    // 10
            this.add("CAS_button_label_color", '#FFFFFF' , { type: 'color' , group: 'CAS'});
            this.add("CAS_button_color" , '#13679A' , { type: 'color' , group: 'CAS'});      // 12
            this.add("CAS_autoclose", true , { type: 'boolean' , group: 'CAS'});             // 13
        });                                                                                  // 14
    });                                                                                      // 15
});                                                                                          // 16
                                                                                             // 17
timer = undefined                                                                            // 18
                                                                                             // 19
function updateServices(record) {                                                            // 20
    if( typeof timer != 'undefined' ) {                                                      // 21
        Meteor.clearTimeout(timer);                                                          // 22
    }                                                                                        // 23
                                                                                             // 24
    timer = Meteor.setTimeout(function() {                                                   // 25
        console.log("Updating login service CAS".blue)                                       // 26
        data = {                                                                             // 27
            // These will pe passed to 'node-cas' as options                                 // 28
            enabled:          RocketChat.settings.get("CAS_enabled"),                        // 29
            base_url:         RocketChat.settings.get("CAS_base_url"),                       // 30
            login_url:        RocketChat.settings.get("CAS_login_url"),                      // 31
            // Rocketchat Visuals                                                            // 32
            buttonLabelText:  RocketChat.settings.get("CAS_button_label_text"),              // 33
            buttonLabelColor: RocketChat.settings.get("CAS_button_label_color"),             // 34
            buttonColor:      RocketChat.settings.get("CAS_button_color"),                   // 35
            width:            RocketChat.settings.get("CAS_popup_width"),                    // 36
            height:           RocketChat.settings.get("CAS_popup_height"),                   // 37
            autoclose:        RocketChat.settings.get("CAS_autoclose"),                      // 38
        };                                                                                   // 39
                                                                                             // 40
        // Either register or deregister the CAS login service based upon its configuration  // 41
        if( data.enabled ) {                                                                 // 42
            ServiceConfiguration.configurations.upsert({service: 'cas'}, { $set: data });    // 43
            // Export needed settings for meteor-accounts-cas here                           // 44
            Meteor.settings.public.cas = { loginUrl: data.login_url };                       // 45
            Meteor.settings.cas = { baseUrl: data.base_url };                                // 46
        } else {                                                                             // 47
            ServiceConfiguration.configurations.remove({service: 'cas'});                    // 48
            Meteor.settings.public.cas = {};                                                 // 49
            Meteor.settings.cas = {};                                                        // 50
        }                                                                                    // 51
    }, 2000);                                                                                // 52
};                                                                                           // 53
                                                                                             // 54
function check_record (record) {                                                             // 55
    if( /^CAS_.+/.test( record._id )){                                                       // 56
        updateServices( record );                                                            // 57
    }                                                                                        // 58
};                                                                                           // 59
                                                                                             // 60
RocketChat.models.Settings.find().observe({                                                  // 61
    added: check_record,                                                                     // 62
    changed: check_record,                                                                   // 63
    removed: check_record                                                                    // 64
});                                                                                          // 65
                                                                                             // 66
///////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// packages/rocketchat_cas/cas_server.js                                                     //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
var Fiber = Npm.require('fibers');                                                           // 1
var url = Npm.require('url');                                                                // 2
var CAS = Npm.require('cas');                                                                // 3
                                                                                             // 4
var _casCredentialTokens = {};                                                               // 5
                                                                                             // 6
RoutePolicy.declare('/_cas/', 'network');                                                    // 7
                                                                                             // 8
// Listen to incoming OAuth http requests                                                    // 9
WebApp.connectHandlers.use(function(req, res, next) {                                        // 10
  // Need to create a Fiber since we're using synchronous http calls and nothing             // 11
  // else is wrapping this in a fiber automatically                                          // 12
  Fiber(function () {                                                                        // 13
    middleware(req, res, next);                                                              // 14
  }).run();                                                                                  // 15
});                                                                                          // 16
                                                                                             // 17
middleware = function (req, res, next) {                                                     // 18
  // Make sure to catch any exceptions because otherwise we'd crash                          // 19
  // the runner                                                                              // 20
  try {                                                                                      // 21
    var barePath = req.url.substring(0, req.url.indexOf('?'));                               // 22
    var splitPath = barePath.split('/');                                                     // 23
                                                                                             // 24
    // Any non-cas request will continue down the default                                    // 25
    // middlewares.                                                                          // 26
    if (splitPath[1] !== '_cas') {                                                           // 27
      next();                                                                                // 28
      return;                                                                                // 29
    }                                                                                        // 30
                                                                                             // 31
    // get auth token                                                                        // 32
    var credentialToken = splitPath[2];                                                      // 33
    if (!credentialToken) {                                                                  // 34
      closePopup(res);                                                                       // 35
      return;                                                                                // 36
    }                                                                                        // 37
                                                                                             // 38
    // validate ticket                                                                       // 39
    casTicket(req, credentialToken, function() {                                             // 40
      closePopup(res);                                                                       // 41
    });                                                                                      // 42
                                                                                             // 43
  } catch (err) {                                                                            // 44
    console.log("account-cas: unexpected error : " + err.message);                           // 45
    closePopup(res);                                                                         // 46
  }                                                                                          // 47
};                                                                                           // 48
                                                                                             // 49
var casTicket = function (req, token, callback) {                                            // 50
  // get configuration                                                                       // 51
  if (!Meteor.settings.cas && !Meteor.settings.cas.validate) {                               // 52
    console.log("accounts-cas: unable to get configuration");                                // 53
    callback();                                                                              // 54
  }                                                                                          // 55
                                                                                             // 56
  // get ticket and validate.                                                                // 57
  var parsedUrl = url.parse(req.url, true);                                                  // 58
  var ticketId = parsedUrl.query.ticket;                                                     // 59
  var baseUrl = Meteor.settings.cas.baseUrl;                                                 // 60
                                                                                             // 61
  var cas = new CAS({                                                                        // 62
    base_url: Meteor.settings.cas.baseUrl,                                                   // 63
    service: Meteor.absoluteUrl() + "_cas/" + token                                          // 64
  });                                                                                        // 65
                                                                                             // 66
  cas.validate(ticketId, function(err, status, username) {                                   // 67
    if (err) {                                                                               // 68
      console.log("accounts-cas: error when trying to validate " + err);                     // 69
    } else {                                                                                 // 70
      if (status) {                                                                          // 71
        console.log("accounts-cas: user validated " + username);                             // 72
        _casCredentialTokens[token] = { id: username };                                      // 73
      } else {                                                                               // 74
        console.log("accounts-cas: unable to validate " + ticketId);                         // 75
      }                                                                                      // 76
    }                                                                                        // 77
                                                                                             // 78
    callback();                                                                              // 79
  });                                                                                        // 80
  console.log("Validated: " + ticketId);                                                     // 81
                                                                                             // 82
  return;                                                                                    // 83
};                                                                                           // 84
                                                                                             // 85
/*                                                                                           // 86
 * Register a server-side login handle.                                                      // 87
 * It is call after Accounts.callLoginMethod() is call from client.                          // 88
 *                                                                                           // 89
 */                                                                                          // 90
 Accounts.registerLoginHandler(function (options) {                                          // 91
                                                                                             // 92
  if (!options.cas)                                                                          // 93
    return undefined;                                                                        // 94
                                                                                             // 95
  if (!_hasCredential(options.cas.credentialToken)) {                                        // 96
    throw new Meteor.Error(Accounts.LoginCancelledError.numericError,                        // 97
      'no matching login attempt found');                                                    // 98
  }                                                                                          // 99
                                                                                             // 100
  var result = _retrieveCredential(options.cas.credentialToken);                             // 101
  var options = { profile: { name: result.id } };                                            // 102
  //var user = Accounts.updateOrCreateUserFromExternalService("cas", result, options);       // 103
                                                                                             // 104
  var user = Meteor.users.findOne({ 'username': result.id });                                // 105
                                                                                             // 106
  if (!user) {                                                                               // 107
	var newUser = {                                                                             // 108
		username: result.id,                                                                       // 109
		active: true,                                                                              // 110
		globalRoles: ['user'],                                                                     // 111
	};                                                                                          // 112
                                                                                             // 113
	var userId = Accounts.insertUserDoc({}, newUser);                                           // 114
	user = Meteor.users.findOne(userId);                                                        // 115
  }                                                                                          // 116
                                                                                             // 117
  console.log("Using user: " + user._id);                                                    // 118
                                                                                             // 119
  return { userId: user._id };                                                               // 120
});                                                                                          // 121
                                                                                             // 122
var _hasCredential = function(credentialToken) {                                             // 123
  return _.has(_casCredentialTokens, credentialToken);                                       // 124
}                                                                                            // 125
                                                                                             // 126
/*                                                                                           // 127
 * Retrieve token and delete it to avoid replaying it.                                       // 128
 */                                                                                          // 129
var _retrieveCredential = function(credentialToken) {                                        // 130
  var result = _casCredentialTokens[credentialToken];                                        // 131
  delete _casCredentialTokens[credentialToken];                                              // 132
  return result;                                                                             // 133
}                                                                                            // 134
                                                                                             // 135
var closePopup = function(res) {                                                             // 136
  res.writeHead(200, {'Content-Type': 'text/html'});                                         // 137
  var content = '<html><head><script>window.close()</script></head></html>';                 // 138
  res.end(content, 'utf-8');                                                                 // 139
}                                                                                            // 140
                                                                                             // 141
///////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:cas'] = {};

})();

//# sourceMappingURL=rocketchat_cas.js.map
