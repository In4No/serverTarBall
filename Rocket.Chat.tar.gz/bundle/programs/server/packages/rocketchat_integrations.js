(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var hljs = Package['simple:highlight.js'].hljs;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

/* Package-scope variables */
var __coffeescriptShare;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/lib/rocketchat.coffee.js                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.integrations = {};                                                                                        // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/client/stylesheets/load.coffee.js                                                //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
RocketChat.theme.addPackageAsset(function() {                                                                        // 1
  return Assets.getText('client/stylesheets/integrations.less');                                                     // 2
});                                                                                                                  // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/models/Integrations.coffee.js                                             //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                       //
                                                                                                                     //
RocketChat.models.Integrations = new ((function(superClass) {                                                        // 1
  extend(_Class, superClass);                                                                                        // 2
                                                                                                                     //
  function _Class() {                                                                                                // 2
    this._initModel('integrations');                                                                                 // 3
  }                                                                                                                  //
                                                                                                                     //
  return _Class;                                                                                                     //
                                                                                                                     //
})(RocketChat.models._Base));                                                                                        //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/publications/integrations.coffee.js                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('integrations', function() {                                                                          // 1
  if (!this.userId) {                                                                                                // 2
    return this.ready();                                                                                             // 3
  }                                                                                                                  //
  if (!RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) {                                         // 5
    throw new Meteor.Error("not-authorized");                                                                        // 6
  }                                                                                                                  //
  return RocketChat.models.Integrations.find();                                                                      // 8
});                                                                                                                  // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/incoming/addIncomingIntegration.coffee.js                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  addIncomingIntegration: function(integration) {                                                                    // 2
    var channel, channelType, hashStampedToken, record, ref, stampedToken, updateObj, user;                          // 3
    if (!RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) {                                       // 3
      throw new Meteor.Error('not_authorized');                                                                      // 4
    }                                                                                                                //
    if (!_.isString(integration.channel)) {                                                                          // 6
      throw new Meteor.Error('invalid_channel', '[methods] addIncomingIntegration -> channel must be string');       // 7
    }                                                                                                                //
    if (integration.channel.trim() === '') {                                                                         // 9
      throw new Meteor.Error('invalid_channel', '[methods] addIncomingIntegration -> channel can\'t be empty');      // 10
    }                                                                                                                //
    if ((ref = integration.channel[0]) !== '@' && ref !== '#') {                                                     // 12
      throw new Meteor.Error('invalid_channel', '[methods] addIncomingIntegration -> channel should start with # or @');
    }                                                                                                                //
    if (!_.isString(integration.username)) {                                                                         // 15
      throw new Meteor.Error('invalid_username', '[methods] addIncomingIntegration -> username must be string');     // 16
    }                                                                                                                //
    if (integration.username.trim() === '') {                                                                        // 18
      throw new Meteor.Error('invalid_username', '[methods] addIncomingIntegration -> username can\'t be empty');    // 19
    }                                                                                                                //
    record = void 0;                                                                                                 // 3
    channelType = integration.channel[0];                                                                            // 3
    channel = integration.channel.substr(1);                                                                         // 3
    switch (channelType) {                                                                                           // 25
      case '#':                                                                                                      // 25
        record = RocketChat.models.Rooms.findOne({                                                                   // 27
          $or: [                                                                                                     // 28
            {                                                                                                        //
              _id: channel                                                                                           // 29
            }, {                                                                                                     //
              name: channel                                                                                          // 30
            }                                                                                                        //
          ]                                                                                                          //
        });                                                                                                          //
        break;                                                                                                       // 26
      case '@':                                                                                                      // 25
        record = RocketChat.models.Users.findOne({                                                                   // 33
          $or: [                                                                                                     // 34
            {                                                                                                        //
              _id: channel                                                                                           // 35
            }, {                                                                                                     //
              username: channel                                                                                      // 36
            }                                                                                                        //
          ]                                                                                                          //
        });                                                                                                          //
    }                                                                                                                // 25
    if (record === void 0) {                                                                                         // 39
      throw new Meteor.Error('channel_does_not_exists', "[methods] addIncomingIntegration -> The channel does not exists");
    }                                                                                                                //
    user = RocketChat.models.Users.findOne({                                                                         // 3
      username: integration.username                                                                                 // 42
    });                                                                                                              //
    if (user == null) {                                                                                              // 44
      throw new Meteor.Error('user_does_not_exists', "[methods] addIncomingIntegration -> The username does not exists");
    }                                                                                                                //
    stampedToken = Accounts._generateStampedLoginToken();                                                            // 3
    hashStampedToken = Accounts._hashStampedToken(stampedToken);                                                     // 3
    updateObj = {                                                                                                    // 3
      $push: {                                                                                                       // 51
        'services.resume.loginTokens': {                                                                             // 52
          hashedToken: hashStampedToken.hashedToken,                                                                 // 53
          integration: true                                                                                          // 53
        }                                                                                                            //
      }                                                                                                              //
    };                                                                                                               //
    integration.type = 'webhook-incoming';                                                                           // 3
    integration.token = hashStampedToken.hashedToken;                                                                // 3
    integration.userId = user._id;                                                                                   // 3
    integration._createdAt = new Date;                                                                               // 3
    integration._createdBy = RocketChat.models.Users.findOne(this.userId, {                                          // 3
      fields: {                                                                                                      // 60
        username: 1                                                                                                  // 60
      }                                                                                                              //
    });                                                                                                              //
    RocketChat.models.Users.update({                                                                                 // 3
      _id: user._id                                                                                                  // 62
    }, updateObj);                                                                                                   //
    RocketChat.models.Roles.addUserRoles(user._id, 'bot');                                                           // 3
    integration._id = RocketChat.models.Integrations.insert(integration);                                            // 3
    return integration;                                                                                              // 68
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/incoming/updateIncomingIntegration.coffee.js                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  updateIncomingIntegration: function(integrationId, integration) {                                                  // 2
    var channel, channelType, currentIntegration, record, ref, user;                                                 // 3
    if (!RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) {                                       // 3
      throw new Meteor.Error('not_authorized');                                                                      // 4
    }                                                                                                                //
    if (!_.isString(integration.channel)) {                                                                          // 6
      throw new Meteor.Error('invalid_channel', '[methods] updateIncomingIntegration -> channel must be string');    // 7
    }                                                                                                                //
    if (integration.channel.trim() === '') {                                                                         // 9
      throw new Meteor.Error('invalid_channel', '[methods] updateIncomingIntegration -> channel can\'t be empty');   // 10
    }                                                                                                                //
    if ((ref = integration.channel[0]) !== '@' && ref !== '#') {                                                     // 12
      throw new Meteor.Error('invalid_channel', '[methods] updateIncomingIntegration -> channel should start with # or @');
    }                                                                                                                //
    currentIntegration = RocketChat.models.Integrations.findOne(integrationId);                                      // 3
    if (currentIntegration == null) {                                                                                // 16
      throw new Meteor.Error('invalid_integration', '[methods] updateIncomingIntegration -> integration not found');
    }                                                                                                                //
    record = void 0;                                                                                                 // 3
    channelType = integration.channel[0];                                                                            // 3
    channel = integration.channel.substr(1);                                                                         // 3
    switch (channelType) {                                                                                           // 23
      case '#':                                                                                                      // 23
        record = RocketChat.models.Rooms.findOne({                                                                   // 25
          $or: [                                                                                                     // 26
            {                                                                                                        //
              _id: channel                                                                                           // 27
            }, {                                                                                                     //
              name: channel                                                                                          // 28
            }                                                                                                        //
          ]                                                                                                          //
        });                                                                                                          //
        break;                                                                                                       // 24
      case '@':                                                                                                      // 23
        record = RocketChat.models.Users.findOne({                                                                   // 31
          $or: [                                                                                                     // 32
            {                                                                                                        //
              _id: channel                                                                                           // 33
            }, {                                                                                                     //
              username: channel                                                                                      // 34
            }                                                                                                        //
          ]                                                                                                          //
        });                                                                                                          //
    }                                                                                                                // 23
    if (record === void 0) {                                                                                         // 37
      throw new Meteor.Error('channel_does_not_exists', "[methods] updateIncomingIntegration -> The channel does not exists");
    }                                                                                                                //
    user = RocketChat.models.Users.findOne({                                                                         // 3
      username: currentIntegration.username                                                                          // 40
    });                                                                                                              //
    RocketChat.models.Roles.addUserRoles(user._id, 'bot');                                                           // 3
    RocketChat.models.Integrations.update(integrationId, {                                                           // 3
      $set: {                                                                                                        // 44
        name: integration.name,                                                                                      // 45
        avatar: integration.avatar,                                                                                  // 45
        emoji: integration.emoji,                                                                                    // 45
        alias: integration.alias,                                                                                    // 45
        channel: integration.channel,                                                                                // 45
        _updatedAt: new Date,                                                                                        // 45
        _updatedBy: RocketChat.models.Users.findOne(this.userId, {                                                   // 45
          fields: {                                                                                                  // 51
            username: 1                                                                                              // 51
          }                                                                                                          //
        })                                                                                                           //
      }                                                                                                              //
    });                                                                                                              //
    return RocketChat.models.Integrations.findOne(integrationId);                                                    // 53
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/incoming/deleteIncomingIntegration.coffee.js                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  deleteIncomingIntegration: function(integrationId) {                                                               // 2
    var integration, updateObj;                                                                                      // 3
    if (!RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) {                                       // 3
      throw new Meteor.Error('not_authorized');                                                                      // 4
    }                                                                                                                //
    integration = RocketChat.models.Integrations.findOne(integrationId);                                             // 3
    if (integration == null) {                                                                                       // 8
      throw new Meteor.Error('invalid_integration', '[methods] deleteIncomingIntegration -> integration not found');
    }                                                                                                                //
    updateObj = {                                                                                                    // 3
      $pull: {                                                                                                       // 12
        'services.resume.loginTokens': {                                                                             // 13
          hashedToken: integration.token,                                                                            // 14
          integration: true                                                                                          // 14
        }                                                                                                            //
      }                                                                                                              //
    };                                                                                                               //
    RocketChat.models.Users.update({                                                                                 // 3
      _id: integration.userId                                                                                        // 17
    }, updateObj);                                                                                                   //
    RocketChat.models.Integrations.remove({                                                                          // 3
      _id: integrationId                                                                                             // 19
    });                                                                                                              //
    return true;                                                                                                     // 21
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/outgoing/addOutgoingIntegration.coffee.js                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  addOutgoingIntegration: function(integration) {                                                                    // 2
    var channel, channelType, i, index, j, len, len1, record, ref, ref1, ref2, ref3, triggerWord, url, user;         // 3
    if ((((ref = integration.channel) != null ? ref.trim : void 0) != null) && integration.channel.trim() === '') {  // 3
      delete integration.channel;                                                                                    // 4
    }                                                                                                                //
    if (!RocketChat.authz.hasPermission(this.userId, 'manage-integrations') && !RocketChat.authz.hasPermission(this.userId, 'manage-integrations', 'bot')) {
      throw new Meteor.Error('not_authorized');                                                                      // 7
    }                                                                                                                //
    if (integration.username.trim() === '') {                                                                        // 9
      throw new Meteor.Error('invalid_username', '[methods] addOutgoingIntegration -> username can\'t be empty');    // 10
    }                                                                                                                //
    if (!Match.test(integration.urls, [String])) {                                                                   // 12
      throw new Meteor.Error('invalid_urls', '[methods] addOutgoingIntegration -> urls must be an array');           // 13
    }                                                                                                                //
    ref1 = integration.urls;                                                                                         // 15
    for (index = i = 0, len = ref1.length; i < len; index = ++i) {                                                   // 15
      url = ref1[index];                                                                                             //
      if (url.trim() === '') {                                                                                       // 16
        delete integration.urls[index];                                                                              // 16
      }                                                                                                              //
    }                                                                                                                // 15
    integration.urls = _.without(integration.urls, [void 0]);                                                        // 3
    if (integration.urls.length === 0) {                                                                             // 20
      throw new Meteor.Error('invalid_urls', '[methods] addOutgoingIntegration -> urls is required');                // 21
    }                                                                                                                //
    if ((integration.channel != null) && ((ref2 = integration.channel[0]) !== '@' && ref2 !== '#')) {                // 23
      throw new Meteor.Error('invalid_channel', '[methods] addOutgoingIntegration -> channel should start with # or @');
    }                                                                                                                //
    if (integration.triggerWords != null) {                                                                          // 26
      if (!Match.test(integration.triggerWords, [String])) {                                                         // 27
        throw new Meteor.Error('invalid_triggerWords', '[methods] addOutgoingIntegration -> triggerWords must be an array');
      }                                                                                                              //
      ref3 = integration.triggerWords;                                                                               // 30
      for (index = j = 0, len1 = ref3.length; j < len1; index = ++j) {                                               // 30
        triggerWord = ref3[index];                                                                                   //
        if (triggerWord.trim() === '') {                                                                             // 31
          delete integration.triggerWords[index];                                                                    // 31
        }                                                                                                            //
      }                                                                                                              // 30
      integration.triggerWords = _.without(integration.triggerWords, [void 0]);                                      // 27
    }                                                                                                                //
    if (integration.channel != null) {                                                                               // 35
      record = void 0;                                                                                               // 36
      channelType = integration.channel[0];                                                                          // 36
      channel = integration.channel.substr(1);                                                                       // 36
      switch (channelType) {                                                                                         // 40
        case '#':                                                                                                    // 40
          record = RocketChat.models.Rooms.findOne({                                                                 // 42
            $or: [                                                                                                   // 43
              {                                                                                                      //
                _id: channel                                                                                         // 44
              }, {                                                                                                   //
                name: channel                                                                                        // 45
              }                                                                                                      //
            ]                                                                                                        //
          });                                                                                                        //
          break;                                                                                                     // 41
        case '@':                                                                                                    // 40
          record = RocketChat.models.Users.findOne({                                                                 // 48
            $or: [                                                                                                   // 49
              {                                                                                                      //
                _id: channel                                                                                         // 50
              }, {                                                                                                   //
                username: channel                                                                                    // 51
              }                                                                                                      //
            ]                                                                                                        //
          });                                                                                                        //
      }                                                                                                              // 40
      if (record === void 0) {                                                                                       // 54
        throw new Meteor.Error('channel_does_not_exists', "[methods] addOutgoingIntegration -> The channel does not exists");
      }                                                                                                              //
    }                                                                                                                //
    user = RocketChat.models.Users.findOne({                                                                         // 3
      username: integration.username                                                                                 // 57
    });                                                                                                              //
    if (user == null) {                                                                                              // 59
      throw new Meteor.Error('user_does_not_exists', "[methods] addOutgoingIntegration -> The username does not exists");
    }                                                                                                                //
    integration.type = 'webhook-outgoing';                                                                           // 3
    integration.userId = user._id;                                                                                   // 3
    integration._createdAt = new Date;                                                                               // 3
    integration._createdBy = RocketChat.models.Users.findOne(this.userId, {                                          // 3
      fields: {                                                                                                      // 65
        username: 1                                                                                                  // 65
      }                                                                                                              //
    });                                                                                                              //
    integration._id = RocketChat.models.Integrations.insert(integration);                                            // 3
    return integration;                                                                                              // 69
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/outgoing/updateOutgoingIntegration.coffee.js                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  updateOutgoingIntegration: function(integrationId, integration) {                                                  // 2
    var channel, channelType, i, index, j, len, len1, record, ref, ref1, ref2, ref3, triggerWord, url, user;         // 3
    if (!RocketChat.authz.hasPermission(this.userId, 'manage-integrations')) {                                       // 3
      throw new Meteor.Error('not_authorized');                                                                      // 4
    }                                                                                                                //
    if (integration.username.trim() === '') {                                                                        // 6
      throw new Meteor.Error('invalid_username', '[methods] updateOutgoingIntegration -> username can\'t be empty');
    }                                                                                                                //
    if (!Match.test(integration.urls, [String])) {                                                                   // 9
      throw new Meteor.Error('invalid_urls', '[methods] updateOutgoingIntegration -> urls must be an array');        // 10
    }                                                                                                                //
    ref = integration.urls;                                                                                          // 12
    for (index = i = 0, len = ref.length; i < len; index = ++i) {                                                    // 12
      url = ref[index];                                                                                              //
      if (url.trim() === '') {                                                                                       // 13
        delete integration.urls[index];                                                                              // 13
      }                                                                                                              //
    }                                                                                                                // 12
    integration.urls = _.without(integration.urls, [void 0]);                                                        // 3
    if (integration.urls.length === 0) {                                                                             // 17
      throw new Meteor.Error('invalid_urls', '[methods] updateOutgoingIntegration -> urls is required');             // 18
    }                                                                                                                //
    if (_.isString(integration.channel)) {                                                                           // 20
      integration.channel = integration.channel.trim();                                                              // 21
    } else {                                                                                                         //
      integration.channel = void 0;                                                                                  // 23
    }                                                                                                                //
    if ((integration.channel != null) && ((ref1 = integration.channel[0]) !== '@' && ref1 !== '#')) {                // 25
      throw new Meteor.Error('invalid_channel', '[methods] updateOutgoingIntegration -> channel should start with # or @');
    }                                                                                                                //
    if ((integration.token == null) || ((ref2 = integration.token) != null ? ref2.trim() : void 0) === '') {         // 28
      throw new Meteor.Error('invalid_token', '[methods] updateOutgoingIntegration -> token is required');           // 29
    }                                                                                                                //
    if (integration.triggerWords != null) {                                                                          // 31
      if (!Match.test(integration.triggerWords, [String])) {                                                         // 32
        throw new Meteor.Error('invalid_triggerWords', '[methods] updateOutgoingIntegration -> triggerWords must be an array');
      }                                                                                                              //
      ref3 = integration.triggerWords;                                                                               // 35
      for (index = j = 0, len1 = ref3.length; j < len1; index = ++j) {                                               // 35
        triggerWord = ref3[index];                                                                                   //
        if (triggerWord.trim() === '') {                                                                             // 36
          delete integration.triggerWords[index];                                                                    // 36
        }                                                                                                            //
      }                                                                                                              // 35
      integration.triggerWords = _.without(integration.triggerWords, [void 0]);                                      // 32
    }                                                                                                                //
    if (RocketChat.models.Integrations.findOne(integrationId) == null) {                                             // 40
      throw new Meteor.Error('invalid_integration', '[methods] updateOutgoingIntegration -> integration not found');
    }                                                                                                                //
    if (integration.channel != null) {                                                                               // 44
      record = void 0;                                                                                               // 45
      channelType = integration.channel[0];                                                                          // 45
      channel = integration.channel.substr(1);                                                                       // 45
      switch (channelType) {                                                                                         // 49
        case '#':                                                                                                    // 49
          record = RocketChat.models.Rooms.findOne({                                                                 // 51
            $or: [                                                                                                   // 52
              {                                                                                                      //
                _id: channel                                                                                         // 53
              }, {                                                                                                   //
                name: channel                                                                                        // 54
              }                                                                                                      //
            ]                                                                                                        //
          });                                                                                                        //
          break;                                                                                                     // 50
        case '@':                                                                                                    // 49
          record = RocketChat.models.Users.findOne({                                                                 // 57
            $or: [                                                                                                   // 58
              {                                                                                                      //
                _id: channel                                                                                         // 59
              }, {                                                                                                   //
                username: channel                                                                                    // 60
              }                                                                                                      //
            ]                                                                                                        //
          });                                                                                                        //
      }                                                                                                              // 49
      if (record === void 0) {                                                                                       // 63
        throw new Meteor.Error('channel_does_not_exists', "[methods] updateOutgoingIntegration -> The channel does not exists");
      }                                                                                                              //
    }                                                                                                                //
    user = RocketChat.models.Users.findOne({                                                                         // 3
      username: integration.username                                                                                 // 66
    });                                                                                                              //
    if (user == null) {                                                                                              // 68
      throw new Meteor.Error('user_does_not_exists', "[methods] updateOutgoingIntegration -> The username does not exists");
    }                                                                                                                //
    RocketChat.models.Integrations.update(integrationId, {                                                           // 3
      $set: {                                                                                                        // 72
        name: integration.name,                                                                                      // 73
        avatar: integration.avatar,                                                                                  // 73
        emoji: integration.emoji,                                                                                    // 73
        alias: integration.alias,                                                                                    // 73
        channel: integration.channel,                                                                                // 73
        username: integration.username,                                                                              // 73
        userId: user._id,                                                                                            // 73
        urls: integration.urls,                                                                                      // 73
        token: integration.token,                                                                                    // 73
        triggerWords: integration.triggerWords,                                                                      // 73
        _updatedAt: new Date,                                                                                        // 73
        _updatedBy: RocketChat.models.Users.findOne(this.userId, {                                                   // 73
          fields: {                                                                                                  // 84
            username: 1                                                                                              // 84
          }                                                                                                          //
        })                                                                                                           //
      }                                                                                                              //
    });                                                                                                              //
    return RocketChat.models.Integrations.findOne(integrationId);                                                    // 86
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/methods/outgoing/deleteOutgoingIntegration.coffee.js                      //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.methods({                                                                                                     // 1
  deleteOutgoingIntegration: function(integrationId) {                                                               // 2
    var integration;                                                                                                 // 3
    if (!RocketChat.authz.hasPermission(this.userId, 'manage-integrations') && !RocketChat.authz.hasPermission(this.userId, 'manage-integrations', 'bot')) {
      throw new Meteor.Error('not_authorized');                                                                      // 4
    }                                                                                                                //
    integration = RocketChat.models.Integrations.findOne(integrationId);                                             // 3
    if (integration == null) {                                                                                       // 8
      throw new Meteor.Error('invalid_integration', '[methods] deleteOutgoingIntegration -> integration not found');
    }                                                                                                                //
    RocketChat.models.Integrations.remove({                                                                          // 3
      _id: integrationId                                                                                             // 11
    });                                                                                                              //
    return true;                                                                                                     // 13
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/api/api.coffee.js                                                         //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var Api, createIntegration, removeIntegration;                                                                       // 1
                                                                                                                     //
Api = new Restivus({                                                                                                 // 1
  enableCors: true,                                                                                                  // 2
  apiPath: 'hooks/',                                                                                                 // 2
  auth: {                                                                                                            // 2
    user: function() {                                                                                               // 5
      var ref, user;                                                                                                 // 6
      if (((ref = this.bodyParams) != null ? ref.payload : void 0) != null) {                                        // 6
        this.bodyParams = JSON.parse(this.bodyParams.payload);                                                       // 7
      }                                                                                                              //
      user = RocketChat.models.Users.findOne({                                                                       // 6
        _id: this.request.params.userId,                                                                             // 10
        'services.resume.loginTokens.hashedToken': decodeURIComponent(this.request.params.token)                     // 10
      });                                                                                                            //
      return {                                                                                                       // 13
        user: user                                                                                                   // 13
      };                                                                                                             //
    }                                                                                                                //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute(':integrationId/:userId/:token', {                                                                      // 1
  authRequired: true                                                                                                 // 16
}, {                                                                                                                 //
  post: function() {                                                                                                 // 17
    var defaultValues, e, integration, message, user;                                                                // 18
    console.log('Post integration');                                                                                 // 18
    console.log('@urlParams', this.urlParams);                                                                       // 18
    console.log('@bodyParams', this.bodyParams);                                                                     // 18
    integration = RocketChat.models.Integrations.findOne(this.urlParams.integrationId);                              // 18
    user = RocketChat.models.Users.findOne(this.userId);                                                             // 18
    this.bodyParams.bot = {                                                                                          // 18
      i: integration._id                                                                                             // 26
    };                                                                                                               //
    defaultValues = {                                                                                                // 18
      channel: integration.channel,                                                                                  // 29
      alias: integration.alias,                                                                                      // 29
      avatar: integration.avatar,                                                                                    // 29
      emoji: integration.emoji                                                                                       // 29
    };                                                                                                               //
    try {                                                                                                            // 34
      message = processWebhookMessage(this.bodyParams, user, defaultValues);                                         // 35
      if (message == null) {                                                                                         // 37
        return RocketChat.API.v1.failure('unknown-error');                                                           // 38
      }                                                                                                              //
      return RocketChat.API.v1.success();                                                                            // 40
    } catch (_error) {                                                                                               //
      e = _error;                                                                                                    // 42
      return RocketChat.API.v1.failure(e.error);                                                                     // 42
    }                                                                                                                //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
createIntegration = function(options, user) {                                                                        // 1
  console.log('Add integration');                                                                                    // 46
  console.log(options);                                                                                              // 46
  Meteor.runAsUser(user._id, (function(_this) {                                                                      // 46
    return function() {                                                                                              //
      switch (options['event']) {                                                                                    // 50
        case 'newMessageOnChannel':                                                                                  // 50
          if (options.data == null) {                                                                                //
            options.data = {};                                                                                       //
          }                                                                                                          //
          if ((options.data.channel_name != null) && options.data.channel_name.indexOf('#') === -1) {                // 54
            options.data.channel_name = '#' + options.data.channel_name;                                             // 55
          }                                                                                                          //
          return Meteor.call('addOutgoingIntegration', {                                                             //
            username: 'rocket.cat',                                                                                  // 58
            urls: [options.target_url],                                                                              // 58
            name: options.name,                                                                                      // 58
            channel: options.data.channel_name,                                                                      // 58
            triggerWords: options.data.trigger_words                                                                 // 58
          });                                                                                                        //
        case 'newMessageToUser':                                                                                     // 50
          if (options.data.username.indexOf('@') === -1) {                                                           // 65
            options.data.username = '@' + options.data.username;                                                     // 66
          }                                                                                                          //
          return Meteor.call('addOutgoingIntegration', {                                                             //
            username: 'rocket.cat',                                                                                  // 69
            urls: [options.target_url],                                                                              // 69
            name: options.name,                                                                                      // 69
            channel: options.data.username,                                                                          // 69
            triggerWords: options.data.trigger_words                                                                 // 69
          });                                                                                                        //
      }                                                                                                              // 50
    };                                                                                                               //
  })(this));                                                                                                         //
  return RocketChat.API.v1.success();                                                                                // 75
};                                                                                                                   // 45
                                                                                                                     //
removeIntegration = function(options, user) {                                                                        // 1
  var integrationToRemove;                                                                                           // 79
  console.log('Remove integration');                                                                                 // 79
  console.log(options);                                                                                              // 79
  integrationToRemove = RocketChat.models.Integrations.findOne({                                                     // 79
    urls: options.target_url                                                                                         // 82
  });                                                                                                                //
  Meteor.runAsUser(user._id, (function(_this) {                                                                      // 79
    return function() {                                                                                              //
      return Meteor.call('deleteOutgoingIntegration', integrationToRemove._id);                                      //
    };                                                                                                               //
  })(this));                                                                                                         //
  return RocketChat.API.v1.success();                                                                                // 86
};                                                                                                                   // 78
                                                                                                                     //
Api.addRoute('add/:integrationId/:userId/:token', {                                                                  // 1
  authRequired: true                                                                                                 // 89
}, {                                                                                                                 //
  post: function() {                                                                                                 // 90
    var integration, user;                                                                                           // 91
    integration = RocketChat.models.Integrations.findOne(this.urlParams.integrationId);                              // 91
    if (integration == null) {                                                                                       // 93
      return RocketChat.API.v1.failure('Invalid integraiton id');                                                    // 94
    }                                                                                                                //
    user = RocketChat.models.Users.findOne(this.userId);                                                             // 91
    return createIntegration(this.bodyParams, user);                                                                 // 98
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('remove/:integrationId/:userId/:token', {                                                               // 1
  authRequired: true                                                                                                 // 101
}, {                                                                                                                 //
  post: function() {                                                                                                 // 102
    var integration, user;                                                                                           // 103
    integration = RocketChat.models.Integrations.findOne(this.urlParams.integrationId);                              // 103
    if (integration == null) {                                                                                       // 105
      return RocketChat.API.v1.failure('Invalid integraiton id');                                                    // 106
    }                                                                                                                //
    user = RocketChat.models.Users.findOne(this.userId);                                                             // 103
    return removeIntegration(this.bodyParams, user);                                                                 // 110
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
RocketChat.API.v1.addRoute('integrations.create', {                                                                  // 1
  authRequired: true                                                                                                 // 113
}, {                                                                                                                 //
  post: function() {                                                                                                 // 114
    return createIntegration(this.bodyParams, this.user);                                                            // 115
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
RocketChat.API.v1.addRoute('integrations.remove', {                                                                  // 1
  authRequired: true                                                                                                 // 118
}, {                                                                                                                 //
  post: function() {                                                                                                 // 119
    return removeIntegration(this.bodyParams, this.user);                                                            // 120
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('sample/:integrationId/:userId/:token', {                                                               // 1
  authRequired: true                                                                                                 // 123
}, {                                                                                                                 //
  get: function() {                                                                                                  // 124
    console.log('Sample Integration');                                                                               // 125
    return {                                                                                                         // 127
      statusCode: 200,                                                                                               // 128
      body: [                                                                                                        // 128
        {                                                                                                            //
          token: Random.id(24),                                                                                      // 130
          channel_id: Random.id(),                                                                                   // 130
          channel_name: 'general',                                                                                   // 130
          timestamp: new Date,                                                                                       // 130
          user_id: Random.id(),                                                                                      // 130
          user_name: 'rocket.cat',                                                                                   // 130
          text: 'Sample text 1',                                                                                     // 130
          trigger_word: 'Sample'                                                                                     // 130
        }, {                                                                                                         //
          token: Random.id(24),                                                                                      // 139
          channel_id: Random.id(),                                                                                   // 139
          channel_name: 'general',                                                                                   // 139
          timestamp: new Date,                                                                                       // 139
          user_id: Random.id(),                                                                                      // 139
          user_name: 'rocket.cat',                                                                                   // 139
          text: 'Sample text 2',                                                                                     // 139
          trigger_word: 'Sample'                                                                                     // 139
        }, {                                                                                                         //
          token: Random.id(24),                                                                                      // 148
          channel_id: Random.id(),                                                                                   // 148
          channel_name: 'general',                                                                                   // 148
          timestamp: new Date,                                                                                       // 148
          user_id: Random.id(),                                                                                      // 148
          user_name: 'rocket.cat',                                                                                   // 148
          text: 'Sample text 3',                                                                                     // 148
          trigger_word: 'Sample'                                                                                     // 148
        }                                                                                                            //
      ]                                                                                                              //
    };                                                                                                               //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
Api.addRoute('info/:integrationId/:userId/:token', {                                                                 // 1
  authRequired: true                                                                                                 // 159
}, {                                                                                                                 //
  get: function() {                                                                                                  // 160
    console.log('Info integration');                                                                                 // 161
    return {                                                                                                         // 163
      statusCode: 200,                                                                                               // 164
      body: {                                                                                                        // 164
        success: true                                                                                                // 166
      }                                                                                                              //
    };                                                                                                               //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/triggers.coffee.js                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var ExecuteTrigger, ExecuteTriggerUrl, ExecuteTriggers, triggers;                                                    // 1
                                                                                                                     //
triggers = {};                                                                                                       // 1
                                                                                                                     //
RocketChat.models.Integrations.find({                                                                                // 1
  type: 'webhook-outgoing'                                                                                           // 3
}).observe({                                                                                                         //
  added: function(record) {                                                                                          // 4
    var channel;                                                                                                     // 5
    channel = record.channel || '__any';                                                                             // 5
    if (triggers[channel] == null) {                                                                                 //
      triggers[channel] = {};                                                                                        //
    }                                                                                                                //
    return triggers[channel][record._id] = record;                                                                   //
  },                                                                                                                 //
  changed: function(record) {                                                                                        // 4
    var channel;                                                                                                     // 10
    channel = record.channel || '__any';                                                                             // 10
    if (triggers[channel] == null) {                                                                                 //
      triggers[channel] = {};                                                                                        //
    }                                                                                                                //
    return triggers[channel][record._id] = record;                                                                   //
  },                                                                                                                 //
  removed: function(record) {                                                                                        // 4
    var channel;                                                                                                     // 15
    channel = record.channel || '__any';                                                                             // 15
    return delete triggers[channel][record._id];                                                                     //
  }                                                                                                                  //
});                                                                                                                  //
                                                                                                                     //
ExecuteTriggerUrl = function(url, trigger, message, room, tries) {                                                   // 1
  var data, i, len, opts, ref, ref1, triggerWord, word;                                                              // 20
  if (tries == null) {                                                                                               //
    tries = 0;                                                                                                       //
  }                                                                                                                  //
  word = void 0;                                                                                                     // 20
  if (((ref = trigger.triggerWords) != null ? ref.length : void 0) > 0) {                                            // 21
    ref1 = trigger.triggerWords;                                                                                     // 22
    for (i = 0, len = ref1.length; i < len; i++) {                                                                   // 22
      triggerWord = ref1[i];                                                                                         //
      if (message.msg.indexOf(triggerWord) === 0) {                                                                  // 23
        word = triggerWord;                                                                                          // 24
        break;                                                                                                       // 25
      }                                                                                                              //
    }                                                                                                                // 22
    if (word == null) {                                                                                              // 28
      return;                                                                                                        // 29
    }                                                                                                                //
  }                                                                                                                  //
  data = {                                                                                                           // 20
    token: trigger.token,                                                                                            // 32
    channel_id: room._id,                                                                                            // 32
    channel_name: room.name,                                                                                         // 32
    timestamp: message.ts,                                                                                           // 32
    user_id: message.u._id,                                                                                          // 32
    user_name: message.u.username,                                                                                   // 32
    text: message.msg                                                                                                // 32
  };                                                                                                                 //
  if (word != null) {                                                                                                // 40
    data.trigger_word = word;                                                                                        // 41
  }                                                                                                                  //
  opts = {                                                                                                           // 20
    data: data,                                                                                                      // 44
    npmRequestOptions: {                                                                                             // 44
      rejectUnauthorized: !RocketChat.settings.get('Allow_Invalid_SelfSigned_Certs'),                                // 46
      strictSSL: !RocketChat.settings.get('Allow_Invalid_SelfSigned_Certs')                                          // 46
    },                                                                                                               //
    headers: {                                                                                                       // 44
      'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36'
    }                                                                                                                //
  };                                                                                                                 //
  return HTTP.call('POST', url, opts, function(error, result) {                                                      //
    var defaultValues, ref2, ref3, user;                                                                             // 52
    if ((result == null) || result.statusCode !== 200) {                                                             // 52
      if (result.statusCode === 410) {                                                                               // 53
        RocketChat.models.Integrations.remove({                                                                      // 54
          _id: trigger._id                                                                                           // 54
        });                                                                                                          //
        return;                                                                                                      // 55
      }                                                                                                              //
      if (result.statusCode === 500) {                                                                               // 57
        console.log('Request Error [500]', url);                                                                     // 58
        console.log(result.content);                                                                                 // 58
        return;                                                                                                      // 60
      }                                                                                                              //
      if (tries <= 6) {                                                                                              // 62
        Meteor.setTimeout(function() {                                                                               // 64
          return ExecuteTriggerUrl(url, trigger, message, room, tries + 1);                                          //
        }, Math.pow(10, tries + 2));                                                                                 //
      }                                                                                                              //
    } else if ((result != null ? result.statusCode : void 0) === 200 && ((((ref2 = result.data) != null ? ref2.text : void 0) != null) || (((ref3 = result.data) != null ? ref3.attachments : void 0) != null))) {
      user = RocketChat.models.Users.findOneByUsername(trigger.username);                                            // 71
      result.data.bot = {                                                                                            // 71
        i: trigger._id                                                                                               // 74
      };                                                                                                             //
      defaultValues = {                                                                                              // 71
        alias: trigger.alias,                                                                                        // 77
        avatar: trigger.avatar,                                                                                      // 77
        emoji: trigger.emoji                                                                                         // 77
      };                                                                                                             //
      if (room.t === 'd') {                                                                                          // 81
        defaultValues.channel = '@' + room._id;                                                                      // 82
      } else {                                                                                                       //
        defaultValues.channel = '#' + room._id;                                                                      // 84
      }                                                                                                              //
      return message = processWebhookMessage(result.data, user, defaultValues);                                      //
    }                                                                                                                //
  });                                                                                                                //
};                                                                                                                   // 19
                                                                                                                     //
ExecuteTrigger = function(trigger, message, room) {                                                                  // 1
  var i, len, ref, results, url;                                                                                     // 90
  ref = trigger.urls;                                                                                                // 90
  results = [];                                                                                                      // 90
  for (i = 0, len = ref.length; i < len; i++) {                                                                      //
    url = ref[i];                                                                                                    //
    results.push(ExecuteTriggerUrl(url, trigger, message, room));                                                    // 91
  }                                                                                                                  // 90
  return results;                                                                                                    //
};                                                                                                                   // 89
                                                                                                                     //
ExecuteTriggers = function(message, room) {                                                                          // 1
  var i, id, key, len, ref, ref1, ref2, ref3, ref4, ref5, ref6, trigger, triggerToExecute, triggersToExecute, username;
  if (room == null) {                                                                                                // 95
    return;                                                                                                          // 96
  }                                                                                                                  //
  triggersToExecute = [];                                                                                            // 95
  switch (room.t) {                                                                                                  // 100
    case 'd':                                                                                                        // 100
      id = room._id.replace(message.u._id, '');                                                                      // 102
      username = _.without(room.usernames, message.u.username);                                                      // 102
      username = username[0];                                                                                        // 102
      if (triggers['@' + id] != null) {                                                                              // 107
        ref = triggers['@' + id];                                                                                    // 108
        for (key in ref) {                                                                                           // 108
          trigger = ref[key];                                                                                        //
          triggersToExecute.push(trigger);                                                                           // 108
        }                                                                                                            // 108
      }                                                                                                              //
      if (id !== username && (triggers['@' + username] != null)) {                                                   // 110
        ref1 = triggers['@' + username];                                                                             // 111
        for (key in ref1) {                                                                                          // 111
          trigger = ref1[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           // 111
        }                                                                                                            // 111
      }                                                                                                              //
      break;                                                                                                         // 101
    case 'c':                                                                                                        // 100
      if (triggers.__any != null) {                                                                                  // 114
        ref2 = triggers.__any;                                                                                       // 115
        for (key in ref2) {                                                                                          // 115
          trigger = ref2[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           // 115
        }                                                                                                            // 115
      }                                                                                                              //
      if (triggers['#' + room._id] != null) {                                                                        // 117
        ref3 = triggers['#' + room._id];                                                                             // 118
        for (key in ref3) {                                                                                          // 118
          trigger = ref3[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           // 118
        }                                                                                                            // 118
      }                                                                                                              //
      if (room._id !== room.name && (triggers['#' + room.name] != null)) {                                           // 120
        ref4 = triggers['#' + room.name];                                                                            // 121
        for (key in ref4) {                                                                                          // 121
          trigger = ref4[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           // 121
        }                                                                                                            // 121
      }                                                                                                              //
      break;                                                                                                         // 113
    default:                                                                                                         // 100
      if (triggers['#' + room._id] != null) {                                                                        // 124
        ref5 = triggers['#' + room._id];                                                                             // 125
        for (key in ref5) {                                                                                          // 125
          trigger = ref5[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           // 125
        }                                                                                                            // 125
      }                                                                                                              //
      if (room._id !== room.name && (triggers['#' + room.name] != null)) {                                           // 127
        ref6 = triggers['#' + room.name];                                                                            // 128
        for (key in ref6) {                                                                                          // 128
          trigger = ref6[key];                                                                                       //
          triggersToExecute.push(trigger);                                                                           // 128
        }                                                                                                            // 128
      }                                                                                                              //
  }                                                                                                                  // 100
  for (i = 0, len = triggersToExecute.length; i < len; i++) {                                                        // 131
    triggerToExecute = triggersToExecute[i];                                                                         //
    ExecuteTrigger(triggerToExecute, message, room);                                                                 // 132
  }                                                                                                                  // 131
  return message;                                                                                                    // 134
};                                                                                                                   // 94
                                                                                                                     //
RocketChat.callbacks.add('afterSaveMessage', ExecuteTriggers, RocketChat.callbacks.priority.LOW);                    // 1
                                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rocketchat_integrations/server/processWebhookMessage.js                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
this.processWebhookMessage = function(messageObj, user, defaultValues) {                                             // 1
	var attachment, channel, channelType, i, len, message, ref, rid, room, roomUser;                                    // 2
                                                                                                                     // 3
	if (!defaultValues) {                                                                                               // 4
		defaultValues = {                                                                                                  // 5
			channel: '',                                                                                                      // 6
			alias: '',                                                                                                        // 7
			avatar: '',                                                                                                       // 8
			emoji: ''                                                                                                         // 9
		};                                                                                                                 // 10
	}                                                                                                                   // 11
                                                                                                                     // 12
	channel = messageObj.channel || defaultValues.channel;                                                              // 13
                                                                                                                     // 14
	channelType = channel[0];                                                                                           // 15
                                                                                                                     // 16
	channel = channel.substr(1);                                                                                        // 17
                                                                                                                     // 18
	switch (channelType) {                                                                                              // 19
		case '#':                                                                                                          // 20
			room = RocketChat.models.Rooms.findOne({                                                                          // 21
				$or: [                                                                                                           // 22
					{                                                                                                               // 23
						_id: channel                                                                                                   // 24
					}, {                                                                                                            // 25
						name: channel                                                                                                  // 26
					}                                                                                                               // 27
				]                                                                                                                // 28
			});                                                                                                               // 29
			if (room == null) {                                                                                               // 30
				throw new Meteor.Error('invalid-channel');                                                                       // 31
			}                                                                                                                 // 32
			rid = room._id;                                                                                                   // 33
			if (room.t === 'c') {                                                                                             // 34
				Meteor.runAsUser(user._id, function() {                                                                          // 35
					return Meteor.call('joinRoom', room._id);                                                                       // 36
				});                                                                                                              // 37
			}                                                                                                                 // 38
			break;                                                                                                            // 39
		case '@':                                                                                                          // 40
			roomUser = RocketChat.models.Users.findOne({                                                                      // 41
				$or: [                                                                                                           // 42
					{                                                                                                               // 43
						_id: channel                                                                                                   // 44
					}, {                                                                                                            // 45
						username: channel                                                                                              // 46
					}                                                                                                               // 47
				]                                                                                                                // 48
			}) || {};                                                                                                         // 49
			rid = [user._id, roomUser._id].sort().join('');                                                                   // 50
			room = RocketChat.models.Rooms.findOne({                                                                          // 51
				_id: {                                                                                                           // 52
					$in: [rid, channel]                                                                                             // 53
				}                                                                                                                // 54
			});                                                                                                               // 55
			if (roomUser == null && room == null) {                                                                           // 56
				throw new Meteor.Error('invalid-channel');                                                                       // 57
			}                                                                                                                 // 58
			if (!room) {                                                                                                      // 59
				Meteor.runAsUser(user._id, function() {                                                                          // 60
					Meteor.call('createDirectMessage', roomUser.username);                                                          // 61
					return room = RocketChat.models.Rooms.findOne(rid);                                                             // 62
				});                                                                                                              // 63
			}                                                                                                                 // 64
			break;                                                                                                            // 65
		default:                                                                                                           // 66
			throw new Meteor.Error('invalid-channel-type');                                                                   // 67
	}                                                                                                                   // 68
                                                                                                                     // 69
	message = {                                                                                                         // 70
		alias: messageObj.username || messageObj.alias || defaultValues.alias,                                             // 71
		msg: _.trim(messageObj.text || messageObj.msg || ''),                                                              // 72
		attachments: messageObj.attachments,                                                                               // 73
		parseUrls: messageObj.parseUrls || true,                                                                           // 74
		bot: messageObj.bot,                                                                                               // 75
		groupable: false                                                                                                   // 76
	};                                                                                                                  // 77
                                                                                                                     // 78
	if ((messageObj.icon_url != null) || (messageObj.avatar != null)) {                                                 // 79
		message.avatar = messageObj.icon_url || messageObj.avatar;                                                         // 80
	} else if ((messageObj.icon_emoji != null) || (messageObj.emoji != null)) {                                         // 81
		message.emoji = messageObj.icon_emoji || messageObj.emoji;                                                         // 82
	} else if (defaultValues.avatar != null) {                                                                          // 83
		message.avatar = defaultValues.avatar;                                                                             // 84
	} else if (defaultValues.emoji != null) {                                                                           // 85
		message.emoji = defaultValues.emoji;                                                                               // 86
	}                                                                                                                   // 87
                                                                                                                     // 88
	if (_.isArray(message.attachments)) {                                                                               // 89
		ref = message.attachments;                                                                                         // 90
		for (i = 0, len = ref.length; i < len; i++) {                                                                      // 91
			attachment = ref[i];                                                                                              // 92
			if (attachment.msg) {                                                                                             // 93
				attachment.text = _.trim(attachment.msg);                                                                        // 94
				delete attachment.msg;                                                                                           // 95
			}                                                                                                                 // 96
		}                                                                                                                  // 97
	}                                                                                                                   // 98
                                                                                                                     // 99
	var messageReturn = RocketChat.sendMessage(user, message, room, {});                                                // 100
                                                                                                                     // 101
	return {                                                                                                            // 102
		channel: channel,                                                                                                  // 103
		message: messageReturn                                                                                             // 104
	}                                                                                                                   // 105
};                                                                                                                   // 106
                                                                                                                     // 107
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:integrations'] = {};

})();

//# sourceMappingURL=rocketchat_integrations.js.map
