(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var module, exports, s;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/underscorestring_underscore.string/meteor-pre.js                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// Defining this will trick dist/underscore.string.js into putting its exports into module.exports                    // 1
// Credit to Tim Heckel for this trick - see https://github.com/TimHeckel/meteor-underscore-string                    // 2
module = {};                                                                                                          // 3
                                                                                                                      // 4
// This also needed, otherwise above doesn't work???                                                                  // 5
exports = {};                                                                                                         // 6
                                                                                                                      // 7
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/underscorestring_underscore.string/dist/underscore.string.js                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
/* underscore.string 3.2.2 | MIT licensed | http://epeli.github.com/underscore.string/ */                             // 1
                                                                                                                      // 2
!function(e){if("object"==typeof exports)module.exports=e();else if("function"==typeof define&&define.amd)define(e);else{var f;"undefined"!=typeof window?f=window:"undefined"!=typeof global?f=global:"undefined"!=typeof self&&(f=self),f.s=e()}}(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(_dereq_,module,exports){
var trim = _dereq_('./trim');                                                                                         // 4
var decap = _dereq_('./decapitalize');                                                                                // 5
                                                                                                                      // 6
module.exports = function camelize(str, decapitalize) {                                                               // 7
  str = trim(str).replace(/[-_\s]+(.)?/g, function(match, c) {                                                        // 8
    return c ? c.toUpperCase() : "";                                                                                  // 9
  });                                                                                                                 // 10
                                                                                                                      // 11
  if (decapitalize === true) {                                                                                        // 12
    return decap(str);                                                                                                // 13
  } else {                                                                                                            // 14
    return str;                                                                                                       // 15
  }                                                                                                                   // 16
};                                                                                                                    // 17
                                                                                                                      // 18
},{"./decapitalize":10,"./trim":63}],2:[function(_dereq_,module,exports){                                             // 19
var makeString = _dereq_('./helper/makeString');                                                                      // 20
                                                                                                                      // 21
module.exports = function capitalize(str, lowercaseRest) {                                                            // 22
  str = makeString(str);                                                                                              // 23
  var remainingChars = !lowercaseRest ? str.slice(1) : str.slice(1).toLowerCase();                                    // 24
                                                                                                                      // 25
  return str.charAt(0).toUpperCase() + remainingChars;                                                                // 26
};                                                                                                                    // 27
                                                                                                                      // 28
},{"./helper/makeString":21}],3:[function(_dereq_,module,exports){                                                    // 29
var makeString = _dereq_('./helper/makeString');                                                                      // 30
                                                                                                                      // 31
module.exports = function chars(str) {                                                                                // 32
  return makeString(str).split('');                                                                                   // 33
};                                                                                                                    // 34
                                                                                                                      // 35
},{"./helper/makeString":21}],4:[function(_dereq_,module,exports){                                                    // 36
module.exports = function chop(str, step) {                                                                           // 37
  if (str == null) return [];                                                                                         // 38
  str = String(str);                                                                                                  // 39
  step = ~~step;                                                                                                      // 40
  return step > 0 ? str.match(new RegExp('.{1,' + step + '}', 'g')) : [str];                                          // 41
};                                                                                                                    // 42
                                                                                                                      // 43
},{}],5:[function(_dereq_,module,exports){                                                                            // 44
var capitalize = _dereq_('./capitalize');                                                                             // 45
var camelize = _dereq_('./camelize');                                                                                 // 46
var makeString = _dereq_('./helper/makeString');                                                                      // 47
                                                                                                                      // 48
module.exports = function classify(str) {                                                                             // 49
  str = makeString(str);                                                                                              // 50
  return capitalize(camelize(str.replace(/[\W_]/g, ' ')).replace(/\s/g, ''));                                         // 51
};                                                                                                                    // 52
                                                                                                                      // 53
},{"./camelize":1,"./capitalize":2,"./helper/makeString":21}],6:[function(_dereq_,module,exports){                    // 54
var trim = _dereq_('./trim');                                                                                         // 55
                                                                                                                      // 56
module.exports = function clean(str) {                                                                                // 57
  return trim(str).replace(/\s\s+/g, ' ');                                                                            // 58
};                                                                                                                    // 59
                                                                                                                      // 60
},{"./trim":63}],7:[function(_dereq_,module,exports){                                                                 // 61
                                                                                                                      // 62
var makeString = _dereq_('./helper/makeString');                                                                      // 63
                                                                                                                      // 64
var from  = "ąàáäâãåæăćčĉęèéëêĝĥìíïîĵłľńňòóöőôõðøśșşšŝťțţŭùúüűûñÿýçżźž",                                              // 65
    to    = "aaaaaaaaaccceeeeeghiiiijllnnoooooooossssstttuuuuuunyyczzz";                                              // 66
                                                                                                                      // 67
from += from.toUpperCase();                                                                                           // 68
to += to.toUpperCase();                                                                                               // 69
                                                                                                                      // 70
to = to.split("");                                                                                                    // 71
                                                                                                                      // 72
// for tokens requireing multitoken output                                                                            // 73
from += "ß";                                                                                                          // 74
to.push('ss');                                                                                                        // 75
                                                                                                                      // 76
                                                                                                                      // 77
module.exports = function cleanDiacritics(str) {                                                                      // 78
    return makeString(str).replace(/.{1}/g, function(c){                                                              // 79
      var index = from.indexOf(c);                                                                                    // 80
      return index === -1 ? c : to[index];                                                                            // 81
  });                                                                                                                 // 82
};                                                                                                                    // 83
                                                                                                                      // 84
},{"./helper/makeString":21}],8:[function(_dereq_,module,exports){                                                    // 85
var makeString = _dereq_('./helper/makeString');                                                                      // 86
                                                                                                                      // 87
module.exports = function(str, substr) {                                                                              // 88
  str = makeString(str);                                                                                              // 89
  substr = makeString(substr);                                                                                        // 90
                                                                                                                      // 91
  if (str.length === 0 || substr.length === 0) return 0;                                                              // 92
                                                                                                                      // 93
  return str.split(substr).length - 1;                                                                                // 94
};                                                                                                                    // 95
                                                                                                                      // 96
},{"./helper/makeString":21}],9:[function(_dereq_,module,exports){                                                    // 97
var trim = _dereq_('./trim');                                                                                         // 98
                                                                                                                      // 99
module.exports = function dasherize(str) {                                                                            // 100
  return trim(str).replace(/([A-Z])/g, '-$1').replace(/[-_\s]+/g, '-').toLowerCase();                                 // 101
};                                                                                                                    // 102
                                                                                                                      // 103
},{"./trim":63}],10:[function(_dereq_,module,exports){                                                                // 104
var makeString = _dereq_('./helper/makeString');                                                                      // 105
                                                                                                                      // 106
module.exports = function decapitalize(str) {                                                                         // 107
  str = makeString(str);                                                                                              // 108
  return str.charAt(0).toLowerCase() + str.slice(1);                                                                  // 109
};                                                                                                                    // 110
                                                                                                                      // 111
},{"./helper/makeString":21}],11:[function(_dereq_,module,exports){                                                   // 112
var makeString = _dereq_('./helper/makeString');                                                                      // 113
                                                                                                                      // 114
function getIndent(str) {                                                                                             // 115
  var matches = str.match(/^[\s\\t]*/gm);                                                                             // 116
  var indent = matches[0].length;                                                                                     // 117
                                                                                                                      // 118
  for (var i = 1; i < matches.length; i++) {                                                                          // 119
    indent = Math.min(matches[i].length, indent);                                                                     // 120
  }                                                                                                                   // 121
                                                                                                                      // 122
  return indent;                                                                                                      // 123
}                                                                                                                     // 124
                                                                                                                      // 125
module.exports = function dedent(str, pattern) {                                                                      // 126
  str = makeString(str);                                                                                              // 127
  var indent = getIndent(str);                                                                                        // 128
  var reg;                                                                                                            // 129
                                                                                                                      // 130
  if (indent === 0) return str;                                                                                       // 131
                                                                                                                      // 132
  if (typeof pattern === 'string') {                                                                                  // 133
    reg = new RegExp('^' + pattern, 'gm');                                                                            // 134
  } else {                                                                                                            // 135
    reg = new RegExp('^[ \\t]{' + indent + '}', 'gm');                                                                // 136
  }                                                                                                                   // 137
                                                                                                                      // 138
  return str.replace(reg, '');                                                                                        // 139
};                                                                                                                    // 140
                                                                                                                      // 141
},{"./helper/makeString":21}],12:[function(_dereq_,module,exports){                                                   // 142
var makeString = _dereq_('./helper/makeString');                                                                      // 143
var toPositive = _dereq_('./helper/toPositive');                                                                      // 144
                                                                                                                      // 145
module.exports = function endsWith(str, ends, position) {                                                             // 146
  str = makeString(str);                                                                                              // 147
  ends = '' + ends;                                                                                                   // 148
  if (typeof position == 'undefined') {                                                                               // 149
    position = str.length - ends.length;                                                                              // 150
  } else {                                                                                                            // 151
    position = Math.min(toPositive(position), str.length) - ends.length;                                              // 152
  }                                                                                                                   // 153
  return position >= 0 && str.indexOf(ends, position) === position;                                                   // 154
};                                                                                                                    // 155
                                                                                                                      // 156
},{"./helper/makeString":21,"./helper/toPositive":23}],13:[function(_dereq_,module,exports){                          // 157
var makeString = _dereq_('./helper/makeString');                                                                      // 158
var escapeChars = _dereq_('./helper/escapeChars');                                                                    // 159
                                                                                                                      // 160
var regexString = "[";                                                                                                // 161
for(var key in escapeChars) {                                                                                         // 162
  regexString += key;                                                                                                 // 163
}                                                                                                                     // 164
regexString += "]";                                                                                                   // 165
                                                                                                                      // 166
var regex = new RegExp( regexString, 'g');                                                                            // 167
                                                                                                                      // 168
module.exports = function escapeHTML(str) {                                                                           // 169
                                                                                                                      // 170
  return makeString(str).replace(regex, function(m) {                                                                 // 171
    return '&' + escapeChars[m] + ';';                                                                                // 172
  });                                                                                                                 // 173
};                                                                                                                    // 174
                                                                                                                      // 175
},{"./helper/escapeChars":18,"./helper/makeString":21}],14:[function(_dereq_,module,exports){                         // 176
module.exports = function() {                                                                                         // 177
  var result = {};                                                                                                    // 178
                                                                                                                      // 179
  for (var prop in this) {                                                                                            // 180
    if (!this.hasOwnProperty(prop) || prop.match(/^(?:include|contains|reverse|join|map)$/)) continue;                // 181
    result[prop] = this[prop];                                                                                        // 182
  }                                                                                                                   // 183
                                                                                                                      // 184
  return result;                                                                                                      // 185
};                                                                                                                    // 186
                                                                                                                      // 187
},{}],15:[function(_dereq_,module,exports){                                                                           // 188
//  Underscore.string                                                                                                 // 189
//  (c) 2010 Esa-Matti Suuronen <esa-matti aet suuronen dot org>                                                      // 190
//  Underscore.string is freely distributable under the terms of the MIT license.                                     // 191
//  Documentation: https://github.com/epeli/underscore.string                                                         // 192
//  Some code is borrowed from MooTools and Alexandru Marasteanu.                                                     // 193
//  Version '3.2.2'                                                                                                   // 194
                                                                                                                      // 195
'use strict';                                                                                                         // 196
                                                                                                                      // 197
function s(value) {                                                                                                   // 198
  /* jshint validthis: true */                                                                                        // 199
  if (!(this instanceof s)) return new s(value);                                                                      // 200
  this._wrapped = value;                                                                                              // 201
}                                                                                                                     // 202
                                                                                                                      // 203
s.VERSION = '3.2.2';                                                                                                  // 204
                                                                                                                      // 205
s.isBlank          = _dereq_('./isBlank');                                                                            // 206
s.stripTags        = _dereq_('./stripTags');                                                                          // 207
s.capitalize       = _dereq_('./capitalize');                                                                         // 208
s.decapitalize     = _dereq_('./decapitalize');                                                                       // 209
s.chop             = _dereq_('./chop');                                                                               // 210
s.trim             = _dereq_('./trim');                                                                               // 211
s.clean            = _dereq_('./clean');                                                                              // 212
s.cleanDiacritics  = _dereq_('./cleanDiacritics');                                                                    // 213
s.count            = _dereq_('./count');                                                                              // 214
s.chars            = _dereq_('./chars');                                                                              // 215
s.swapCase         = _dereq_('./swapCase');                                                                           // 216
s.escapeHTML       = _dereq_('./escapeHTML');                                                                         // 217
s.unescapeHTML     = _dereq_('./unescapeHTML');                                                                       // 218
s.splice           = _dereq_('./splice');                                                                             // 219
s.insert           = _dereq_('./insert');                                                                             // 220
s.replaceAll       = _dereq_('./replaceAll');                                                                         // 221
s.include          = _dereq_('./include');                                                                            // 222
s.join             = _dereq_('./join');                                                                               // 223
s.lines            = _dereq_('./lines');                                                                              // 224
s.dedent           = _dereq_('./dedent');                                                                             // 225
s.reverse          = _dereq_('./reverse');                                                                            // 226
s.startsWith       = _dereq_('./startsWith');                                                                         // 227
s.endsWith         = _dereq_('./endsWith');                                                                           // 228
s.pred             = _dereq_('./pred');                                                                               // 229
s.succ             = _dereq_('./succ');                                                                               // 230
s.titleize         = _dereq_('./titleize');                                                                           // 231
s.camelize         = _dereq_('./camelize');                                                                           // 232
s.underscored      = _dereq_('./underscored');                                                                        // 233
s.dasherize        = _dereq_('./dasherize');                                                                          // 234
s.classify         = _dereq_('./classify');                                                                           // 235
s.humanize         = _dereq_('./humanize');                                                                           // 236
s.ltrim            = _dereq_('./ltrim');                                                                              // 237
s.rtrim            = _dereq_('./rtrim');                                                                              // 238
s.truncate         = _dereq_('./truncate');                                                                           // 239
s.prune            = _dereq_('./prune');                                                                              // 240
s.words            = _dereq_('./words');                                                                              // 241
s.pad              = _dereq_('./pad');                                                                                // 242
s.lpad             = _dereq_('./lpad');                                                                               // 243
s.rpad             = _dereq_('./rpad');                                                                               // 244
s.lrpad            = _dereq_('./lrpad');                                                                              // 245
s.sprintf          = _dereq_('./sprintf');                                                                            // 246
s.vsprintf         = _dereq_('./vsprintf');                                                                           // 247
s.toNumber         = _dereq_('./toNumber');                                                                           // 248
s.numberFormat     = _dereq_('./numberFormat');                                                                       // 249
s.strRight         = _dereq_('./strRight');                                                                           // 250
s.strRightBack     = _dereq_('./strRightBack');                                                                       // 251
s.strLeft          = _dereq_('./strLeft');                                                                            // 252
s.strLeftBack      = _dereq_('./strLeftBack');                                                                        // 253
s.toSentence       = _dereq_('./toSentence');                                                                         // 254
s.toSentenceSerial = _dereq_('./toSentenceSerial');                                                                   // 255
s.slugify          = _dereq_('./slugify');                                                                            // 256
s.surround         = _dereq_('./surround');                                                                           // 257
s.quote            = _dereq_('./quote');                                                                              // 258
s.unquote          = _dereq_('./unquote');                                                                            // 259
s.repeat           = _dereq_('./repeat');                                                                             // 260
s.naturalCmp       = _dereq_('./naturalCmp');                                                                         // 261
s.levenshtein      = _dereq_('./levenshtein');                                                                        // 262
s.toBoolean        = _dereq_('./toBoolean');                                                                          // 263
s.exports          = _dereq_('./exports');                                                                            // 264
s.escapeRegExp     = _dereq_('./helper/escapeRegExp');                                                                // 265
s.wrap             = _dereq_('./wrap');                                                                               // 266
s.map              = _dereq_('./map');                                                                                // 267
                                                                                                                      // 268
// Aliases                                                                                                            // 269
s.strip     = s.trim;                                                                                                 // 270
s.lstrip    = s.ltrim;                                                                                                // 271
s.rstrip    = s.rtrim;                                                                                                // 272
s.center    = s.lrpad;                                                                                                // 273
s.rjust     = s.lpad;                                                                                                 // 274
s.ljust     = s.rpad;                                                                                                 // 275
s.contains  = s.include;                                                                                              // 276
s.q         = s.quote;                                                                                                // 277
s.toBool    = s.toBoolean;                                                                                            // 278
s.camelcase = s.camelize;                                                                                             // 279
s.mapChars  = s.map;                                                                                                  // 280
                                                                                                                      // 281
                                                                                                                      // 282
// Implement chaining                                                                                                 // 283
s.prototype = {                                                                                                       // 284
  value: function value() {                                                                                           // 285
    return this._wrapped;                                                                                             // 286
  }                                                                                                                   // 287
};                                                                                                                    // 288
                                                                                                                      // 289
function fn2method(key, fn) {                                                                                         // 290
  if (typeof fn !== "function") return;                                                                               // 291
  s.prototype[key] = function() {                                                                                     // 292
    var args = [this._wrapped].concat(Array.prototype.slice.call(arguments));                                         // 293
    var res = fn.apply(null, args);                                                                                   // 294
    // if the result is non-string stop the chain and return the value                                                // 295
    return typeof res === 'string' ? new s(res) : res;                                                                // 296
  };                                                                                                                  // 297
}                                                                                                                     // 298
                                                                                                                      // 299
// Copy functions to instance methods for chaining                                                                    // 300
for (var key in s) fn2method(key, s[key]);                                                                            // 301
                                                                                                                      // 302
fn2method("tap", function tap(string, fn) {                                                                           // 303
  return fn(string);                                                                                                  // 304
});                                                                                                                   // 305
                                                                                                                      // 306
function prototype2method(methodName) {                                                                               // 307
  fn2method(methodName, function(context) {                                                                           // 308
    var args = Array.prototype.slice.call(arguments, 1);                                                              // 309
    return String.prototype[methodName].apply(context, args);                                                         // 310
  });                                                                                                                 // 311
}                                                                                                                     // 312
                                                                                                                      // 313
var prototypeMethods = [                                                                                              // 314
    "toUpperCase",                                                                                                    // 315
    "toLowerCase",                                                                                                    // 316
    "split",                                                                                                          // 317
    "replace",                                                                                                        // 318
    "slice",                                                                                                          // 319
    "substring",                                                                                                      // 320
    "substr",                                                                                                         // 321
    "concat"                                                                                                          // 322
];                                                                                                                    // 323
                                                                                                                      // 324
for (var method in prototypeMethods) prototype2method(prototypeMethods[method]);                                      // 325
                                                                                                                      // 326
                                                                                                                      // 327
module.exports = s;                                                                                                   // 328
                                                                                                                      // 329
},{"./camelize":1,"./capitalize":2,"./chars":3,"./chop":4,"./classify":5,"./clean":6,"./cleanDiacritics":7,"./count":8,"./dasherize":9,"./decapitalize":10,"./dedent":11,"./endsWith":12,"./escapeHTML":13,"./exports":14,"./helper/escapeRegExp":19,"./humanize":24,"./include":25,"./insert":26,"./isBlank":27,"./join":28,"./levenshtein":29,"./lines":30,"./lpad":31,"./lrpad":32,"./ltrim":33,"./map":34,"./naturalCmp":35,"./numberFormat":36,"./pad":37,"./pred":38,"./prune":39,"./quote":40,"./repeat":41,"./replaceAll":42,"./reverse":43,"./rpad":44,"./rtrim":45,"./slugify":46,"./splice":47,"./sprintf":48,"./startsWith":49,"./strLeft":50,"./strLeftBack":51,"./strRight":52,"./strRightBack":53,"./stripTags":54,"./succ":55,"./surround":56,"./swapCase":57,"./titleize":58,"./toBoolean":59,"./toNumber":60,"./toSentence":61,"./toSentenceSerial":62,"./trim":63,"./truncate":64,"./underscored":65,"./unescapeHTML":66,"./unquote":67,"./vsprintf":68,"./words":69,"./wrap":70}],16:[function(_dereq_,module,exports){
var makeString = _dereq_('./makeString');                                                                             // 331
                                                                                                                      // 332
module.exports = function adjacent(str, direction) {                                                                  // 333
  str = makeString(str);                                                                                              // 334
  if (str.length === 0) {                                                                                             // 335
    return '';                                                                                                        // 336
  }                                                                                                                   // 337
  return str.slice(0, -1) + String.fromCharCode(str.charCodeAt(str.length - 1) + direction);                          // 338
};                                                                                                                    // 339
                                                                                                                      // 340
},{"./makeString":21}],17:[function(_dereq_,module,exports){                                                          // 341
var escapeRegExp = _dereq_('./escapeRegExp');                                                                         // 342
                                                                                                                      // 343
module.exports = function defaultToWhiteSpace(characters) {                                                           // 344
  if (characters == null)                                                                                             // 345
    return '\\s';                                                                                                     // 346
  else if (characters.source)                                                                                         // 347
    return characters.source;                                                                                         // 348
  else                                                                                                                // 349
    return '[' + escapeRegExp(characters) + ']';                                                                      // 350
};                                                                                                                    // 351
                                                                                                                      // 352
},{"./escapeRegExp":19}],18:[function(_dereq_,module,exports){                                                        // 353
/* We're explicitly defining the list of entities we want to escape.                                                  // 354
nbsp is an HTML entity, but we don't want to escape all space characters in a string, hence its omission in this map.
                                                                                                                      // 356
*/                                                                                                                    // 357
var escapeChars = {                                                                                                   // 358
    '¢' : 'cent',                                                                                                     // 359
    '£' : 'pound',                                                                                                    // 360
    '¥' : 'yen',                                                                                                      // 361
    '€': 'euro',                                                                                                      // 362
    '©' :'copy',                                                                                                      // 363
    '®' : 'reg',                                                                                                      // 364
    '<' : 'lt',                                                                                                       // 365
    '>' : 'gt',                                                                                                       // 366
    '"' : 'quot',                                                                                                     // 367
    '&' : 'amp',                                                                                                      // 368
    "'" : '#39'                                                                                                       // 369
};                                                                                                                    // 370
                                                                                                                      // 371
module.exports = escapeChars;                                                                                         // 372
                                                                                                                      // 373
},{}],19:[function(_dereq_,module,exports){                                                                           // 374
var makeString = _dereq_('./makeString');                                                                             // 375
                                                                                                                      // 376
module.exports = function escapeRegExp(str) {                                                                         // 377
  return makeString(str).replace(/([.*+?^=!:${}()|[\]\/\\])/g, '\\$1');                                               // 378
};                                                                                                                    // 379
                                                                                                                      // 380
},{"./makeString":21}],20:[function(_dereq_,module,exports){                                                          // 381
/*                                                                                                                    // 382
We're explicitly defining the list of entities that might see in escape HTML strings                                  // 383
*/                                                                                                                    // 384
var htmlEntities = {                                                                                                  // 385
  nbsp: ' ',                                                                                                          // 386
  cent: '¢',                                                                                                          // 387
  pound: '£',                                                                                                         // 388
  yen: '¥',                                                                                                           // 389
  euro: '€',                                                                                                          // 390
  copy: '©',                                                                                                          // 391
  reg: '®',                                                                                                           // 392
  lt: '<',                                                                                                            // 393
  gt: '>',                                                                                                            // 394
  quot: '"',                                                                                                          // 395
  amp: '&',                                                                                                           // 396
  apos: "'"                                                                                                           // 397
};                                                                                                                    // 398
                                                                                                                      // 399
module.exports = htmlEntities;                                                                                        // 400
                                                                                                                      // 401
},{}],21:[function(_dereq_,module,exports){                                                                           // 402
/**                                                                                                                   // 403
 * Ensure some object is a coerced to a string                                                                        // 404
 **/                                                                                                                  // 405
module.exports = function makeString(object) {                                                                        // 406
  if (object == null) return '';                                                                                      // 407
  return '' + object;                                                                                                 // 408
};                                                                                                                    // 409
                                                                                                                      // 410
},{}],22:[function(_dereq_,module,exports){                                                                           // 411
module.exports = function strRepeat(str, qty){                                                                        // 412
  if (qty < 1) return '';                                                                                             // 413
  var result = '';                                                                                                    // 414
  while (qty > 0) {                                                                                                   // 415
    if (qty & 1) result += str;                                                                                       // 416
    qty >>= 1, str += str;                                                                                            // 417
  }                                                                                                                   // 418
  return result;                                                                                                      // 419
};                                                                                                                    // 420
                                                                                                                      // 421
},{}],23:[function(_dereq_,module,exports){                                                                           // 422
module.exports = function toPositive(number) {                                                                        // 423
  return number < 0 ? 0 : (+number || 0);                                                                             // 424
};                                                                                                                    // 425
                                                                                                                      // 426
},{}],24:[function(_dereq_,module,exports){                                                                           // 427
var capitalize = _dereq_('./capitalize');                                                                             // 428
var underscored = _dereq_('./underscored');                                                                           // 429
var trim = _dereq_('./trim');                                                                                         // 430
                                                                                                                      // 431
module.exports = function humanize(str) {                                                                             // 432
  return capitalize(trim(underscored(str).replace(/_id$/, '').replace(/_/g, ' ')));                                   // 433
};                                                                                                                    // 434
                                                                                                                      // 435
},{"./capitalize":2,"./trim":63,"./underscored":65}],25:[function(_dereq_,module,exports){                            // 436
var makeString = _dereq_('./helper/makeString');                                                                      // 437
                                                                                                                      // 438
module.exports = function include(str, needle) {                                                                      // 439
  if (needle === '') return true;                                                                                     // 440
  return makeString(str).indexOf(needle) !== -1;                                                                      // 441
};                                                                                                                    // 442
                                                                                                                      // 443
},{"./helper/makeString":21}],26:[function(_dereq_,module,exports){                                                   // 444
var splice = _dereq_('./splice');                                                                                     // 445
                                                                                                                      // 446
module.exports = function insert(str, i, substr) {                                                                    // 447
  return splice(str, i, 0, substr);                                                                                   // 448
};                                                                                                                    // 449
                                                                                                                      // 450
},{"./splice":47}],27:[function(_dereq_,module,exports){                                                              // 451
var makeString = _dereq_('./helper/makeString');                                                                      // 452
                                                                                                                      // 453
module.exports = function isBlank(str) {                                                                              // 454
  return (/^\s*$/).test(makeString(str));                                                                             // 455
};                                                                                                                    // 456
                                                                                                                      // 457
},{"./helper/makeString":21}],28:[function(_dereq_,module,exports){                                                   // 458
var makeString = _dereq_('./helper/makeString');                                                                      // 459
var slice = [].slice;                                                                                                 // 460
                                                                                                                      // 461
module.exports = function join() {                                                                                    // 462
  var args = slice.call(arguments),                                                                                   // 463
    separator = args.shift();                                                                                         // 464
                                                                                                                      // 465
  return args.join(makeString(separator));                                                                            // 466
};                                                                                                                    // 467
                                                                                                                      // 468
},{"./helper/makeString":21}],29:[function(_dereq_,module,exports){                                                   // 469
var makeString = _dereq_('./helper/makeString');                                                                      // 470
                                                                                                                      // 471
/**                                                                                                                   // 472
 * Based on the implementation here: https://github.com/hiddentao/fast-levenshtein                                    // 473
 */                                                                                                                   // 474
module.exports = function levenshtein(str1, str2) {                                                                   // 475
  'use strict';                                                                                                       // 476
  str1 = makeString(str1);                                                                                            // 477
  str2 = makeString(str2);                                                                                            // 478
                                                                                                                      // 479
  // Short cut cases                                                                                                  // 480
  if (str1 === str2) return 0;                                                                                        // 481
  if (!str1 || !str2) return Math.max(str1.length, str2.length);                                                      // 482
                                                                                                                      // 483
  // two rows                                                                                                         // 484
  var prevRow = new Array(str2.length + 1);                                                                           // 485
                                                                                                                      // 486
  // initialise previous row                                                                                          // 487
  for (var i = 0; i < prevRow.length; ++i) {                                                                          // 488
    prevRow[i] = i;                                                                                                   // 489
  }                                                                                                                   // 490
                                                                                                                      // 491
  // calculate current row distance from previous row                                                                 // 492
  for (i = 0; i < str1.length; ++i) {                                                                                 // 493
    var nextCol = i + 1;                                                                                              // 494
                                                                                                                      // 495
    for (var j = 0; j < str2.length; ++j) {                                                                           // 496
      var curCol = nextCol;                                                                                           // 497
                                                                                                                      // 498
      // substution                                                                                                   // 499
      nextCol = prevRow[j] + ( (str1.charAt(i) === str2.charAt(j)) ? 0 : 1 );                                         // 500
      // insertion                                                                                                    // 501
      var tmp = curCol + 1;                                                                                           // 502
      if (nextCol > tmp) {                                                                                            // 503
        nextCol = tmp;                                                                                                // 504
      }                                                                                                               // 505
      // deletion                                                                                                     // 506
      tmp = prevRow[j + 1] + 1;                                                                                       // 507
      if (nextCol > tmp) {                                                                                            // 508
        nextCol = tmp;                                                                                                // 509
      }                                                                                                               // 510
                                                                                                                      // 511
      // copy current col value into previous (in preparation for next iteration)                                     // 512
      prevRow[j] = curCol;                                                                                            // 513
    }                                                                                                                 // 514
                                                                                                                      // 515
    // copy last col value into previous (in preparation for next iteration)                                          // 516
    prevRow[j] = nextCol;                                                                                             // 517
  }                                                                                                                   // 518
                                                                                                                      // 519
  return nextCol;                                                                                                     // 520
};                                                                                                                    // 521
                                                                                                                      // 522
},{"./helper/makeString":21}],30:[function(_dereq_,module,exports){                                                   // 523
module.exports = function lines(str) {                                                                                // 524
  if (str == null) return [];                                                                                         // 525
  return String(str).split(/\r\n?|\n/);                                                                               // 526
};                                                                                                                    // 527
                                                                                                                      // 528
},{}],31:[function(_dereq_,module,exports){                                                                           // 529
var pad = _dereq_('./pad');                                                                                           // 530
                                                                                                                      // 531
module.exports = function lpad(str, length, padStr) {                                                                 // 532
  return pad(str, length, padStr);                                                                                    // 533
};                                                                                                                    // 534
                                                                                                                      // 535
},{"./pad":37}],32:[function(_dereq_,module,exports){                                                                 // 536
var pad = _dereq_('./pad');                                                                                           // 537
                                                                                                                      // 538
module.exports = function lrpad(str, length, padStr) {                                                                // 539
  return pad(str, length, padStr, 'both');                                                                            // 540
};                                                                                                                    // 541
                                                                                                                      // 542
},{"./pad":37}],33:[function(_dereq_,module,exports){                                                                 // 543
var makeString = _dereq_('./helper/makeString');                                                                      // 544
var defaultToWhiteSpace = _dereq_('./helper/defaultToWhiteSpace');                                                    // 545
var nativeTrimLeft = String.prototype.trimLeft;                                                                       // 546
                                                                                                                      // 547
module.exports = function ltrim(str, characters) {                                                                    // 548
  str = makeString(str);                                                                                              // 549
  if (!characters && nativeTrimLeft) return nativeTrimLeft.call(str);                                                 // 550
  characters = defaultToWhiteSpace(characters);                                                                       // 551
  return str.replace(new RegExp('^' + characters + '+'), '');                                                         // 552
};                                                                                                                    // 553
                                                                                                                      // 554
},{"./helper/defaultToWhiteSpace":17,"./helper/makeString":21}],34:[function(_dereq_,module,exports){                 // 555
var makeString = _dereq_('./helper/makeString');                                                                      // 556
                                                                                                                      // 557
module.exports = function(str, callback) {                                                                            // 558
  str = makeString(str);                                                                                              // 559
                                                                                                                      // 560
  if (str.length === 0 || typeof callback !== 'function') return str;                                                 // 561
                                                                                                                      // 562
  return str.replace(/./g, callback);                                                                                 // 563
};                                                                                                                    // 564
                                                                                                                      // 565
},{"./helper/makeString":21}],35:[function(_dereq_,module,exports){                                                   // 566
module.exports = function naturalCmp(str1, str2) {                                                                    // 567
  if (str1 == str2) return 0;                                                                                         // 568
  if (!str1) return -1;                                                                                               // 569
  if (!str2) return 1;                                                                                                // 570
                                                                                                                      // 571
  var cmpRegex = /(\.\d+|\d+|\D+)/g,                                                                                  // 572
    tokens1 = String(str1).match(cmpRegex),                                                                           // 573
    tokens2 = String(str2).match(cmpRegex),                                                                           // 574
    count = Math.min(tokens1.length, tokens2.length);                                                                 // 575
                                                                                                                      // 576
  for (var i = 0; i < count; i++) {                                                                                   // 577
    var a = tokens1[i],                                                                                               // 578
      b = tokens2[i];                                                                                                 // 579
                                                                                                                      // 580
    if (a !== b) {                                                                                                    // 581
      var num1 = +a;                                                                                                  // 582
      var num2 = +b;                                                                                                  // 583
      if (num1 === num1 && num2 === num2) {                                                                           // 584
        return num1 > num2 ? 1 : -1;                                                                                  // 585
      }                                                                                                               // 586
      return a < b ? -1 : 1;                                                                                          // 587
    }                                                                                                                 // 588
  }                                                                                                                   // 589
                                                                                                                      // 590
  if (tokens1.length != tokens2.length)                                                                               // 591
    return tokens1.length - tokens2.length;                                                                           // 592
                                                                                                                      // 593
  return str1 < str2 ? -1 : 1;                                                                                        // 594
};                                                                                                                    // 595
                                                                                                                      // 596
},{}],36:[function(_dereq_,module,exports){                                                                           // 597
module.exports = function numberFormat(number, dec, dsep, tsep) {                                                     // 598
  if (isNaN(number) || number == null) return '';                                                                     // 599
                                                                                                                      // 600
  number = number.toFixed(~~dec);                                                                                     // 601
  tsep = typeof tsep == 'string' ? tsep : ',';                                                                        // 602
                                                                                                                      // 603
  var parts = number.split('.'),                                                                                      // 604
    fnums = parts[0],                                                                                                 // 605
    decimals = parts[1] ? (dsep || '.') + parts[1] : '';                                                              // 606
                                                                                                                      // 607
  return fnums.replace(/(\d)(?=(?:\d{3})+$)/g, '$1' + tsep) + decimals;                                               // 608
};                                                                                                                    // 609
                                                                                                                      // 610
},{}],37:[function(_dereq_,module,exports){                                                                           // 611
var makeString = _dereq_('./helper/makeString');                                                                      // 612
var strRepeat = _dereq_('./helper/strRepeat');                                                                        // 613
                                                                                                                      // 614
module.exports = function pad(str, length, padStr, type) {                                                            // 615
  str = makeString(str);                                                                                              // 616
  length = ~~length;                                                                                                  // 617
                                                                                                                      // 618
  var padlen = 0;                                                                                                     // 619
                                                                                                                      // 620
  if (!padStr)                                                                                                        // 621
    padStr = ' ';                                                                                                     // 622
  else if (padStr.length > 1)                                                                                         // 623
    padStr = padStr.charAt(0);                                                                                        // 624
                                                                                                                      // 625
  switch (type) {                                                                                                     // 626
    case 'right':                                                                                                     // 627
      padlen = length - str.length;                                                                                   // 628
      return str + strRepeat(padStr, padlen);                                                                         // 629
    case 'both':                                                                                                      // 630
      padlen = length - str.length;                                                                                   // 631
      return strRepeat(padStr, Math.ceil(padlen / 2)) + str + strRepeat(padStr, Math.floor(padlen / 2));              // 632
    default: // 'left'                                                                                                // 633
      padlen = length - str.length;                                                                                   // 634
      return strRepeat(padStr, padlen) + str;                                                                         // 635
  }                                                                                                                   // 636
};                                                                                                                    // 637
                                                                                                                      // 638
},{"./helper/makeString":21,"./helper/strRepeat":22}],38:[function(_dereq_,module,exports){                           // 639
var adjacent = _dereq_('./helper/adjacent');                                                                          // 640
                                                                                                                      // 641
module.exports = function succ(str) {                                                                                 // 642
  return adjacent(str, -1);                                                                                           // 643
};                                                                                                                    // 644
                                                                                                                      // 645
},{"./helper/adjacent":16}],39:[function(_dereq_,module,exports){                                                     // 646
/**                                                                                                                   // 647
 * _s.prune: a more elegant version of truncate                                                                       // 648
 * prune extra chars, never leaving a half-chopped word.                                                              // 649
 * @author github.com/rwz                                                                                             // 650
 */                                                                                                                   // 651
var makeString = _dereq_('./helper/makeString');                                                                      // 652
var rtrim = _dereq_('./rtrim');                                                                                       // 653
                                                                                                                      // 654
module.exports = function prune(str, length, pruneStr) {                                                              // 655
  str = makeString(str);                                                                                              // 656
  length = ~~length;                                                                                                  // 657
  pruneStr = pruneStr != null ? String(pruneStr) : '...';                                                             // 658
                                                                                                                      // 659
  if (str.length <= length) return str;                                                                               // 660
                                                                                                                      // 661
  var tmpl = function(c) {                                                                                            // 662
    return c.toUpperCase() !== c.toLowerCase() ? 'A' : ' ';                                                           // 663
  },                                                                                                                  // 664
    template = str.slice(0, length + 1).replace(/.(?=\W*\w*$)/g, tmpl); // 'Hello, world' -> 'HellAA AAAAA'           // 665
                                                                                                                      // 666
  if (template.slice(template.length - 2).match(/\w\w/))                                                              // 667
    template = template.replace(/\s*\S+$/, '');                                                                       // 668
  else                                                                                                                // 669
    template = rtrim(template.slice(0, template.length - 1));                                                         // 670
                                                                                                                      // 671
  return (template + pruneStr).length > str.length ? str : str.slice(0, template.length) + pruneStr;                  // 672
};                                                                                                                    // 673
                                                                                                                      // 674
},{"./helper/makeString":21,"./rtrim":45}],40:[function(_dereq_,module,exports){                                      // 675
var surround = _dereq_('./surround');                                                                                 // 676
                                                                                                                      // 677
module.exports = function quote(str, quoteChar) {                                                                     // 678
  return surround(str, quoteChar || '"');                                                                             // 679
};                                                                                                                    // 680
                                                                                                                      // 681
},{"./surround":56}],41:[function(_dereq_,module,exports){                                                            // 682
var makeString = _dereq_('./helper/makeString');                                                                      // 683
var strRepeat = _dereq_('./helper/strRepeat');                                                                        // 684
                                                                                                                      // 685
module.exports = function repeat(str, qty, separator) {                                                               // 686
  str = makeString(str);                                                                                              // 687
                                                                                                                      // 688
  qty = ~~qty;                                                                                                        // 689
                                                                                                                      // 690
  // using faster implementation if separator is not needed;                                                          // 691
  if (separator == null) return strRepeat(str, qty);                                                                  // 692
                                                                                                                      // 693
  // this one is about 300x slower in Google Chrome                                                                   // 694
  /*eslint no-empty: 0*/                                                                                              // 695
  for (var repeat = []; qty > 0; repeat[--qty] = str) {}                                                              // 696
  return repeat.join(separator);                                                                                      // 697
};                                                                                                                    // 698
                                                                                                                      // 699
},{"./helper/makeString":21,"./helper/strRepeat":22}],42:[function(_dereq_,module,exports){                           // 700
var makeString = _dereq_('./helper/makeString');                                                                      // 701
                                                                                                                      // 702
module.exports = function replaceAll(str, find, replace, ignorecase) {                                                // 703
  var flags = (ignorecase === true)?'gi':'g';                                                                         // 704
  var reg = new RegExp(find, flags);                                                                                  // 705
                                                                                                                      // 706
  return makeString(str).replace(reg, replace);                                                                       // 707
};                                                                                                                    // 708
                                                                                                                      // 709
},{"./helper/makeString":21}],43:[function(_dereq_,module,exports){                                                   // 710
var chars = _dereq_('./chars');                                                                                       // 711
                                                                                                                      // 712
module.exports = function reverse(str) {                                                                              // 713
  return chars(str).reverse().join('');                                                                               // 714
};                                                                                                                    // 715
                                                                                                                      // 716
},{"./chars":3}],44:[function(_dereq_,module,exports){                                                                // 717
var pad = _dereq_('./pad');                                                                                           // 718
                                                                                                                      // 719
module.exports = function rpad(str, length, padStr) {                                                                 // 720
  return pad(str, length, padStr, 'right');                                                                           // 721
};                                                                                                                    // 722
                                                                                                                      // 723
},{"./pad":37}],45:[function(_dereq_,module,exports){                                                                 // 724
var makeString = _dereq_('./helper/makeString');                                                                      // 725
var defaultToWhiteSpace = _dereq_('./helper/defaultToWhiteSpace');                                                    // 726
var nativeTrimRight = String.prototype.trimRight;                                                                     // 727
                                                                                                                      // 728
module.exports = function rtrim(str, characters) {                                                                    // 729
  str = makeString(str);                                                                                              // 730
  if (!characters && nativeTrimRight) return nativeTrimRight.call(str);                                               // 731
  characters = defaultToWhiteSpace(characters);                                                                       // 732
  return str.replace(new RegExp(characters + '+$'), '');                                                              // 733
};                                                                                                                    // 734
                                                                                                                      // 735
},{"./helper/defaultToWhiteSpace":17,"./helper/makeString":21}],46:[function(_dereq_,module,exports){                 // 736
var trim = _dereq_('./trim');                                                                                         // 737
var dasherize = _dereq_('./dasherize');                                                                               // 738
var cleanDiacritics = _dereq_("./cleanDiacritics");                                                                   // 739
                                                                                                                      // 740
module.exports = function slugify(str) {                                                                              // 741
  return trim(dasherize(cleanDiacritics(str).replace(/[^\w\s-]/g, '-').toLowerCase()), '-');                          // 742
};                                                                                                                    // 743
                                                                                                                      // 744
},{"./cleanDiacritics":7,"./dasherize":9,"./trim":63}],47:[function(_dereq_,module,exports){                          // 745
var chars = _dereq_('./chars');                                                                                       // 746
                                                                                                                      // 747
module.exports = function splice(str, i, howmany, substr) {                                                           // 748
  var arr = chars(str);                                                                                               // 749
  arr.splice(~~i, ~~howmany, substr);                                                                                 // 750
  return arr.join('');                                                                                                // 751
};                                                                                                                    // 752
                                                                                                                      // 753
},{"./chars":3}],48:[function(_dereq_,module,exports){                                                                // 754
// sprintf() for JavaScript 0.7-beta1                                                                                 // 755
// http://www.diveintojavascript.com/projects/javascript-sprintf                                                      // 756
//                                                                                                                    // 757
// Copyright (c) Alexandru Marasteanu <alexaholic [at) gmail (dot] com>                                               // 758
// All rights reserved.                                                                                               // 759
var strRepeat = _dereq_('./helper/strRepeat');                                                                        // 760
var toString = Object.prototype.toString;                                                                             // 761
var sprintf = (function() {                                                                                           // 762
  function get_type(variable) {                                                                                       // 763
    return toString.call(variable).slice(8, -1).toLowerCase();                                                        // 764
  }                                                                                                                   // 765
                                                                                                                      // 766
  var str_repeat = strRepeat;                                                                                         // 767
                                                                                                                      // 768
  var str_format = function() {                                                                                       // 769
    if (!str_format.cache.hasOwnProperty(arguments[0])) {                                                             // 770
      str_format.cache[arguments[0]] = str_format.parse(arguments[0]);                                                // 771
    }                                                                                                                 // 772
    return str_format.format.call(null, str_format.cache[arguments[0]], arguments);                                   // 773
  };                                                                                                                  // 774
                                                                                                                      // 775
  str_format.format = function(parse_tree, argv) {                                                                    // 776
    var cursor = 1, tree_length = parse_tree.length, node_type = '', arg, output = [], i, k, match, pad, pad_character, pad_length;
    for (i = 0; i < tree_length; i++) {                                                                               // 778
      node_type = get_type(parse_tree[i]);                                                                            // 779
      if (node_type === 'string') {                                                                                   // 780
        output.push(parse_tree[i]);                                                                                   // 781
      }                                                                                                               // 782
      else if (node_type === 'array') {                                                                               // 783
        match = parse_tree[i]; // convenience purposes only                                                           // 784
        if (match[2]) { // keyword argument                                                                           // 785
          arg = argv[cursor];                                                                                         // 786
          for (k = 0; k < match[2].length; k++) {                                                                     // 787
            if (!arg.hasOwnProperty(match[2][k])) {                                                                   // 788
              throw new Error(sprintf('[_.sprintf] property "%s" does not exist', match[2][k]));                      // 789
            }                                                                                                         // 790
            arg = arg[match[2][k]];                                                                                   // 791
          }                                                                                                           // 792
        } else if (match[1]) { // positional argument (explicit)                                                      // 793
          arg = argv[match[1]];                                                                                       // 794
        }                                                                                                             // 795
        else { // positional argument (implicit)                                                                      // 796
          arg = argv[cursor++];                                                                                       // 797
        }                                                                                                             // 798
                                                                                                                      // 799
        if (/[^s]/.test(match[8]) && (get_type(arg) != 'number')) {                                                   // 800
          throw new Error(sprintf('[_.sprintf] expecting number but found %s', get_type(arg)));                       // 801
        }                                                                                                             // 802
        switch (match[8]) {                                                                                           // 803
          case 'b': arg = arg.toString(2); break;                                                                     // 804
          case 'c': arg = String.fromCharCode(arg); break;                                                            // 805
          case 'd': arg = parseInt(arg, 10); break;                                                                   // 806
          case 'e': arg = match[7] ? arg.toExponential(match[7]) : arg.toExponential(); break;                        // 807
          case 'f': arg = match[7] ? parseFloat(arg).toFixed(match[7]) : parseFloat(arg); break;                      // 808
          case 'o': arg = arg.toString(8); break;                                                                     // 809
          case 's': arg = ((arg = String(arg)) && match[7] ? arg.substring(0, match[7]) : arg); break;                // 810
          case 'u': arg = Math.abs(arg); break;                                                                       // 811
          case 'x': arg = arg.toString(16); break;                                                                    // 812
          case 'X': arg = arg.toString(16).toUpperCase(); break;                                                      // 813
        }                                                                                                             // 814
        arg = (/[def]/.test(match[8]) && match[3] && arg >= 0 ? '+'+ arg : arg);                                      // 815
        pad_character = match[4] ? match[4] == '0' ? '0' : match[4].charAt(1) : ' ';                                  // 816
        pad_length = match[6] - String(arg).length;                                                                   // 817
        pad = match[6] ? str_repeat(pad_character, pad_length) : '';                                                  // 818
        output.push(match[5] ? arg + pad : pad + arg);                                                                // 819
      }                                                                                                               // 820
    }                                                                                                                 // 821
    return output.join('');                                                                                           // 822
  };                                                                                                                  // 823
                                                                                                                      // 824
  str_format.cache = {};                                                                                              // 825
                                                                                                                      // 826
  str_format.parse = function(fmt) {                                                                                  // 827
    var _fmt = fmt, match = [], parse_tree = [], arg_names = 0;                                                       // 828
    while (_fmt) {                                                                                                    // 829
      if ((match = /^[^\x25]+/.exec(_fmt)) !== null) {                                                                // 830
        parse_tree.push(match[0]);                                                                                    // 831
      }                                                                                                               // 832
      else if ((match = /^\x25{2}/.exec(_fmt)) !== null) {                                                            // 833
        parse_tree.push('%');                                                                                         // 834
      }                                                                                                               // 835
      else if ((match = /^\x25(?:([1-9]\d*)\$|\(([^\)]+)\))?(\+)?(0|'[^$])?(-)?(\d+)?(?:\.(\d+))?([b-fosuxX])/.exec(_fmt)) !== null) {
        if (match[2]) {                                                                                               // 837
          arg_names |= 1;                                                                                             // 838
          var field_list = [], replacement_field = match[2], field_match = [];                                        // 839
          if ((field_match = /^([a-z_][a-z_\d]*)/i.exec(replacement_field)) !== null) {                               // 840
            field_list.push(field_match[1]);                                                                          // 841
            while ((replacement_field = replacement_field.substring(field_match[0].length)) !== '') {                 // 842
              if ((field_match = /^\.([a-z_][a-z_\d]*)/i.exec(replacement_field)) !== null) {                         // 843
                field_list.push(field_match[1]);                                                                      // 844
              }                                                                                                       // 845
              else if ((field_match = /^\[(\d+)\]/.exec(replacement_field)) !== null) {                               // 846
                field_list.push(field_match[1]);                                                                      // 847
              }                                                                                                       // 848
              else {                                                                                                  // 849
                throw new Error('[_.sprintf] huh?');                                                                  // 850
              }                                                                                                       // 851
            }                                                                                                         // 852
          }                                                                                                           // 853
          else {                                                                                                      // 854
            throw new Error('[_.sprintf] huh?');                                                                      // 855
          }                                                                                                           // 856
          match[2] = field_list;                                                                                      // 857
        }                                                                                                             // 858
        else {                                                                                                        // 859
          arg_names |= 2;                                                                                             // 860
        }                                                                                                             // 861
        if (arg_names === 3) {                                                                                        // 862
          throw new Error('[_.sprintf] mixing positional and named placeholders is not (yet) supported');             // 863
        }                                                                                                             // 864
        parse_tree.push(match);                                                                                       // 865
      }                                                                                                               // 866
      else {                                                                                                          // 867
        throw new Error('[_.sprintf] huh?');                                                                          // 868
      }                                                                                                               // 869
      _fmt = _fmt.substring(match[0].length);                                                                         // 870
    }                                                                                                                 // 871
    return parse_tree;                                                                                                // 872
  };                                                                                                                  // 873
                                                                                                                      // 874
  return str_format;                                                                                                  // 875
})();                                                                                                                 // 876
                                                                                                                      // 877
module.exports = sprintf;                                                                                             // 878
                                                                                                                      // 879
},{"./helper/strRepeat":22}],49:[function(_dereq_,module,exports){                                                    // 880
var makeString = _dereq_('./helper/makeString');                                                                      // 881
var toPositive = _dereq_('./helper/toPositive');                                                                      // 882
                                                                                                                      // 883
module.exports = function startsWith(str, starts, position) {                                                         // 884
  str = makeString(str);                                                                                              // 885
  starts = '' + starts;                                                                                               // 886
  position = position == null ? 0 : Math.min(toPositive(position), str.length);                                       // 887
  return str.lastIndexOf(starts, position) === position;                                                              // 888
};                                                                                                                    // 889
                                                                                                                      // 890
},{"./helper/makeString":21,"./helper/toPositive":23}],50:[function(_dereq_,module,exports){                          // 891
var makeString = _dereq_('./helper/makeString');                                                                      // 892
                                                                                                                      // 893
module.exports = function strLeft(str, sep) {                                                                         // 894
  str = makeString(str);                                                                                              // 895
  sep = makeString(sep);                                                                                              // 896
  var pos = !sep ? -1 : str.indexOf(sep);                                                                             // 897
  return~ pos ? str.slice(0, pos) : str;                                                                              // 898
};                                                                                                                    // 899
                                                                                                                      // 900
},{"./helper/makeString":21}],51:[function(_dereq_,module,exports){                                                   // 901
var makeString = _dereq_('./helper/makeString');                                                                      // 902
                                                                                                                      // 903
module.exports = function strLeftBack(str, sep) {                                                                     // 904
  str = makeString(str);                                                                                              // 905
  sep = makeString(sep);                                                                                              // 906
  var pos = str.lastIndexOf(sep);                                                                                     // 907
  return~ pos ? str.slice(0, pos) : str;                                                                              // 908
};                                                                                                                    // 909
                                                                                                                      // 910
},{"./helper/makeString":21}],52:[function(_dereq_,module,exports){                                                   // 911
var makeString = _dereq_('./helper/makeString');                                                                      // 912
                                                                                                                      // 913
module.exports = function strRight(str, sep) {                                                                        // 914
  str = makeString(str);                                                                                              // 915
  sep = makeString(sep);                                                                                              // 916
  var pos = !sep ? -1 : str.indexOf(sep);                                                                             // 917
  return~ pos ? str.slice(pos + sep.length, str.length) : str;                                                        // 918
};                                                                                                                    // 919
                                                                                                                      // 920
},{"./helper/makeString":21}],53:[function(_dereq_,module,exports){                                                   // 921
var makeString = _dereq_('./helper/makeString');                                                                      // 922
                                                                                                                      // 923
module.exports = function strRightBack(str, sep) {                                                                    // 924
  str = makeString(str);                                                                                              // 925
  sep = makeString(sep);                                                                                              // 926
  var pos = !sep ? -1 : str.lastIndexOf(sep);                                                                         // 927
  return~ pos ? str.slice(pos + sep.length, str.length) : str;                                                        // 928
};                                                                                                                    // 929
                                                                                                                      // 930
},{"./helper/makeString":21}],54:[function(_dereq_,module,exports){                                                   // 931
var makeString = _dereq_('./helper/makeString');                                                                      // 932
                                                                                                                      // 933
module.exports = function stripTags(str) {                                                                            // 934
  return makeString(str).replace(/<\/?[^>]+>/g, '');                                                                  // 935
};                                                                                                                    // 936
                                                                                                                      // 937
},{"./helper/makeString":21}],55:[function(_dereq_,module,exports){                                                   // 938
var adjacent = _dereq_('./helper/adjacent');                                                                          // 939
                                                                                                                      // 940
module.exports = function succ(str) {                                                                                 // 941
  return adjacent(str, 1);                                                                                            // 942
};                                                                                                                    // 943
                                                                                                                      // 944
},{"./helper/adjacent":16}],56:[function(_dereq_,module,exports){                                                     // 945
module.exports = function surround(str, wrapper) {                                                                    // 946
  return [wrapper, str, wrapper].join('');                                                                            // 947
};                                                                                                                    // 948
                                                                                                                      // 949
},{}],57:[function(_dereq_,module,exports){                                                                           // 950
var makeString = _dereq_('./helper/makeString');                                                                      // 951
                                                                                                                      // 952
module.exports = function swapCase(str) {                                                                             // 953
  return makeString(str).replace(/\S/g, function(c) {                                                                 // 954
    return c === c.toUpperCase() ? c.toLowerCase() : c.toUpperCase();                                                 // 955
  });                                                                                                                 // 956
};                                                                                                                    // 957
                                                                                                                      // 958
},{"./helper/makeString":21}],58:[function(_dereq_,module,exports){                                                   // 959
var makeString = _dereq_('./helper/makeString');                                                                      // 960
                                                                                                                      // 961
module.exports = function titleize(str) {                                                                             // 962
  return makeString(str).toLowerCase().replace(/(?:^|\s|-)\S/g, function(c) {                                         // 963
    return c.toUpperCase();                                                                                           // 964
  });                                                                                                                 // 965
};                                                                                                                    // 966
                                                                                                                      // 967
},{"./helper/makeString":21}],59:[function(_dereq_,module,exports){                                                   // 968
var trim = _dereq_('./trim');                                                                                         // 969
                                                                                                                      // 970
function boolMatch(s, matchers) {                                                                                     // 971
  var i, matcher, down = s.toLowerCase();                                                                             // 972
  matchers = [].concat(matchers);                                                                                     // 973
  for (i = 0; i < matchers.length; i += 1) {                                                                          // 974
    matcher = matchers[i];                                                                                            // 975
    if (!matcher) continue;                                                                                           // 976
    if (matcher.test && matcher.test(s)) return true;                                                                 // 977
    if (matcher.toLowerCase() === down) return true;                                                                  // 978
  }                                                                                                                   // 979
}                                                                                                                     // 980
                                                                                                                      // 981
module.exports = function toBoolean(str, trueValues, falseValues) {                                                   // 982
  if (typeof str === "number") str = "" + str;                                                                        // 983
  if (typeof str !== "string") return !!str;                                                                          // 984
  str = trim(str);                                                                                                    // 985
  if (boolMatch(str, trueValues || ["true", "1"])) return true;                                                       // 986
  if (boolMatch(str, falseValues || ["false", "0"])) return false;                                                    // 987
};                                                                                                                    // 988
                                                                                                                      // 989
},{"./trim":63}],60:[function(_dereq_,module,exports){                                                                // 990
module.exports = function toNumber(num, precision) {                                                                  // 991
  if (num == null) return 0;                                                                                          // 992
  var factor = Math.pow(10, isFinite(precision) ? precision : 0);                                                     // 993
  return Math.round(num * factor) / factor;                                                                           // 994
};                                                                                                                    // 995
                                                                                                                      // 996
},{}],61:[function(_dereq_,module,exports){                                                                           // 997
var rtrim = _dereq_('./rtrim');                                                                                       // 998
                                                                                                                      // 999
module.exports = function toSentence(array, separator, lastSeparator, serial) {                                       // 1000
  separator = separator || ', ';                                                                                      // 1001
  lastSeparator = lastSeparator || ' and ';                                                                           // 1002
  var a = array.slice(),                                                                                              // 1003
    lastMember = a.pop();                                                                                             // 1004
                                                                                                                      // 1005
  if (array.length > 2 && serial) lastSeparator = rtrim(separator) + lastSeparator;                                   // 1006
                                                                                                                      // 1007
  return a.length ? a.join(separator) + lastSeparator + lastMember : lastMember;                                      // 1008
};                                                                                                                    // 1009
                                                                                                                      // 1010
},{"./rtrim":45}],62:[function(_dereq_,module,exports){                                                               // 1011
var toSentence = _dereq_('./toSentence');                                                                             // 1012
                                                                                                                      // 1013
module.exports = function toSentenceSerial(array, sep, lastSep) {                                                     // 1014
  return toSentence(array, sep, lastSep, true);                                                                       // 1015
};                                                                                                                    // 1016
                                                                                                                      // 1017
},{"./toSentence":61}],63:[function(_dereq_,module,exports){                                                          // 1018
var makeString = _dereq_('./helper/makeString');                                                                      // 1019
var defaultToWhiteSpace = _dereq_('./helper/defaultToWhiteSpace');                                                    // 1020
var nativeTrim = String.prototype.trim;                                                                               // 1021
                                                                                                                      // 1022
module.exports = function trim(str, characters) {                                                                     // 1023
  str = makeString(str);                                                                                              // 1024
  if (!characters && nativeTrim) return nativeTrim.call(str);                                                         // 1025
  characters = defaultToWhiteSpace(characters);                                                                       // 1026
  return str.replace(new RegExp('^' + characters + '+|' + characters + '+$', 'g'), '');                               // 1027
};                                                                                                                    // 1028
                                                                                                                      // 1029
},{"./helper/defaultToWhiteSpace":17,"./helper/makeString":21}],64:[function(_dereq_,module,exports){                 // 1030
var makeString = _dereq_('./helper/makeString');                                                                      // 1031
                                                                                                                      // 1032
module.exports = function truncate(str, length, truncateStr) {                                                        // 1033
  str = makeString(str);                                                                                              // 1034
  truncateStr = truncateStr || '...';                                                                                 // 1035
  length = ~~length;                                                                                                  // 1036
  return str.length > length ? str.slice(0, length) + truncateStr : str;                                              // 1037
};                                                                                                                    // 1038
                                                                                                                      // 1039
},{"./helper/makeString":21}],65:[function(_dereq_,module,exports){                                                   // 1040
var trim = _dereq_('./trim');                                                                                         // 1041
                                                                                                                      // 1042
module.exports = function underscored(str) {                                                                          // 1043
  return trim(str).replace(/([a-z\d])([A-Z]+)/g, '$1_$2').replace(/[-\s]+/g, '_').toLowerCase();                      // 1044
};                                                                                                                    // 1045
                                                                                                                      // 1046
},{"./trim":63}],66:[function(_dereq_,module,exports){                                                                // 1047
var makeString = _dereq_('./helper/makeString');                                                                      // 1048
var htmlEntities = _dereq_('./helper/htmlEntities');                                                                  // 1049
                                                                                                                      // 1050
module.exports = function unescapeHTML(str) {                                                                         // 1051
  return makeString(str).replace(/\&([^;]+);/g, function(entity, entityCode) {                                        // 1052
    var match;                                                                                                        // 1053
                                                                                                                      // 1054
    if (entityCode in htmlEntities) {                                                                                 // 1055
      return htmlEntities[entityCode];                                                                                // 1056
    /*eslint no-cond-assign: 0*/                                                                                      // 1057
    } else if (match = entityCode.match(/^#x([\da-fA-F]+)$/)) {                                                       // 1058
      return String.fromCharCode(parseInt(match[1], 16));                                                             // 1059
    /*eslint no-cond-assign: 0*/                                                                                      // 1060
    } else if (match = entityCode.match(/^#(\d+)$/)) {                                                                // 1061
      return String.fromCharCode(~~match[1]);                                                                         // 1062
    } else {                                                                                                          // 1063
      return entity;                                                                                                  // 1064
    }                                                                                                                 // 1065
  });                                                                                                                 // 1066
};                                                                                                                    // 1067
                                                                                                                      // 1068
},{"./helper/htmlEntities":20,"./helper/makeString":21}],67:[function(_dereq_,module,exports){                        // 1069
module.exports = function unquote(str, quoteChar) {                                                                   // 1070
  quoteChar = quoteChar || '"';                                                                                       // 1071
  if (str[0] === quoteChar && str[str.length - 1] === quoteChar)                                                      // 1072
    return str.slice(1, str.length - 1);                                                                              // 1073
  else return str;                                                                                                    // 1074
};                                                                                                                    // 1075
                                                                                                                      // 1076
},{}],68:[function(_dereq_,module,exports){                                                                           // 1077
var sprintf = _dereq_('./sprintf');                                                                                   // 1078
                                                                                                                      // 1079
module.exports = function vsprintf(fmt, argv) {                                                                       // 1080
  argv.unshift(fmt);                                                                                                  // 1081
  return sprintf.apply(null, argv);                                                                                   // 1082
};                                                                                                                    // 1083
                                                                                                                      // 1084
},{"./sprintf":48}],69:[function(_dereq_,module,exports){                                                             // 1085
var isBlank = _dereq_('./isBlank');                                                                                   // 1086
var trim = _dereq_('./trim');                                                                                         // 1087
                                                                                                                      // 1088
module.exports = function words(str, delimiter) {                                                                     // 1089
  if (isBlank(str)) return [];                                                                                        // 1090
  return trim(str, delimiter).split(delimiter || /\s+/);                                                              // 1091
};                                                                                                                    // 1092
                                                                                                                      // 1093
},{"./isBlank":27,"./trim":63}],70:[function(_dereq_,module,exports){                                                 // 1094
// Wrap                                                                                                               // 1095
// wraps a string by a certain width                                                                                  // 1096
                                                                                                                      // 1097
var makeString = _dereq_('./helper/makeString');                                                                      // 1098
                                                                                                                      // 1099
module.exports = function wrap(str, options){                                                                         // 1100
	str = makeString(str);                                                                                               // 1101
                                                                                                                      // 1102
	options = options || {};                                                                                             // 1103
                                                                                                                      // 1104
	var width = options.width || 75;                                                                                     // 1105
	var seperator = options.seperator || '\n';                                                                           // 1106
	var cut = options.cut || false;                                                                                      // 1107
	var preserveSpaces = options.preserveSpaces || false;                                                                // 1108
	var trailingSpaces = options.trailingSpaces || false;                                                                // 1109
                                                                                                                      // 1110
  var result;                                                                                                         // 1111
                                                                                                                      // 1112
	if(width <= 0){                                                                                                      // 1113
		return str;                                                                                                         // 1114
	}                                                                                                                    // 1115
                                                                                                                      // 1116
	else if(!cut){                                                                                                       // 1117
                                                                                                                      // 1118
		var words = str.split(" ");                                                                                         // 1119
		var current_column = 0;                                                                                             // 1120
		result = "";                                                                                                        // 1121
                                                                                                                      // 1122
		while(words.length > 0){                                                                                            // 1123
			                                                                                                                   // 1124
			// if adding a space and the next word would cause this line to be longer than width...                            // 1125
			if(1 + words[0].length + current_column > width){                                                                  // 1126
				//start a new line if this line is not already empty                                                              // 1127
				if(current_column > 0){                                                                                           // 1128
					// add a space at the end of the line is preserveSpaces is true                                                  // 1129
					if (preserveSpaces){                                                                                             // 1130
						result += ' ';                                                                                                  // 1131
						current_column++;                                                                                               // 1132
					}                                                                                                                // 1133
					// fill the rest of the line with spaces if trailingSpaces option is true                                        // 1134
					else if(trailingSpaces){                                                                                         // 1135
						while(current_column < width){                                                                                  // 1136
							result += ' ';                                                                                                 // 1137
							current_column++;                                                                                              // 1138
						}						                                                                                                         // 1139
					}                                                                                                                // 1140
					//start new line                                                                                                 // 1141
					result += seperator;                                                                                             // 1142
					current_column = 0;                                                                                              // 1143
				}                                                                                                                 // 1144
			}                                                                                                                  // 1145
                                                                                                                      // 1146
			// if not at the begining of the line, add a space in front of the word                                            // 1147
			if(current_column > 0){                                                                                            // 1148
				result += " ";                                                                                                    // 1149
				current_column++;                                                                                                 // 1150
			}                                                                                                                  // 1151
                                                                                                                      // 1152
			// tack on the next word, update current column, a pop words array                                                 // 1153
			result += words[0];                                                                                                // 1154
			current_column += words[0].length;                                                                                 // 1155
			words.shift();                                                                                                     // 1156
                                                                                                                      // 1157
		}                                                                                                                   // 1158
                                                                                                                      // 1159
		// fill the rest of the line with spaces if trailingSpaces option is true                                           // 1160
		if(trailingSpaces){                                                                                                 // 1161
			while(current_column < width){                                                                                     // 1162
				result += ' ';                                                                                                    // 1163
				current_column++;                                                                                                 // 1164
			}						                                                                                                            // 1165
		}                                                                                                                   // 1166
                                                                                                                      // 1167
		return result;                                                                                                      // 1168
                                                                                                                      // 1169
	}                                                                                                                    // 1170
                                                                                                                      // 1171
	else {                                                                                                               // 1172
                                                                                                                      // 1173
		var index = 0;                                                                                                      // 1174
		result = "";                                                                                                        // 1175
                                                                                                                      // 1176
		// walk through each character and add seperators where appropriate                                                 // 1177
		while(index < str.length){                                                                                          // 1178
			if(index % width == 0 && index > 0){                                                                               // 1179
				result += seperator;                                                                                              // 1180
			}                                                                                                                  // 1181
			result += str.charAt(index);                                                                                       // 1182
			index++;                                                                                                           // 1183
		}                                                                                                                   // 1184
                                                                                                                      // 1185
		// fill the rest of the line with spaces if trailingSpaces option is true                                           // 1186
		if(trailingSpaces){                                                                                                 // 1187
			while(index % width > 0){                                                                                          // 1188
				result += ' ';                                                                                                    // 1189
				index++;                                                                                                          // 1190
			}						                                                                                                            // 1191
		}                                                                                                                   // 1192
		                                                                                                                    // 1193
		return result;                                                                                                      // 1194
	}                                                                                                                    // 1195
};                                                                                                                    // 1196
                                                                                                                      // 1197
},{"./helper/makeString":21}]},{},[15])                                                                               // 1198
(15)                                                                                                                  // 1199
});                                                                                                                   // 1200
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/underscorestring_underscore.string/meteor-post.js                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// s will be picked up by Meteor and exported                                                                         // 1
s = module.exports;                                                                                                   // 2
                                                                                                                      // 3
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['underscorestring:underscore.string'] = {
  s: s
};

})();

//# sourceMappingURL=underscorestring_underscore.string.js.map
