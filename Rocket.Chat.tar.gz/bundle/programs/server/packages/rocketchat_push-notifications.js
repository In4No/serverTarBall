(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var ECMAScript = Package.ecmascript.ECMAScript;
var _ = Package.underscore._;
var RocketChat = Package['rocketchat:lib'].RocketChat;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var subscription, query, update, translations;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/server/methods/saveNotificationSettings.js                          //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
Meteor.methods({                                                                                              // 1
	saveNotificationSettings: function (rid, field, value) {                                                     // 2
		if (!Meteor.userId()) {                                                                                     // 3
			throw new Meteor.Error('invalid-user', 'Invalid user');                                                    // 4
		}                                                                                                           //
                                                                                                              //
		check(rid, String);                                                                                         // 7
		check(field, String);                                                                                       // 8
		check(value, String);                                                                                       // 9
                                                                                                              //
		if (['desktopNotifications', 'mobilePushNotifications'].indexOf(field) === -1) {                            // 11
			throw new Meteor.Error('invalid-settings', 'Invalid settings field');                                      // 12
		}                                                                                                           //
                                                                                                              //
		if (['all', 'mentions', 'nothing'].indexOf(value) === -1) {                                                 // 15
			throw new Meteor.Error('invalid-settings', 'Invalid settings value');                                      // 16
		}                                                                                                           //
                                                                                                              //
		subscription = RocketChat.models.Subscriptions.findOneByRoomIdAndUserId(rid, Meteor.userId());              // 19
		if (!subscription) {                                                                                        // 20
			throw new Meteor.Error('invalid-subscription', 'Invalid subscription');                                    // 21
		}                                                                                                           //
                                                                                                              //
		if (field === 'desktopNotifications') {                                                                     // 24
			RocketChat.models.Subscriptions.updateDesktopNotificationsById(subscription._id, value);                   // 25
		} else if (field === 'mobilePushNotifications') {                                                           //
			RocketChat.models.Subscriptions.updateMobilePushNotificationsById(subscription._id, value);                // 27
		}                                                                                                           //
                                                                                                              //
		return true;                                                                                                // 30
	}                                                                                                            //
});                                                                                                           //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/server/models/Subscriptions.js                                      //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
RocketChat.models.Subscriptions.updateDesktopNotificationsById = function (_id, desktopNotifications) {       // 1
	query = {                                                                                                    // 2
		_id: _id                                                                                                    // 3
	};                                                                                                           //
                                                                                                              //
	update = {                                                                                                   // 6
		$set: {                                                                                                     // 7
			desktopNotifications: desktopNotifications                                                                 // 8
		}                                                                                                           //
	};                                                                                                           //
                                                                                                              //
	return this.update(query, update);                                                                           // 12
};                                                                                                            //
                                                                                                              //
RocketChat.models.Subscriptions.updateMobilePushNotificationsById = function (_id, mobilePushNotifications) {
	query = {                                                                                                    // 16
		_id: _id                                                                                                    // 17
	};                                                                                                           //
                                                                                                              //
	update = {                                                                                                   // 20
		$set: {                                                                                                     // 21
			mobilePushNotifications: mobilePushNotifications                                                           // 22
		}                                                                                                           //
	};                                                                                                           //
                                                                                                              //
	return this.update(query, update);                                                                           // 26
};                                                                                                            //
                                                                                                              //
RocketChat.models.Subscriptions.findAlwaysNotifyDesktopUsersByRoomId = function (roomId) {                    // 29
	query = {                                                                                                    // 30
		rid: roomId,                                                                                                // 31
		desktopNotifications: 'all'                                                                                 // 32
	};                                                                                                           //
                                                                                                              //
	return this.find(query);                                                                                     // 35
};                                                                                                            //
                                                                                                              //
RocketChat.models.Subscriptions.findDontNotifyDesktopUsersByRoomId = function (roomId) {                      // 38
	query = {                                                                                                    // 39
		rid: roomId,                                                                                                // 40
		desktopNotifications: 'nothing'                                                                             // 41
	};                                                                                                           //
                                                                                                              //
	return this.find(query);                                                                                     // 44
};                                                                                                            //
                                                                                                              //
RocketChat.models.Subscriptions.findAlwaysNotifyMobileUsersByRoomId = function (roomId) {                     // 47
	query = {                                                                                                    // 48
		rid: roomId,                                                                                                // 49
		mobilePushNotifications: 'all'                                                                              // 50
	};                                                                                                           //
                                                                                                              //
	return this.find(query);                                                                                     // 53
};                                                                                                            //
                                                                                                              //
RocketChat.models.Subscriptions.findDontNotifyMobileUsersByRoomId = function (roomId) {                       // 56
	query = {                                                                                                    // 57
		rid: roomId,                                                                                                // 58
		mobilePushNotifications: 'nothing'                                                                          // 59
	};                                                                                                           //
                                                                                                              //
	return this.find(query);                                                                                     // 62
};                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/packages/rocketchat_push-notificationsi18n/de.i18n.js               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _ = Package.underscore._,                                                                                 // 1
    package_name = "project",                                                                                 // 2
    namespace = "project";                                                                                    // 3
                                                                                                              // 4
if (package_name != "project") {                                                                              // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                     // 6
}                                                                                                             // 7
TAPi18n.languages_names["de"] = ["German","Deutsch"];                                                         // 8
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];                                                        // 10
if(_.isUndefined(TAPi18n.translations["de"])) {                                                               // 11
  TAPi18n.translations["de"] = {};                                                                            // 12
}                                                                                                             // 13
                                                                                                              // 14
if(_.isUndefined(TAPi18n.translations["de"][namespace])) {                                                    // 15
  TAPi18n.translations["de"][namespace] = {};                                                                 // 16
}                                                                                                             // 17
                                                                                                              // 18
_.extend(TAPi18n.translations["de"][namespace], {"All_messages":"Alle Nachrichten","Desktop_notifications":"Desktop-Benachrichtigungen","Invalid_notification_setting_s":"Ungültige Benachrichtigungseinstellung: %s","Mentions":"Erwähnungen","Mentions_default":"Erwähnungen (Standard)","Mobile_push_notifications":"Pushnachrichten auf mobilen Geräten","Nothing":"Nichts","Push_notifications":"Pushnachrichten"});
TAPi18n._registerServerTranslator("de", namespace);                                                           // 20
                                                                                                              // 21
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/packages/rocketchat_push-notificationsi18n/en.i18n.js               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _ = Package.underscore._,                                                                                 // 1
    package_name = "project",                                                                                 // 2
    namespace = "project";                                                                                    // 3
                                                                                                              // 4
if (package_name != "project") {                                                                              // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                     // 6
}                                                                                                             // 7
// integrate the fallback language translations                                                               // 8
translations = {};                                                                                            // 9
translations[namespace] = {"All_messages":"All messages","Desktop_notifications":"Desktop notifications","Invalid_notification_setting_s":"Invalid notification setting: %s","Mentions":"Mentions","Mentions_default":"Mentions (default)","Mobile_push_notifications":"Mobile push notifications","Nothing":"Nothing","Push_notifications":"Push notifications"};
TAPi18n._loadLangFileObject("en", translations);                                                              // 11
TAPi18n._registerServerTranslator("en", namespace);                                                           // 12
                                                                                                              // 13
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/packages/rocketchat_push-notificationsi18n/fi.i18n.js               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _ = Package.underscore._,                                                                                 // 1
    package_name = "project",                                                                                 // 2
    namespace = "project";                                                                                    // 3
                                                                                                              // 4
if (package_name != "project") {                                                                              // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                     // 6
}                                                                                                             // 7
TAPi18n.languages_names["fi"] = ["Finnish","Suomi"];                                                          // 8
if(_.isUndefined(TAPi18n.translations["fi"])) {                                                               // 9
  TAPi18n.translations["fi"] = {};                                                                            // 10
}                                                                                                             // 11
                                                                                                              // 12
if(_.isUndefined(TAPi18n.translations["fi"][namespace])) {                                                    // 13
  TAPi18n.translations["fi"][namespace] = {};                                                                 // 14
}                                                                                                             // 15
                                                                                                              // 16
_.extend(TAPi18n.translations["fi"][namespace], {"Mentions":"Maininnat"});                                    // 17
TAPi18n._registerServerTranslator("fi", namespace);                                                           // 18
                                                                                                              // 19
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/packages/rocketchat_push-notificationsi18n/fr.i18n.js               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _ = Package.underscore._,                                                                                 // 1
    package_name = "project",                                                                                 // 2
    namespace = "project";                                                                                    // 3
                                                                                                              // 4
if (package_name != "project") {                                                                              // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                     // 6
}                                                                                                             // 7
TAPi18n.languages_names["fr"] = ["French (France)","Français"];                                               // 8
if(_.isUndefined(TAPi18n.translations["fr"])) {                                                               // 9
  TAPi18n.translations["fr"] = {};                                                                            // 10
}                                                                                                             // 11
                                                                                                              // 12
if(_.isUndefined(TAPi18n.translations["fr"][namespace])) {                                                    // 13
  TAPi18n.translations["fr"][namespace] = {};                                                                 // 14
}                                                                                                             // 15
                                                                                                              // 16
_.extend(TAPi18n.translations["fr"][namespace], {"Mentions":"Mentions"});                                     // 17
TAPi18n._registerServerTranslator("fr", namespace);                                                           // 18
                                                                                                              // 19
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/packages/rocketchat_push-notificationsi18n/he.i18n.js               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _ = Package.underscore._,                                                                                 // 1
    package_name = "project",                                                                                 // 2
    namespace = "project";                                                                                    // 3
                                                                                                              // 4
if (package_name != "project") {                                                                              // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                     // 6
}                                                                                                             // 7
TAPi18n.languages_names["he"] = ["Hebrew","עברית"];                                                           // 8
if(_.isUndefined(TAPi18n.translations["he"])) {                                                               // 9
  TAPi18n.translations["he"] = {};                                                                            // 10
}                                                                                                             // 11
                                                                                                              // 12
if(_.isUndefined(TAPi18n.translations["he"][namespace])) {                                                    // 13
  TAPi18n.translations["he"][namespace] = {};                                                                 // 14
}                                                                                                             // 15
                                                                                                              // 16
_.extend(TAPi18n.translations["he"][namespace], {"Mentions":"אזכורים"});                                      // 17
TAPi18n._registerServerTranslator("he", namespace);                                                           // 18
                                                                                                              // 19
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/packages/rocketchat_push-notificationsi18n/nl.i18n.js               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _ = Package.underscore._,                                                                                 // 1
    package_name = "project",                                                                                 // 2
    namespace = "project";                                                                                    // 3
                                                                                                              // 4
if (package_name != "project") {                                                                              // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                     // 6
}                                                                                                             // 7
TAPi18n.languages_names["nl"] = ["Dutch","Nederlands"];                                                       // 8
if(_.isUndefined(TAPi18n.translations["nl"])) {                                                               // 9
  TAPi18n.translations["nl"] = {};                                                                            // 10
}                                                                                                             // 11
                                                                                                              // 12
if(_.isUndefined(TAPi18n.translations["nl"][namespace])) {                                                    // 13
  TAPi18n.translations["nl"][namespace] = {};                                                                 // 14
}                                                                                                             // 15
                                                                                                              // 16
_.extend(TAPi18n.translations["nl"][namespace], {"Mentions":"Vermeldingen"});                                 // 17
TAPi18n._registerServerTranslator("nl", namespace);                                                           // 18
                                                                                                              // 19
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/packages/rocketchat_push-notificationsi18n/pl.i18n.js               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _ = Package.underscore._,                                                                                 // 1
    package_name = "project",                                                                                 // 2
    namespace = "project";                                                                                    // 3
                                                                                                              // 4
if (package_name != "project") {                                                                              // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                     // 6
}                                                                                                             // 7
TAPi18n.languages_names["pl"] = ["Polish","Polski"];                                                          // 8
if(_.isUndefined(TAPi18n.translations["pl"])) {                                                               // 9
  TAPi18n.translations["pl"] = {};                                                                            // 10
}                                                                                                             // 11
                                                                                                              // 12
if(_.isUndefined(TAPi18n.translations["pl"][namespace])) {                                                    // 13
  TAPi18n.translations["pl"][namespace] = {};                                                                 // 14
}                                                                                                             // 15
                                                                                                              // 16
_.extend(TAPi18n.translations["pl"][namespace], {"Mentions":"Wzmianki o tobie"});                             // 17
TAPi18n._registerServerTranslator("pl", namespace);                                                           // 18
                                                                                                              // 19
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/packages/rocketchat_push-notificationsi18n/ro.i18n.js               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _ = Package.underscore._,                                                                                 // 1
    package_name = "project",                                                                                 // 2
    namespace = "project";                                                                                    // 3
                                                                                                              // 4
if (package_name != "project") {                                                                              // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                     // 6
}                                                                                                             // 7
TAPi18n.languages_names["ro"] = ["Romanian","Română"];                                                        // 8
if(_.isUndefined(TAPi18n.translations["ro"])) {                                                               // 9
  TAPi18n.translations["ro"] = {};                                                                            // 10
}                                                                                                             // 11
                                                                                                              // 12
if(_.isUndefined(TAPi18n.translations["ro"][namespace])) {                                                    // 13
  TAPi18n.translations["ro"][namespace] = {};                                                                 // 14
}                                                                                                             // 15
                                                                                                              // 16
_.extend(TAPi18n.translations["ro"][namespace], {"Mentions":"Mențiuni"});                                     // 17
TAPi18n._registerServerTranslator("ro", namespace);                                                           // 18
                                                                                                              // 19
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                            //
// packages/rocketchat_push-notifications/packages/rocketchat_push-notificationsi18n/ru.i18n.js               //
//                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                              //
var _ = Package.underscore._,                                                                                 // 1
    package_name = "project",                                                                                 // 2
    namespace = "project";                                                                                    // 3
                                                                                                              // 4
if (package_name != "project") {                                                                              // 5
    namespace = TAPi18n.packages[package_name].namespace;                                                     // 6
}                                                                                                             // 7
TAPi18n.languages_names["ru"] = ["Russian","Русский"];                                                        // 8
if(_.isUndefined(TAPi18n.translations["ru"])) {                                                               // 9
  TAPi18n.translations["ru"] = {};                                                                            // 10
}                                                                                                             // 11
                                                                                                              // 12
if(_.isUndefined(TAPi18n.translations["ru"][namespace])) {                                                    // 13
  TAPi18n.translations["ru"][namespace] = {};                                                                 // 14
}                                                                                                             // 15
                                                                                                              // 16
_.extend(TAPi18n.translations["ru"][namespace], {"Mentions":"Упоминания"});                                   // 17
TAPi18n._registerServerTranslator("ru", namespace);                                                           // 18
                                                                                                              // 19
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['rocketchat:push-notifications'] = {};

})();

//# sourceMappingURL=rocketchat_push-notifications.js.map
